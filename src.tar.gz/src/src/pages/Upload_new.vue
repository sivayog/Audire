<template>
  <q-page padding>
    <q-stepper
      v-model="step"
      ref="stepper"
      class="bg-blue-grey-2"
      animated
      done-color="deep-purple-10"
    >
      <q-step
        :name="1"
        title="Initial Setup"
        icon="settings"
        :done="step > 1"
        style="min-height: 200px"
        color="black"
      >
        <div class="row">
          <div class="col-xs-12">Available Data for the Organization.</div>
        </div>
        <div class="row q-mt-md">
          <div class="col">
            <q-select
              v-model="orgModel"
              :options="orgOptions"
              label="Select Organization"
              @input="orgHandler"
            />
          </div>
          <!-- <q-form @submit="onSubmit" @reset="onReset" class="q-gutter-md">
              <q-input
                filled
                v-model="systemName"
                clearable
                placeholder="Enter Systems"
                :rules="[ val => val && val.length >= 5 || 'Please type minimum 5 characters',
              val => val && !val.includes(',') || 'please enter a single system']"
                class="text-subtitle1"
                @resetValidation="this.$qInput.resetValidation()"
              />
              <q-input
                v-model="systemsAdded"
                filled
                autogrow
                clearable
                class="text-subtitle1"
                :rules="[val => val && val !== '' && val !== ' ' || 'Please type something', 
                val => val && !val.includes(' ') || 'please enter comma seperated']"
                placeholder="Enter comma seperated entities."
              />
              <q-input
                v-model="truthSystems"
                filled
                autogrow
                clearable
                class="text-subtitle1"
                placeholder="Enter comma seperated true source for the functionalities"
              />

              <div class="relative-right">
                <q-btn label="save" type="submit" color="blue-grey-14" flat/>
                <q-btn label="Reset" type="reset" color="blue-grey-14" flat class="q-ml-sm"/>
                <q-btn
                  label="clear all"
                  @click="onClear"
                  color="blue-grey-14"
                  flat
                  class="q-ml-sm"
                />
              </div>
          </q-form>-->
          <!-- </div> -->
          <!-- <div class="col q-ml-lg text-subtitle1">
            <div class="row wrap">
              <div class="col-xs-12">Entered Systems:</div>
              <div class="col-xs-6 q-mt-md">
                <q-tree
                  :nodes="simple"
                  icon="fas fa-angle-double-right"
                  node-key="label"
                  no-nodes-label="No Data available."
                />
              </div>
            </div>
          </div>-->
        </div>
      </q-step>

      <q-step
        :name="2"
        title="Upload Data"
        icon="fas fa-cloud-upload-alt"
        :done="step > 2"
        style="min-height: 200px"
        color="black"
      >
        <div class="row">
          <div class="col-xs-12">Upload relevant data for the selected process.</div>
        </div>
        <!-- <div class="row q-mt-md">
          <div class="col q-mr-lg" v-for="(i,index) in checkboxTicked" :key="`i-${index}`">
            <q-tree
              :nodes="[i]"
              icon="fas fa-angle-double-right"
              node-key="label"
              no-nodes-label="No Data available."
              no-results-label="No Data Available"
              tick-strategy="leaf"
              :ticked.sync="_.find(truth,i.label)[`${i.label}`]"
              @update:ticked="truthHandler"
            />
          </div>
        </div>
        <div class="row q-mt-md">
          <div class="col q-mr-lg" v-for="(i,index) in truth" :key="`i-${index}`">{{i}}</div>
        </div>-->
        <!-- :filter="checkFileType" -->
        <div class="row no-wrap">
          <div class="col q-pa-md" v-for="(i,index) in simple" :key="`i-${index}`">
            <q-uploader
              ref="uploader"
              url="http://localhost:7777/upload"
              :form-fields="[{name: 'system', value: `${i}`},{name:'orgName',value:orgModel}]"
              :label="i"
              multiple
              batch
              color="blue-grey-14"
              accept="csv"
              :max-file-size="100e+7"
              style="max-width:250px"
              dark
              @added="fileAdded"
              @removed="fileRemoved"
              @uploaded="info => {uploadCheck(info)}"
            >
              <template v-slot:list="scope">
                <q-list separator inset>
                  <q-item v-for="file in scope.files" :key="file.name">
                    <q-item-section>
                      <q-item-label class="full-width ellipsis text-white">{{ file.name }}</q-item-label>

                      <q-item-label caption class="text-white">Status: {{ file.__status }}</q-item-label>

                      <q-item-label
                        caption
                        class="text-white"
                      >{{ file.__sizeLabel }} / {{ file.__progressLabel }}</q-item-label>
                    </q-item-section>

                    <q-item-section v-if="file.__img" thumbnail class="gt-xs">
                      <img :src="file.__img.src" />
                    </q-item-section>

                    <q-item-section top side>
                      <q-btn
                        class="gt-xs text-white"
                        size="12px"
                        flat
                        dense
                        round
                        icon="delete"
                        @click="scope.removeFile(file)"
                      />
                    </q-item-section>
                  </q-item>
                </q-list>
              </template>
            </q-uploader>
          </div>
        </div>
      </q-step>

      <q-step
        :name="3"
        title="Graph Mapping"
        icon="settings"
        :done="step > 3"
        style="min-height: 200px"
        color="black"
      >
        <div class="row">
          <div class="col-xs-12">Map CSV data with your "process" graph.</div>
        </div>
        <div class="row">
          <div class="col-xs-6 q-pa-lg">
            <q-tree
              :nodes="tree"
              icon="fas fa-angle-double-right"
              node-key="label"
              no-nodes-label="No Data available."
              no-results-label="No Results available"
              tick-strategy="leaf"
              :ticked.sync="ticked"
              color="red-10"
              control-color="teal-10"
            />
            <!-- :ticked.sync="_.find(ticked,i.label)[`${i.label}`]"
            @update:ticked="tickHandler()"-->
          </div>
          <div class="col-xs-6 q-pa-lg">
            <q-select
              :options="processes"
              v-model="selectedProcess"
              label="Select Process"
              options-dense
              dense
            />
          </div>
        </div>
        <div class="row flex flex-center">
          <q-btn
            class="float-right q-mr-md"
            :loading="buttonLoader"
            :disable="disableButton"
            rounded
            outlined
            color="teal-10"
            label="Load"
            @click="loadData"
          />
        </div>

        <!-- ..................... Testing comment starts ............................ -->
        <div class="row q-pa-md">
          <div class="col">
            <q-table
              :data="data"
              :columns="columns"
              row-key="name"
              class="bg-blue-grey-2"
              no-data-label="Load some data to Map"
            >
              <template v-slot:top class="flex flex-center row">
                <div class="row full-width">
                  <div class="col">
                    <span class="text-weight-bolder text-h6">{{orgModel}}</span>
                  </div>
                </div>
              </template>
              <template v-slot:body="props">
                <q-tr :props="props">
                  <q-td key="processdefn" :props="props" :class="props.row.class">
                    <!-- <div class="col-xs-6">
                      <q-select
                        :options="processdefn"
                        v-model="props.row.processModel"
                        placeholder="Mapping header"
                        dense
                        borderless
                        options-dense
                        @input="defnSelectHandler(props.row.processModel,props.row.id)"
                      />
                    </div>-->
                    {{props.row.processdefn}}
                  </q-td>
                  <q-td key="csvheader" :props="props">
                    <span v-if="props.row.csvheader !== null">
                      <!-- <q-select
                        placeholder="Mapping header"
                        dense
                        :options="[props.row.csvheader]"
                        v-model="props.row.csvheaderModel"
                        borderless
                        options-dense
                        :display-value="`${props.row.csvheader}`"
                      />-->
                      {{props.row.csvheader}}
                    </span>
                    <span v-else>
                      <q-select
                        :options="csvheaders"
                        v-model="props.row.csvheaderModel"
                        placeholder="Mapping header"
                        dense
                        borderless
                        options-dense
                        @input="defnSelectHandler(props.row.csvheaderModel,props.row.id,props.row.processdefn)"
                      />
                    </span>
                  </q-td>
                  <!-- <q-td key="sot" :props="props">
                    <q-checkbox
                      v-model="props.row.checkModel"
                      @input="checkboxHandler(props.row.checkModel,props.row.id)"
                    />
                  </q-td>-->
                  <q-td key="action" :props="props">
                    <q-btn
                      v-if="props.row.processdefn.includes('*')"
                      disable
                      flat
                      dense
                      color="red-14"
                      icon="far fa-trash-alt"
                    ></q-btn>
                    <q-btn
                      v-else
                      flat
                      dense
                      color="red-14"
                      icon="far fa-trash-alt"
                      @click="removeRow(props)"
                    ></q-btn>
                  </q-td>
                </q-tr>
              </template>
            </q-table>
          </div>
        </div>
        <!-- ....................     Testing comment ends ...................-->
        <!-- <div class="row no-wrap">
            <div class="col q-ma-lg" v-for="(i,index) in simple" :key="`i-${index}`">
              <q-uploader
                ref="uploader"
                url="http://localhost:7777/upload"
                :form-fields="[{name: 'system', value: `${i.label}`}]"
                :label="i.label"
                multiple
                batch
                color="blue-grey-14"
                :filter="checkFileType"
                :max-file-size="100e+7"
                style="max-width:250px"
                dark
                @added="fileAdded"
                @removed="fileRemoved"
                @start="uploadCheck"
              >
                <template v-slot:list="scope">
                  <q-list separator inset>
                    <q-item v-for="file in scope.files" :key="file.name">
                      <q-item-section>
                        <q-item-label class="full-width ellipsis text-white">{{ file.name }}</q-item-label>

                        <q-item-label caption class="text-white">Status: {{ file.__status }}</q-item-label>

                        <q-item-label
                          caption
                          class="text-white"
                        >{{ file.__sizeLabel }} / {{ file.__progressLabel }}</q-item-label>
                      </q-item-section>

                      <q-item-section v-if="file.__img" thumbnail class="gt-xs">
                        <img :src="file.__img.src">
                      </q-item-section>

                      <q-item-section top side>
                        <q-btn
                          class="gt-xs text-white"
                          size="12px"
                          flat
                          dense
                          round
                          icon="delete"
                          @click="scope.removeFile(file)"
                        />
                      </q-item-section>
                    </q-item>
                  </q-list>
                </template>
                <q-separator vertical inset/>
              </q-uploader>
            </div>
        </div>-->
        <!-- </div> -->
        <!-- ...................... Testing starts ....................... -->
        <div class="row q-pa-lg">
          <div class="col q-pr-lg">
            <q-btn
              class="float-right text-outline bg-blue-grey-3"
              @click="saveData"
              :loading="saveButtonLoader"
            >Save</q-btn>
          </div>
          <div class="col">
            <q-btn class="flex flex-center bg-blue-grey-3" @click="resetMap">Reset</q-btn>
          </div>
        </div>
        <!-- ...................... Testing ends .................... -->
      </q-step>

      <!-- <q-step
        :name="4"
        :done="step > 4"
        title="Final Check."
        icon="settings"
        style="min-height: 200px;"
        color="black"
      >
        <div class="row">
          <div
            class="col-xs-9"
          >On the right is our Enterprise KG (Knowledge Graph) structure and on the left is the columns of uploaded data.Kindly map the data with our structure.</div>
          <div class="col q-ml-lg">
            <q-select
              bottom-slots
              v-model="structureSelect"
              :options="options"
              label="Select Graph Structure"
              dense
              clearable
              hide-dropdown-icon
            >
              <template v-slot:append>
                <q-icon name="close" @click.stop="model = ''" class="cursor-pointer"/>
              </template>
            </q-select>
          </div>
        </div>
        <div class="row q-pa-lg">
          <div class="col q-pa-md">
            <q-card dark flat bordered class="bg-grey-9 my-card">
              <q-card-section>
                <div class="text-h6">Graph Structurre Visual.</div>
              </q-card-section>
              <q-separator dark inset/>
              <q-card-section>{{ lorem }}</q-card-section>
            </q-card>
          </div>
        </div>
        <div class="row q-pa-lg">
          <div class="col q-pa-md">
            <q-card flat>
              <q-tabs
                v-model="tab"
                dense
                class="bg-blue-grey-14 text-white"
                active-color="white"
                indicator-color="red"
                align="justify"
              >
                <q-tab name="mails" label="CSV1"/>
                <q-tab name="alarms" label="CSV2"/>
                <q-tab name="movies" label="CSV3"/>
              </q-tabs>

              <q-tab-panels v-model="tab" animated class="bg-blue-grey-2">
                <q-tab-panel name="mails">
                  <div class="text-h6">CSV1</div>Lorem ipsum dolor sit amet consectetur adipisicing elit.
                </q-tab-panel>

                <q-tab-panel name="alarms">
                  <div class="text-h6">CSV2</div>Lorem ipsum dolor sit amet consectetur adipisicing elit.
                </q-tab-panel>

                <q-tab-panel name="movies">
                  <div class="text-h6">CSV3</div>Lorem ipsum dolor sit amet consectetur adipisicing elit.
                </q-tab-panel>
              </q-tab-panels>
            </q-card>
          </div>
        </div>
      </q-step>-->

      <!-- <q-step
        :name="4"
        title="Final Review"
        icon="add_comment"
        style="min-height: 200px;"
        color="black"
      >Final Check.</q-step>-->

      <template v-slot:navigation>
        <q-stepper-navigation class="align-right">
          <q-btn
            @click="handleStep(step)"
            class="bg-blue-grey-14 text-white text-overline"
            :label="step === 3 ? 'Finish' : 'Continue'"
            :disable="stepHandler"
          />
          <q-btn
            v-if="step > 1"
            flat
            color="blue-grey-14"
            @click="$refs.stepper.previous()"
            label="Back"
            class="q-ml-sm text-overline"
          />
        </q-stepper-navigation>
      </template>

      <template v-slot:message>
        <q-banner
          v-if="step === 1"
          class="bg-blue-grey-14 text-white q-px-lg text-subtitle2"
        >Select necessary/all data from appropriate options.</q-banner>
        <q-banner v-else-if="step === 2" class="bg-blue-grey-14 text-white q-px-lg">Upload Data.</q-banner>
        <q-banner v-else-if="step === 3" class="bg-blue-grey-14 text-white q-px-lg">Map process.</q-banner>
        <!-- <q-banner v-else-if="step === 4" class="bg-blue-grey-14 text-white q-px-lg">Final Check.</q-banner> -->
        <!-- <q-banner v-else class="bg-blue-grey-14 text-white q-px-lg">Final Review</q-banner> -->
      </template>
    </q-stepper>
  </q-page>
</template>

<script>
import { ApiConstants } from './../const';
window._ = require("lodash");
// add load data from systems and change the route form upload to here
export default {
  data() {
    return {
      tree: null,
      saveButtonLoader: false,
      stepHandler: true,
      disableButton: false,
      buttonLoader: false,
      step: 1,
      orgModel: null,
      orgOptions: null,
      systemName: null,
      systemsAdded: null,
      structureSelect: null,
      options: ["PO", "GRN"],
      allSysFunctions: [],
      truthSystems: null,
      simple: [],
      viz: null,
      lorem:
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.",
      tab: "mails",
      ticked: [],
      truth: [],
      checkboxTicked: [],
      ticked: [],
      files: [],
      columns: [
        {
          name: "processdefn",
          align: "left",
          label: "Process Definitions ( * = mandatory)",
          classes: "text-subtitle1",
          field: "processdefn"
        },
        {
          name: "csvheader",
          label: "CSV Headers",
          align: "left",
          field: "csvheader"
        },
        // {
        //   name: "sot",
        //   align: "center",
        //   label: "Source Of Truth",
        //   field: "sot"
        // },
        {
          name: "action",
          align: "center",
          label: "Action",
          field: "action"
        }
      ],
      data: [],
      processes: ["DOMESTIC_PURCHASE_ORDER", "WORK_ORDER"],
      selectedProcess: [],
      pagination: {
        page: 1,
        rowsPerPage: 7 // 0 means all rows
      },
      filesInfo: null,
      csvheaders: [],
      selectedcsvheader: {},
      processdefnsot: {},
      row: 0,
      globalMapdata: null,
      mandatories: {},
      globalSelectedProcess: {},
      globalProcess: [],
      recheck: false,
      mandData: null,
      selectedMappings: {},
      sourceSystems: [],
      onFinishData: {},
      currentSystem: null,
      checkDefn: null
    };
  },
  created() {},
  mounted() {
    this.getOrg();
  },
  methods: {
    handleStep(step) {
      if (step === 2 && this.recheck === true) {
        this.ticked = [];
        this.$refs.stepper.next();
        this.getFilesAndFolders();
      }
      if (step === 3) {
        let counter = 0;
        for (let key of Object.keys(this.onFinishData)) {
          if (this.onFinishData[key].length > 0) {
            counter++;
            this.finishData();
            // this.finishDataTest();
            break;
          } else {
            counter++;
          }
        }
        if (counter === Object.keys(this.onFinishData).length) {
          this.$q.notify({
            color: "red-10",
            position: "top",
            textColor: "white",
            icon: "fas fa-exclamation-triangle",
            message: "Atleast one file has to be mapped."
          });
        }
      }
      this.$refs.stepper.next();
    },
    finishDataTest() {
      this.$router.push(`/dashboard`);
      this.$root.$emit("dashboard", {
        org: this.orgModel,
        process: this.selectedProcess
      });
    },
    finishData() {
      let finalObj = {};
      for (let key of Object.keys(this.onFinishData)) {
        if (this.onFinishData[key].length !== 0) {
          finalObj[key] = this.onFinishData[key];
        }
      }
      console.log(finalObj)
      this.$axios
        .post(ApiConstants.APIURL +  "collateFiles", {
          org: this.orgModel,
          fileData: finalObj
        })
        .then(response => {
          if (response.data.status === "failed") {
            this.$q.notify({
              color: "red-10",
              position: "top",
              textColor: "white",
              icon: "fas fa-exclamation-traingle",
              message: "Server error.Please try again."
            });
            this.$router.push(`/upload`);
          } else {
            let allProcesses = [];
            for (let key of Object.keys(this.onFinishData)) {
              if (this.onFinishData[key].length > 0) {
                allProcesses.push(key);
              }
            }
            this.$q.localStorage.set(
              "audire_tempProcess",
              JSON.stringify(allProcesses)
            );
            this.$axios
              .post(ApiConstants.APIURL +  "python2", {
                org: this.orgModel,
                user: this.$q.localStorage.getItem("audire_user"),
                process: allProcesses
              })
              .then(response => {
                this.$q.localStorage.set(
                  "audire_tempProcess",
                  response.data.msg
                );
              })
              .catch(err => console.error(err));
            this.$router.push(`/dashboard`);
          }
        })
        .catch(err => console.error(err));
    },
    getOrg() {
      // this.$axios.get("http://localhost:7777/org").then(repsonse => {
      //   this.orgOptions = repsonse.data.msg;
      // });
      this.orgOptions = this.$q.localStorage.getItem("audire_user_org").split();
    },
    appendSys(a) {
      if (a != null && !this.systemsAdded.includes(a)) {
        a = a.trim();
        this.systemsAdded.push(a);
      }
      this.systemName = null;
    },
    deleteSys(a) {
      this.systemsAdded.pop(a);
    },
    checkFileType(files) {
      console.log(files);
      return files.filter(file => file.type === "text/csv");
    },
    getFilesAndFolders() {
      this.$axios
        .post(ApiConstants.APIURL +  "fileandfolder", { orgName: this.orgModel })
        .then(response => {
          if (response.data.status === "success") {
            this.recheck = false;
            this.tree = response.data.msg;
          } else {
            this.recheck = true;
            this.tree = [];
          }
        });
    },
    onSubmit() {
      if (this.systemName != null && this.systemsAdded !== null) {
        this.allSysFunctions.push({
          system: this.systemName.trim(),
          functionality: this.systemsAdded.split(","),
          truth: this.truthSystems.split(",")
        });
        this.simple.push({
          label: this.systemName,
          children: [
            {
              label: this.systemName + " - " + "entities",
              children: [
                {
                  label: this.systemsAdded.includes(",")
                    ? this.systemsAdded.split(",").join(",")
                    : this.systemsAdded
                }
              ]
            },
            {
              label: this.systemName + " - " + "Source of truth",
              children: [
                {
                  label: this.truthSystems.includes(",")
                    ? this.truthSystems.split(",").join(",")
                    : this.truthSystems
                }
              ]
            }
          ]
        });
        this.onReset();
        this.$q.notify({
          color: "blue-grey-14",
          position: "top",
          textColor: "white",
          icon: "fas fa-check-circle",
          message: "Saved"
        });
      }
    },
    onReset() {
      this.systemName = null;
      this.systemsAdded = null;
      this.truthSystems = null;
    },
    onClear() {
      this.allSysFunctions = [];
      this.simple = [];
    },
    draw() {
      let config = {
        container_id: "viz",
        server_url: "bolt://54.169.129.170:7687",
        server_user: "neo4j",
        server_password: "0neintegral@123",
        labels: {
          PO_HEADER: {
            caption: "id",
            size: "pagerank",
            community: "community"
          }
        },
        relationships: {
          // INTERACTS: {
          //   thickness: "weight",
          //   caption: false
          // }
        },
        initial_cypher: "match (n:PO_HEADER)<-[]-(m) return n,m"
      };

      var viz = new NeoVis.default(config);
      viz.render();
    },
    getSystems() {
      this.$axios.get(ApiConstants.APIURL +  "systems").then(repsonse => {
        this.simple = repsonse.data.msg;
        this.simple.forEach(ele => {
          this.ticked.push({ [ele.label]: [] });
          this.truth.push({ [ele.label]: [] });
        });
      });
    },
    async tickHandler() {
      this.checkboxTicked = [];
      let list = [];
      let name = null;
      await this.ticked.forEach(obj => {
        name = Object.keys(obj)[0];
        list = [];
        if (obj[Object.keys(obj)[0]].length !== 0) {
          obj[Object.keys(obj)[0]].forEach(process => {
            list.push({ label: process });
          });
          this.checkboxTicked.push({ label: name, children: list });
        } else {
          this.checkboxTicked.push({
            label: name,
            children: list,
            disabled: true
          });
          _.find(this.truth, name)[`${name}`] = [];
        }
      });
      // console.log(this.checkboxTicked);
    },
    truthHandler() {
      let coll = [];
      this.truth.forEach(obj => {
        coll.push(obj[Object.keys(obj)[0]]);
      });
      let interCol = _.intersection(...coll);
      if (interCol.length > 0) {
        this.$q.notify({
          color: "red-9",
          position: "top",
          textColor: "white",
          icon: "fas fa-exclamation-triangle",
          message: "Duplicate source of truth found!."
        });
        this.truth.forEach(obj2 => {
          obj2[Object.keys(obj2)[0]] = _.without(
            obj2[Object.keys(obj2)[0]],
            ...interCol
          );
        });
      }
    },
    verifyStep(next) {
      if (this.checkboxTicked.length > 0) {
        this.checkboxTicked.forEach(obj => {
          if (obj.children.length > 0) {
            next();
          } else {
            this.$q.notify({
              color: "blue-grey-14",
              position: "top",
              textColor: "white",
              icon: "fas fa-check-circle",
              message: "Please select Systems"
            });
          }
        });
      } else {
        this.$q.notify({
          color: "blue-grey-14",
          position: "top",
          textColor: "white",
          icon: "fas fa-check-circle",
          message: "Please select Systems"
        });
      }
    },
    fileAdded(file) {
      Object.keys(file).forEach(key => {
        this.files.push(file[key]);
      });
    },
    fileRemoved(file) {
      this.files.splice(this.files.indexOf(file[0].name, 1));
    },
    uploadCheck(info) {
      if (JSON.parse(info.xhr.response).status === "success") {
        this.recheck = true;
        this.$q.notify({
          color: "green-10",
          position: "bottom-right",
          textColor: "white",
          icon: "fas fa-check-circle",
          message: "Upload Successful!."
        });
      } else {
        this.$q.notify({
          color: "red-9",
          position: "bottom-wight",
          textColor: "white",
          icon: "fas fa-exclamation-triangle",
          message: "Upload Failed!"
        });
      }
    },
    loadData() {
      if (this.ticked.length === 1 && this.selectedProcess.length > 0) {
        this.resetData();
        this.$axios
          .post(ApiConstants.APIURL +  "checkHeaders", {
            orgName: this.orgModel,
            fileNames: this.ticked
          })
          .then(response => {
            if (response.data.status === "failed") {
              this.$q
                .dialog({
                  title: "Warning",
                  message:
                    response.data.msg +
                    "Delete the selected files and reupload?",
                  cancel: true,
                  persistent: true,
                  color: "grey-10"
                })
                .onOk(() => {
                  this.$axios
                    .post(ApiConstants.APIURL +  "deleteFiles", {
                      orgName: this.orgModel,
                      fileNames: this.ticked
                    })
                    .then(response => {
                      this.recheck = true;
                      this.$refs.stepper.previous();
                    });
                })
                .onCancel(() => {});
            } else {
              this.currentSystem = response.data.system;
              this.csvheaders = response.data.headers[0]; // tried array destructuring but was a headache, so took the first element bcz i knew it is thr
              let normalData = [];
              this.data = [];
              this.mandData = [];
              this.selectedcsvheader = {};
              this.$q
                .dialog({
                  title: "Success",
                  message: response.data.msg,
                  cancel: true,
                  persistent: true,
                  color: "grey-10"
                })
                .onOk(() => {
                  // console.log(this.csvheaders);
                  this.$axios
                    .post(ApiConstants.APIURL +  "processdefn", {
                      processName: this.selectedProcess
                    })
                    .then(response => {
                      // this.processdefn = response.data.msg; // Original code
                      // Modified for mandatory addition
                      let counters = [];
                      for (let message of response.data.msg) {
                        if (message.mandatory === 1) {
                          let tempid = `row${this.row++}`;
                          this.mandData.push({
                            id: tempid,
                            csvheader: (() => {
                              if (this.csvheaders.includes(message.name)) {
                                this.csvheaders.splice(
                                  this.csvheaders.indexOf(message.name),
                                  1
                                );
                                counters.push({
                                  val: message.name,
                                  id: tempid,
                                  processdefn: message.name + "*"
                                });
                                return message.name;
                              } else {
                                return null;
                              }
                            })(),
                            csvheaderModel: [],
                            processdefn: message.name + "*",
                            // sot: null,
                            class: "text-weight-bolder text-red",
                            checkModel: false,
                            action: null,
                            sourceSys: null // fileObj['source']
                          });
                        } else {
                          let tempid = `row${this.row++}`;
                          normalData.push({
                            id: tempid,
                            csvheader: (() => {
                              if (this.csvheaders.includes(message.name)) {
                                this.csvheaders.splice(
                                  this.csvheaders.indexOf(message.name),
                                  1
                                );
                                counters.push({
                                  val: message.name,
                                  id: tempid,
                                  processdefn: message.name
                                });
                                return message.name;
                              } else {
                                return null;
                              }
                            })(),
                            csvheaderModel: [],
                            processdefn: message.name,
                            // sot: null,
                            checkModel: false,
                            action: null,
                            sourceSys: null // fileObj['source']
                          });
                        }
                      }
                      let temp = this.mandData.slice();
                      this.data = temp;
                      this.data.push(...normalData);
                      if (counters.length > 0) {
                        for (let c of counters) {
                          this.defnSelectHandler(c.val, c.id, c.processdefn);
                        }
                      }
                    });
                });
            }
          });
      } else if (this.selectedProcess.length > 0 && this.ticked.length > 1) {
        this.$q.notify({
          color: "red-9",
          position: "top",
          textColor: "white",
          icon: "fas fa-exclamation-triangle",
          message: "Only one file at a time can be Mapped."
        });
      } else {
        this.$q.notify({
          color: "red-9",
          position: "top",
          textColor: "white",
          icon: "fas fa-exclamation-triangle",
          message: "Pl. Select a Single File & process."
        });
      }
      // this.buttonLoader = true;
      // this.loading = true;
      // this.$axios
      //   .post("http://localhost:7777/load", { orgName: this.orgModel })
      //   .then(response => {
      //     if (response.data.status === "success") {
      //       this.disableButton = true;
      //       this.filesInfo = response.data.msg;
      //       this.filesInfo.forEach(fileObj => {
      //         Object.keys(fileObj).forEach(key => {
      //           if (key !== "source")
      //             fileObj[key].forEach(header => {
      //               this.data.push({
      //                 id: `row${this.row++}`,
      //                 csvheader: header,
      //                 processdefn: null,
      //                 sot: null,
      //                 processModel: [],
      //                 checkModel: false,
      //                 action: null,
      //                 sourceSys: fileObj["source"]
      //               });
      //             });
      //         });
      //       });
      //       this.loading = false;
      //       this.buttonLoader = false;
      //     } else {
      //       console.log("error in data loading!.");
      //     }
      //   });
    },
    orgHandler() {
      this.$q.loading.show({
        message: "Fetching Systems and Process.Pls Wait!!!.",
        spinner: "QSpinnerPie",
        spinnerColor: "orange-10",
        backgroundColor: "grey-5",
        messageColor: "black"
      });
      this.getSysandProc();
      this.getFilesAndFolders();
    },
    getSysandProc() {
      this.$axios
        .post(ApiConstants.APIURL +  "sysProc", { orgName: this.orgModel })
        .then(response => {
          this.$q.loading.hide();
          this.simple = response.data.sys;
          this.processes = _.uniq(response.data.proc);
          for (let process of this.processes) {
            this.onFinishData[process] = [];
          }
        });
    },
    selectHandler() {
      let defnHeaders = null;
      this.mandatories = {};
      this.processdefn = [];
      this.mandatories[this.selectedProcess] = [];
      this.$axios
        .post(ApiConstants.APIURL +  "processdefn", {
          processName: this.selectedProcess
        })
        .then(response => {
          // this.processdefn = response.data.msg; // Original code
          // Modified for mandatory addition
          response.data.msg.forEach(msg => {
            if (msg["mandatory"] !== null) {
              this.mandatories[this.selectedProcess].push(msg["name"]);
              this.processdefn.push(msg["name"] + " " + "*");
            } else {
              this.processdefn.push(msg["name"]);
            }
          });
          this.globalSelectedProcess[this.selectedProcess] === undefined
            ? (this.globalSelectedProcess[this.selectedProcess] = [])
            : null;
        });
      // above code is to pass to python server
    },
    defnSelectHandler(val, id, processdefn) {
      this.selectedcsvheader[id] = val;
      this.selectedMappings[id] = val;
      // this.selectedcsvheader[id + "_process"] = this.selectedProcess;
      // this.selectedcsvheader[this.selectedProcess].push(val);
      Object.keys(this.selectedcsvheader).forEach(key => {
        if (key !== id) {
          if (this.selectedcsvheader[key] === val) {
            _.find(this.data, { id: key })["csvheaderModel"] = null;
            _.find(this.data, { id: id })["csvheaderModel"] = null;
            // this.selectedcsvheader[id] = null;
            // this.selectedcsvheader[key] = null;
            delete this.selectedcsvheader[id];
            delete this.selectedcsvheader[key];
            delete this.selectedMappings[id];
            delete this.selectedMappings[key];
            this.$q.notify({
              color: "red-9",
              position: "top",
              textColor: "white",
              icon: "fas fa-exclamation-triangle",
              message: "Can't set multiple headers."
            });
            return true;
          }
        } else {
        }
      });
    },
    checkboxHandler(val, id) {
      this.processdefnsot[id] = val;
    },
    saveData() {
      let csvkeycount = 0;
      let mandcount = this.mandData.length;
      for (let key of Object.keys(this.selectedcsvheader)) {
        if (_.find(this.mandData, { id: key })) {
          csvkeycount++;
        }
      }
      if (csvkeycount === mandcount) {
        let csvCols = [];
        let mappedProcessDefns = [];
        // let sot = [];
        for (let key of Object.keys(this.selectedMappings)) {
          mappedProcessDefns.push(
            _.find(this.data, { id: key })["processdefn"].replace("*", "")
          );
          csvCols.push(this.selectedcsvheader[key]);
          // this.processdefnsot[key] === undefined
          //   ? sot.push(false)
          //   : sot.push(this.processdefnsot[key]);
        }
        // calculating only for thre remainign data other than compulsory mapped mandatories.
        if (
          Object.keys(this.selectedMappings).length - csvkeycount === 0 &&
          this.data.length - mandcount !== 0
        ) {
          this.$q
            .dialog({
              title: "Warning",
              message:
                "Necessary CSV columns Mapped.Please remove unmapped rows to continue",
              cancel: true,
              persistent: true,
              color: "grey-10"
            })
            .onOk(() => {})
            .onCancel(() => {});
        } else if (
          Object.keys(this.selectedMappings).length - csvkeycount > 0 &&
          this.data.length - mandcount !==
            Object.keys(this.selectedMappings).length - csvkeycount
        ) {
          this.$q
            .dialog({
              title: "Warning",
              message: "Please remove unmapped rows to continue",
              cancel: true,
              persistent: true,
              color: "grey-10"
            })
            .onOk(() => {})
            .onCancel(() => {});
        } else {
          this.$axios
            .post(ApiConstants.APIURL +  "mappedcsv", {
              config: JSON.stringify(_.zip(csvCols, mappedProcessDefns)),
              orgName: this.orgModel,
              processName: this.selectedProcess,
              sys: this.currentSystem,
              fileName: this.ticked[0]
            })
            .then(response => {
              this.$q.notify({
                color: "teal-10",
                position: "top",
                textColor: "white",
                icon: "fas fa-check-circle",
                message: "Data Saved successfully!"
              });
              // let sys = this.ticked[0].split("__")[0];
              // let obj = _.find(this.tree, { label: sys }).children;
              // let filename = _.find(obj, { label: this.ticked[0] }).label;
              // _.find(obj, { label: filename }).label += `_(mapped)`;
              this.onFinishData[this.selectedProcess].push(
                response.data.filename.split("/").pop()
              );
              this.resetMap();
            });
        }
      } else {
        if (
          this.mandData.length === 0 &&
          this.csvheaders.length !== this.data.length
        ) {
          this.$q
            .dialog({
              title: "Warning",
              message: "Please remove unmapped rows to continue",
              cancel: true,
              persistent: true,
              color: "grey-10"
            })
            .onOk(() => {})
            .onCancel(() => {});
        } else {
          this.$q.notify({
            color: "red-9",
            position: "bottom-right",
            textColor: "white",
            icon: "fas fa-exclamation-triangle",
            message: "All mandatories must be selected"
          });
        }
      }
    },
    saveMap() {
      // Need to check for resert and save after scenario
      let condition = false;
      let mandCounter = 0;
      let finalCounter = 0;

      for (let j of Object.keys(this.mandatories)) {
        finalCounter += this.mandatories[j].length;
      }
      Object.keys(this.selectedProcessdefn).forEach(key => {
        // console.log(this.selectedProcessdefn[key]);
        for (let i of Object.keys(this.mandatories)) {
          if (
            // this.selectedProcessdefn[key] !== null &&
            _.includes(
              this.mandatories[i],
              this.selectedProcessdefn[key].replace("*", "").trim()
            ) &&
            this.selectedProcessdefn[key + "_process"] !== i
          ) {
            mandCounter++;
            // console.log(`inside for each : counter${counter}`);
          }
        }
      });
      // if (mandCounter === finalCounter) {
      // console.log(`Inside if : counter ${counter}`);
      if (
        mandCounter === finalCounter &&
        Object.keys(this.selectedProcessdefn).length === this.data.length &&
        Object.keys(this.selectedProcessdefn).length > 0 &&
        this.data.length > 0
      ) {
        this.saveButtonLoader = true;
        let headers = [],
          mappedHeaders = [],
          sotData = [],
          source = [],
          processnames = [],
          counter = 0;
        this.data.forEach(header => {
          headers.push(header["csvheader"]);
          source.push(header["sourceSys"]);
        });
        Object.keys(this.selectedProcessdefn).forEach(key => {
          if (this.selectedProcessdefn[key] !== null) {
            counter++;
            mappedHeaders.push(this.selectedProcessdefn[key]);
            this.processdefnsot[key] === undefined
              ? sotData.push(false)
              : sotData.push(this.processdefnsot[key]);
          } else {
            // possible issues here : notifies based on number of null values
            this.$q.notify({
              color: "red-9",
              position: "bottom-right",
              textColor: "white",
              icon: "fas fa-exclamation-triangle",
              message: "One or more mappings missing!."
            });
          }
        });
        if (counter === this.data.length) {
          this.globalMapdata = _.zip(headers, mappedHeaders, sotData, source);
          for (let key of Object.keys(this.selectedProcessdefn)) {
            for (let ele of mappedHeaders) {
              if (
                (_.includes(this.globalSelectedProcess[key], ele) &&
                  _.includes(this.selectedProcessdefn[key]),
                ele)
              ) {
                this.globalProcess.push(key);
                break;
              }
            }
          }
          this.$axios
            .post(ApiConstants.APIURL +  "mappedcsv", {
              config: JSON.stringify(this.globalMapdata),
              orgName: this.orgModel
            })
            .then(response => {
              this.saveButtonLoader = false;
              this.$q.notify({
                color: "teal-10",
                position: "top",
                textColor: "white",
                icon: "fas fa-check-circle",
                message: "Data Mapped successfully!"
              });
              this.$router.push("/dashboard");
            });
        } else {
        }
      } else {
        // console.log(this.selectedProcessdefn);

        this.$q.notify({
          color: "red-9",
          position: "bottom-right",
          textColor: "white",
          icon: "fas fa-exclamation-triangle",
          message: "One or more mappings/mandatory fields missing!"
        });
      }
      // } else {
      //   // console.log(`counter :${counter} final Counter : ${finalCounter}`);
      //   this.$q.notify({
      //     color: "red-9",
      //     position: "bottom-right",
      //     textColor: "white",
      //     icon: "fas fa-exclamation-triangle",
      //     message: "Please select all mandatory fields."
      //   });
      // }
    },
    resetData() {
      this.data = [];
      this.csvheaders = [];
      this.selectedcsvheader = {};
      this.processdefnsot = {};
      this.mandData = null;
      this.selectedMappings = {};
    },
    resetMap() {
      this.data = [];
      this.disableButton = false;
      this.processdefn = [];
      // this.filesInfo.forEach(fileObj => {
      //   Object.keys(fileObj).forEach(key => {
      //     fileObj[key].forEach(header => {
      //       this.data.push({
      //         id: `row${this.row++}`,
      //         csvheader: header,
      //         processdefn: null,
      //         sot: null,
      //         processModel: [],
      //         checkModel: false,
      //         action: null
      //       });
      //     });
      //   });
      // });
      this.filesInfo = null;
      this.selectedProcessdefn = {};
      this.processdefnsot = {};
      this.selectedProcess = [];
      this.ticked = [];
    },
    removeRow(prop) {
      delete this.selectedcsvheader[prop.row.id];
      this.data.splice(
        this.data.indexOf(
          _.find(this.data, { processdefn: prop.row.processdefn })
        ),
        1
      );
    }
  },
  computed: {
    _() {
      return _;
    }
  },
  watch: {
    orgModel(val) {
      this.stepHandler = false;
    },
    checkDefn(val) {
      if (val !== null) {
        this.defnSelectHandler(val.val, val.id, val.processdefn);
      }
    }
  }
};
</script>

<style scoped>
</style>
