<template>
  <q-page class="q-pa-md">
    <div class="row">
      <div class="col-xs-6 offset-xs-3">
        <q-card bordered class="bg-grey-2 q-mt-lg" flat>
          <q-card-section>
            <div class="text-h6 text-center">Please enter your Registered E-mail</div>
          </q-card-section>
          <q-separator inset class="grey-10" />
          <q-card-section>
            <div class="row">
              <div class="col-xs-9 q-mr-md">
                <q-input
                  dense
                  filled
                  type="email"
                  v-model="resetEmail"
                  placeholder="Enter E-mail "
                  lazy-rules
                  @keydown.space.prevent
                  :rules="[ val => val && val.length > 0 || 'Please type something']"
                />
              </div>
              <div class="col">
                <q-btn label="Submit" @click="passReset" color="primary" flat></q-btn>
              </div>
            </div>
          </q-card-section>
        </q-card>
      </div>
    </div>
  </q-page>
</template>

<script>
import { ApiConstants } from './../const';
import { EventBus } from "./event-bus.js";
export default {
  name: "passwordReset",
  data() {
    return {
      resetEmail: null
    };
  },
  methods: {
    passReset() {
      const payload = {
        email: this.resetEmail
      };
      this.$axios
        .post(ApiConstants.LOGINAPIURL +  "passwordReset", payload)
        .then(response => {
          if (response.data.status === "failed") {
            this.$q.notify({
              color: "red-2",
              position: "top-right",
              textColor: "black",
              icon: "fas fa-exclamation",
              message: response.data.message
            });
          } else {
            this.$q.notify({
              color: "green-2",
              position: "top-right",
              textColor: "black",
              icon: "fas fa-exclamation",
              message: `Password Reset link sent to the provided e-mail.`
            });
          }
        })
        .catch(err => console.log(err));
    }
  },
  created() {}
};
</script>

<style scoped>
</style>