<template>
  <q-page>
    <div class="flex items-center items-baseline">
      <div class="px-12 py-8 w-5/12">
        <div class="rounded-l-lg border-b-2" style="border-color:#022C4C">
          <span class="text-lg font-sans font-semibold tracking-widest text-gray-700">{{orgModel}}</span>
        </div>
      </div>
      <div class="flex items-center w-7/12 justify-end justify-center justify-around px-12">
        <div class="bg-grey-1 rounded-full">
          <q-select
            rounded
            hide-bottom-space
            outlined
            v-model="companyModel"
            :options="companyOptions"
            label="Company"
            class="w-auto"
            size="sm"
            dense
            style="min-width:8rem"
            options-dense
            transition-show="jump-up"
            transition-hide="jump-up"
          />
        </div>
        <div class="bg-grey-1 rounded-full">
          <q-select
            rounded
            outlined
            hide-bottom-space
            v-model="branchModel"
            :options="branchOptions"
            label="Branch"
            class="w-auto"
            size="md"
            dense
            style="min-width:8rem"
            options-dense
            transition-show="jump-up"
            transition-hide="jump-up"
          />
        </div>
        <div class="bg-grey-1 rounded-full">
          <q-select
            rounded
            outlined
            hide-bottom-space
            v-model="processModel"
            :options="processOptions"
            label="Process"
            class="w-auto"
            size="md"
            style="min-width:8rem"
            dense
            options-dense
            transition-show="jump-up"
            transition-hide="jump-up"
          />
        </div>
        <!-- <div class="px-4 m-1">
          <router-link to="/dashboard">
            <q-btn
              dense
              unelevated
              no-caps
              flat
              rounded
              size="md"
              class="w-24"
              style="background-color:#022C4C"
            >
              <span class="text-bold-soft text-gray-100 tracking-wide">View</span>
            </q-btn>
          </router-link>
        </div>-->
      </div>
    </div>
    <div class="flex items-baseline justify-end">
      <div class="w-9/12">
        <div class="px-12 py-1">
          <div class="border-b-4 border-gray-400">
            <span class="text-lg font-sans font-bold tracking-wider text-gray-700">Upload Files</span>
          </div>
          <div class="flex items-center px-12 py-4">
            <div v-for="(i,index) in simple" :key="`i-${index}`" class="pr-12 py-2">
              <q-uploader
                ref="uploader"
                url="http://localhost:7777/upload"
                :form-fields="[{name: 'system', value: `${i}`},{name:'orgName',value:orgModel}]"
                :label="i[0]+ i.slice(1).toLowerCase()"
                multiple
                flat
                bordered
                class
                accept="csv"
                :max-file-size="100e+7"
                @added="fileAdded"
                @removed="fileRemoved"
                @uploaded="info => {uploadCheck(info)}"
              >
                <template v-slot:list="scope">
                  <q-list separator inset>
                    <q-item v-for="file in scope.files" :key="file.name">
                      <q-item-section>
                        <q-item-label>
                          <span class="font-bold text-md tacking-wide text-gray-700">{{ file.name }}</span>
                        </q-item-label>

                        <q-item-label>
                          <div class="pt-3">
                            <span class="font-bold tracking-wide text-sm text-gray-500">
                              status:
                              <span
                                v-if="file.__status === 'failed'"
                                class="rounded-full bg-red-3 px-3 font-black text-gray-600"
                              >{{ file.__status }}</span>
                              <span
                                v-if="file.__status === 'idle'"
                                class="rounded-full bg-amber-4 px-3 font-black text-gray-600"
                              >{{ file.__status }}</span>
                              <span
                                v-if="file.__status === 'uploading'"
                                class="rounded-full bg-indigo-4 px-3 font-black text-gray-600"
                              >{{ file.__status }}</span>
                              <span
                                v-if="file.__status === 'uploaded'"
                                class="rounded-full bg-green-4 px-3 font-black text-gray-600"
                              >{{ file.__status }}</span>
                            </span>
                          </div>
                        </q-item-label>

                        <q-item-label>
                          <span
                            class="font-bold-soft tracking-wide text-sm text-gray-500"
                          >{{ file.__sizeLabel }} / {{ file.__progressLabel }}</span>
                        </q-item-label>
                      </q-item-section>

                      <q-item-section v-if="file.__img" thumbnail class>
                        <img :src="file.__img.src" />
                      </q-item-section>

                      <q-item-section top side>
                        <q-btn
                          size="10px"
                          flat
                          dense
                          round
                          icon="fas fa-trash-alt"
                          @click="scope.removeFile(file)"
                        />
                      </q-item-section>
                    </q-item>
                  </q-list>
                </template>
              </q-uploader>
            </div>
          </div>
        </div>
        <div class="px-12 py-1">
          <div class="border-b-4 border-gray-400">
            <span class="text-lg font-sans font-bold tracking-wider text-gray-700">Uploaded files</span>
          </div>
          <div class="px-12 py-4">
            <q-tree
              :nodes="tree"
              icon="fas fa-angle-right"
              node-key="label"
              no-nodes-label="No Data available."
              no-results-label="No Results available"
              tick-strategy="leaf"
              :ticked.sync="ticked"
              color="primary"
              control-color="primary"
              text-color="primary"
              selected-color="primary"
              accordion
              class="text-md tracking-wide font-semibold-soft"
              :duration="200"
              @update:ticked="tickHandler()"
            />
          </div>
        </div>
        <div class="px-12 py-1">
          <div class="border-b-4 border-gray-400">
            <span
              class="text-lg font-sans font-bold tracking-wider text-gray-700"
            >Mapping of Fields (Automated if the CSV headers are not tampered with)</span>
          </div>
          <div class="px-12 py-6">
            <q-table
              :data="data"
              :columns="columns"
              row-key="name"
              class="bg-grey-1"
              flat
              bordered
              :loading="tableLoader"
              no-data-label="Load some data to Map"
            >
              <template v-slot:top-left>
                <div>
                  <span
                    v-if="ticked[0] !== undefined"
                    class="text-gray-700 text-md font-semibold tracking-wide"
                  >{{ticked[0]}}</span>
                  <span
                    v-else
                    class="text-gray-700 text-md font-semibold tracking-wide ellipsis"
                  >File name</span>
                </div>
              </template>
              <template v-slot:top-right>
                <div v-if="ticked[0] !== undefined">
                  <q-btn
                    dense
                    unelevated
                    no-caps
                    flat
                    rounded
                    size="md"
                    class="w-24 m-auto"
                    style="background-color:#022C4C"
                    @click="deleteFile(ticked)"
                  >
                    <span class="text-bold-soft text-gray-100 tracking-wide">Delete</span>
                  </q-btn>
                </div>
                <div v-else>
                  <q-btn
                    dense
                    unelevated
                    no-caps
                    flat
                    rounded
                    disable
                    size="md"
                    class="w-24 m-auto"
                    style="background-color:#022C4C"
                    @click="deleteFile"
                  >
                    <span class="text-bold-soft text-gray-100 tracking-wide">Delete</span>
                  </q-btn>
                </div>
              </template>
              <template v-slot:body="props">
                <q-tr :props="props">
                  <q-td
                    key="processdefn"
                    :props="props"
                    :class="props.row.class"
                  >{{props.row.processdefn}}</q-td>
                  <q-td key="csvheader" :props="props">
                    <span v-if="props.row.csvheader !== null">{{props.row.csvheader}}</span>
                    <span v-else>
                      <q-select
                        :options="csvheaders"
                        v-model="props.row.csvheaderModel"
                        placeholder="Mapping header"
                        dense
                        borderless
                        options-dense
                        @input="defnSelectHandler(props.row.csvheaderModel,props.row.id,props.row.processdefn)"
                      />
                    </span>
                  </q-td>
                  <q-td key="action" :props="props">
                    <q-btn
                      v-if="props.row.processdefn.includes('*')"
                      disable
                      flat
                      dense
                      color="red-14"
                      icon="far fa-trash-alt"
                    ></q-btn>
                    <q-btn
                      v-else
                      flat
                      dense
                      color="red-14"
                      icon="far fa-trash-alt"
                      @click="removeRow(props)"
                    ></q-btn>
                  </q-td>
                </q-tr>
              </template>
            </q-table>
          </div>
          <div class="flex">
            <q-btn
              dense
              unelevated
              no-caps
              flat
              rounded
              size="md"
              class="w-24 m-auto"
              style="background-color:#022C4C"
              @click="saveData"
              :disable="saveDisable"
            >
              <span class="text-bold-soft text-gray-100 tracking-wide">Save</span>
            </q-btn>
          </div>
        </div>
        <div class="px-12 py-1">
          <div class="border-b-4 border-gray-400">
            <span class="text-lg font-sans font-bold tracking-wider text-gray-700">Finish</span>
          </div>
          <div class="px-12 py-6" v-if="showFinish">
            <div>
              <dl class="py-2" v-for="(process,index) in Object.keys(desc)" :key="process+index">
                <dt class="pb-2">
                  <span
                    class="text-gray-700 text-md font-semibold tracking-wide border-b-2 border-gray-900"
                  >{{process}} :</span>
                </dt>
                <dd v-for="(file,index) in desc[process]" :key="file+index">
                  <div class="flex items-center items-baseline">
                    <div class="px-2">
                      <q-icon name="fas fa-check-circle" size="12px" />
                    </div>
                    <div>
                      <span class="text-gray-700 text-md font-semibold-soft px-3">{{file}}</span>
                    </div>
                    <div>
                      <q-btn
                        round
                        flat
                        size="8px"
                        color="primary"
                        icon="fas fa-trash"
                        @click="deleteFile([file],process)"
                      />
                    </div>
                  </div>
                </dd>
              </dl>
            </div>
            <div class="flex">
              <q-btn
                dense
                unelevated
                no-caps
                flat
                rounded
                size="md"
                class="w-24 m-auto"
                style="background-color:#022C4C"
                @click="finishData"
              >
                <span class="text-bold-soft text-gray-100 tracking-wide">Finish</span>
              </q-btn>
            </div>
          </div>
          <div class="px-12 py-6" v-else>
            <div
              class="p-1 flex justify-center bg-grey-1 border-b border-gray-400 m-auto rounded-lg"
            >
              <span
                class="p-1 text-lg font-black text-gray-600 m-auto text-center"
              >Finished mappings</span>
            </div>
          </div>
        </div>
      </div>
      <div class="w-3/12">
        <div class="px-6 py-2">
          <div class="flex flex-col">
            <div
              class="text-xl text-bold-soft tracking-wider text-center text-gray-200 px-2 pt-1 rounded-t-lg"
              style="background-color:#022C4C"
            >Templates</div>
            <div v-if="processModel !==null">
              <div
                class="bg-grey-1 px-2 border-b border-gray-400"
                v-for="(i,index) in processTemplates"
                :key="i+index"
              >
                <div class="flex justify-between items-baseline pl-4">
                  <div>
                    <span class="text-md font-sans font-semibold text-gray-700">{{i}}</span>
                  </div>
                  <div>
                    <q-btn
                      size="11px"
                      flat
                      round
                      @click="downloadFile(i)"
                      icon="fas fa-arrow-circle-down"
                    ></q-btn>
                  </div>
                </div>
                <div class="py-1 pl-4">
                  <span class="text-md font-black-soft text-gray-600 tracking-wide">{{i}}</span>
                </div>
              </div>
            </div>
            <div v-if="processModel === null">
              <div class="p-4 flex justify-center bg-grey-1 border-b border-gray-400 m-auto">
                <span
                  class="p-4 text-lg font-black text-gray-500 m-auto text-center"
                >Select a process above</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </q-page>
</template>

<script>
import { ApiConstants } from './../const';
import { CLIENT_RENEG_LIMIT } from "tls";
window._ = require("lodash");
export default {
  data() {
    return {
      companyModel: null,
      tableLoader: false,
      companyOptions: null,
      branchModel: null,
      branchOptions: null,
      orgModel: null,
      simple: null,
      processModel: null,
      processOptions: null,
      tree: [],
      ticked: [],
      columns: [
        {
          name: "processdefn",
          align: "left",
          label: "Process defn. ( * = required)",
          style:
            "color:#2d3748;	font-size: 1rem;	font-weight: 800;letter-spacing: 0.025em;	line-height: 2;width: 41.666667%;		justify-content: center;",
          field: "processdefn"
        },
        {
          name: "csvheader",
          label: "Csv headers",
          align: "left",
          field: "csvheader",
          style:
            "color:#2d3748;	font-size: 1rem;	font-weight: 800;letter-spacing: 0.025em;	line-height: 2;	width: 41.666667%;		justify-content: center;"
        },
        {
          name: "action",
          align: "center",
          label: "Action",
          field: "action",
          style:
            "color:#2d3748;	font-size: 1rem;	font-weight: 800;letter-spacing: 0.025em;	line-height: 2;		width: 16.666667%;	justify-content: center;"
        }
      ],
      data: [],
      csvheaders: null,
      selectedcsvheader: {},
      normalData: [],
      selectedMappings: {},
      currentSystem: null,
      mandData: [],
      row: 0,
      mandIds: [],
      files: [],
      desc: {},
      sysDesc: {},
      saveDisable: true,
      showFinish: false,
      processTemplates: null
    };
  },
  methods: {
    fileAdded(file) {
      Object.keys(file).forEach(key => {
        this.files.push(file[key]);
      });
    },
    fileRemoved(file) {
      this.files.splice(this.files.indexOf(file[0].name, 1));
    },
    uploadCheck(info) {
      if (JSON.parse(info.xhr.response).status === "success") {
        this.recheck = true;
        this.getFilesAndFolders();
        this.$q.notify({
          color: "green-2",
          position: "top-right",
          textColor: "black",
          icon: "fas fa-check-circle",
          message: "Upload successful",
          classes: "text-gray-800 tracking-wide text-semibold text-md",
          timeout: 1000
        });
      } else {
        this.$q.notify({
          color: "amber-2",
          position: "top-right",
          textColor: "black",
          icon: "fas fa-exclamation",
          message: "Upload failed"
        });
      }
    },
    getSysandProc() {
      if (this.$q.localStorage.getItem("moduleAndProcess")) {
        let process = [];
        let system = [];
        let temp = JSON.parse(this.$q.localStorage.getItem("moduleAndProcess"));
        Object.keys(temp).forEach(key => {
          temp[key].forEach(obj => {
            process.push(obj.process);
            system.push(obj.system);
          });
          this.simple = _.uniq(system);
          this.processOptions = process;
        });
      } else {
        this.$axios
          .post(ApiConstants.APIURL +  "sysProc", { orgName: this.orgModel })
          .then(response => {
            this.simple = response.data.sys.sort();
            this.processOptions = _.uniq(response.data.proc);
          });
      }
    },
    getFilesAndFolders() {
      this.$axios
        .post(ApiConstants.APIURL +  "fileandfolder", {
          orgName: this.orgModel
        })
        .then(response => {
          if (response.data.status === "success") {
            // this.recheck = false;
            this.tree = response.data.msg;
          } else {
            // this.recheck = true;
            this.tree = [];
          }
        });
    },
    tickHandler() {
      this.ticked = [this.ticked.pop()];
    },
    async loadData() {
      this.resetData();
      let result = await this.$axios.post(
        ApiConstants.APIURL +  "checkHeaders",
        {
          orgName: this.orgModel,
          fileNames: this.ticked
        }
      );
      if (result.data.status === "failed") {
        this.$q.notify({
          color: "red-2",
          position: "top-right",
          textColor: "black",
          icon: "fas fa-exclamation",
          message: "Unknown error.Contact support"
        });
      } else {
        this.currentSystem = result.data.system;
        this.csvheaders = result.data.headers[0]; // tried array destructuring but was a headache, so took the first element bcz i knew it is thr
        let normalData = [];
        let counters = [];
        let processdefnResult = await this.$axios.post(
          ApiConstants.APIURL +  "processdefn",
          {
            processName: this.processModel,
            org: this.orgModel
          }
        );
        for (let message of processdefnResult.data.msg) {
          if (message.mandatory === 1) {
            let tempid = `row${this.row++}`;
            this.mandIds.push(tempid);
            this.mandData.push({
              id: tempid,
              csvheader: (() => {
                if (this.csvheaders.includes(message.name)) {
                  this.csvheaders.splice(
                    this.csvheaders.indexOf(message.name),
                    1
                  );
                  counters.push({
                    val: message.name,
                    id: tempid,
                    processdefn: message.name + "*"
                  });
                  return message.name;
                } else {
                  return null;
                }
              })(),
              csvheaderModel: [],
              processdefn: message.name + "*",
              // sot: null,
              class: "text-red-700",
              checkModel: false,
              action: null,
              sourceSys: null // fileObj['source']
            });
          } else {
            let tempid = `row${this.row++}`;
            normalData.push({
              id: tempid,
              csvheader: (() => {
                if (this.csvheaders.includes(message.name)) {
                  this.csvheaders.splice(
                    this.csvheaders.indexOf(message.name),
                    1
                  );
                  counters.push({
                    val: message.name,
                    id: tempid,
                    processdefn: message.name
                  });
                  return message.name;
                } else {
                  return null;
                }
              })(),
              csvheaderModel: [this.csvheader],
              processdefn: message.name,
              // sot: null,
              checkModel: false,
              action: null,
              sourceSys: null // fileObj['source']
            });
          }
        }
        let temp = this.mandData.slice();
        this.data = temp;
        this.data.push(...normalData);
        if (counters.length > 0) {
          for (let c of counters) {
            this.defnSelectHandler(c.val, c.id, c.processdefn);
          }
        }
      }
    },
    defnSelectHandler(val, id, processdefn) {
      this.selectedMappings[id] = val;
      this.selectedcsvheader[id] = processdefn;
      Object.keys(this.selectedMappings).forEach(key => {
        if (key !== id) {
          if (this.selectedMappings[key] === val) {
            _.find(this.data, { id: key })["csvheaderModel"] = null;
            _.find(this.data, { id: id })["csvheaderModel"] = null;
            delete this.selectedMappings[id];
            delete this.selectedMappings[key];
            delete this.selectedcsvheader[id];
            delete this.selectedcsvheader[key];
            this.$q.notify({
              color: "amber-2",
              position: "top-right",
              textColor: "black",
              icon: "fas fa-exclamation",
              message: "Can't set multiple headers"
            });
            return true;
          }
        } else {
        }
      });
    },
    resetData() {
      this.data = [];
      this.csvheaders = [];
      this.selectedcsvheader = {};
      this.mandData = [];
      this.selectedMappings = {};
      this.mandIds = [];
    },
    downloadFile(file) {
      this.$axios
        .post(
          ApiConstants.APIURL +  "download",
          {
            filename: file
          },
          { responseType: "blob" }
        )
        .then(response => {
          let link = document.createElement("a");
          link.href = window.URL.createObjectURL(response.data);
          link.download = file;
          link.click().catch(error => console.error(error));
        });
    },
    saveData() {
      let keys = Object.keys(this.selectedMappings);
      let csvcols = [];
      let mappedcols = [];
      if (this.mandIds.every(ele => keys.includes(ele))) {
        keys.map(key => {
          csvcols.push(this.selectedMappings[key]);
          mappedcols.push(this.selectedcsvheader[key]);
        });
        for (let i = 0; i < mappedcols.length; i++) {
          if (mappedcols[i].includes("*")) {
            mappedcols[i] = mappedcols[i].replace("*", "");
          }
        }
        this.$axios
          .post(ApiConstants.APIURL +  "mappedcsv", {
            config: JSON.stringify(_.zip(csvcols, mappedcols)),
            orgName: this.orgModel,
            processName: this.processModel,
            sys: this.currentSystem,
            fileName: this.ticked[0]
          })
          .then(response => {
            this.$q.notify({
              color: "green-2",
              position: "top-right",
              textColor: "black",
              icon: "fas fa-check-circle",
              message: "Continue mapping files or click Finish."
            });
            this.showFinish = true;
            Array.isArray(this.desc[this.processModel])
              ? this.desc[this.processModel].push(response.data.filename)
              : (this.desc[this.processModel] = [response.data.filename]);
            Array.isArray(this.sysDesc[this.processModel])
              ? this.sysDesc[this.processModel].push(this.currentSystem)
              : (this.sysDesc[this.processModel] = [this.currentSystem]);
            this.resetData();
            this.ticked = [];
            this.processModel = null;
            this.saveDisable = true;
          });
      } else {
        this.$q.notify({
          color: "amber-4",
          position: "top-right",
          textColor: "black",
          icon: "fas fa-exclamation",
          message: "All mandatories should be mapped"
        });
      }
    },
    removeRow(prop) {
      delete this.selectedcsvheader[prop.row.id];
      this.data.splice(
        this.data.indexOf(
          _.find(this.data, { processdefn: prop.row.processdefn })
        ),
        1
      );
    },
    deleteFile(filename, process = null) {
      this.$axios
        .post(ApiConstants.APIURL +  "deleteFiles", {
          orgName: this.orgModel,
          fileNames: filename
        })
        .then(response => {
          this.$q.notify({
            color: "green-2",
            position: "top-right",
            textColor: "black",
            icon: "fas fa-exclamation",
            message: "File deleted"
          });
          this.ticked = [];
          this.getFilesAndFolders();
          if (process !== null) {
            this.desc[process].splice(this.desc[process].indexOf(filename), 1);
          }
          this.resetData();
        });
    },
    finishData() {
      this.$axios
        .post(ApiConstants.APIURL +  "collateFiles", {
          org: this.orgModel,
          fileData: this.desc
        })
        .then(response => {
          if (response.data.status === "failed") {
            this.$q.notify({
              color: "red-2",
              position: "top-right",
              textColor: "black",
              icon: "fas fa-exclamation",
              message: "Server error, please try again"
            });
          } else {
            let allProcesses = Object.keys(this.desc);
            this.$axios
              .post(ApiConstants.APIURL +  "python2", {
                org: this.orgModel,
                user: this.$q.localStorage.getItem("audire_user"),
                process: allProcesses,
                system: this.currentSystem
              })
              .then(response => {
                if (response.data.status === "success") {
                  this.$router.push(`/transactions`);
                } else {
                  this.$q.notify({
                    color: "red-2",
                    position: "top-right",
                    textColor: "black",
                    icon: "fas fa-exclamation",
                    message: "Server error, please try again"
                  });
                }
              })
              .catch(err => console.error(err));
          }
        })
        .catch(err => console.log(err));
    },
    async ProcessTemplates() {
      let templatePromise = await this.$axios.post(
        ApiConstants.APIURL +  "processTemplates",
        { process: this.processModel }
      );
      this.processTemplates = templatePromise.data.msg;
    }
  },
  created() {
    this.orgModel = this.$q.localStorage.getItem("audire_user_org");
    // if (this.orgModel === "XYZ Company") {
    this.companyModel = this.orgModel;
    this.branchModel = this.orgModel;
    // }
    this.showFinish = false;
    this.getSysandProc();
    this.getFilesAndFolders();
  },
  watch: {
    ticked() {
      if (
        this.ticked.length !== 0 &&
        this.ticked[0] !== undefined &&
        this.processModel !== null
      ) {
        this.tableLoader = true;
        this.loadData();
        this.tableLoader = false;
        this.saveDisable = false;
      }
    },
    processModel() {
      if (
        this.ticked.length !== 0 &&
        this.ticked[0] !== undefined &&
        this.processModel !== null
      ) {
        this.tableLoader = true;
        this.loadData();
        this.tableLoader = false;
        this.saveDisable = false;
      }
      if (this.processModel !== null) {
        this.ProcessTemplates();
      }
    }
  }
};
</script>

<style>
</style>