<template>
  <q-page>
    <div class="px-8 py-5">
      <div class="flex justify-between px-4">
        <div class="w-3/12">
          <q-input
            color="indigo-10"
            v-model="searchText"
            outlined
            rounded
            dense
            placeholder="Search Lease Id"
          >
            <template v-slot:prepend>
              <q-icon name="search" />
            </template>
          </q-input>
        </div>
        <div class="w-2/12">
          <q-select
            rounded
            outlined
            hide-bottom-space
            v-model="listLeaseModel"
            :options="listLeaseOptions"
            label="Lease Status"
            class="w-auto"
            size="md"
            dense
            style="min-width:8rem"
            options-dense
            transition-show="jump-up"
            transition-hide="jump-up"
          />
        </div>
        <div class="w-2/12">
          <q-select
            rounded
            outlined
            hide-bottom-space
            v-model="listProjectModel"
            :options="listProjectOptions"
            label="Project Status"
            class="w-auto"
            size="md"
            dense
            style="min-width:8rem"
            options-dense
            transition-show="jump-up"
            transition-hide="jump-up"
          />
        </div>
        <div class="w-2/12">
          <q-btn
            dense
            flat
            rounded
            no-caps
            size="15px"
            class="w-24"
            style="background-color:#022C4C"
            @click="listLease"
          >
            <span class="text-bold-soft text-gray-100 tracking-wide">Load</span>
          </q-btn>
        </div>
      </div>
      <div class="flex items-top py-6">
        <div class="w-2/12 pr-2">
          <q-list>
            <q-item
              clickable
              v-for="(item,index) in leaseIds"
              @click="getWorkflow(item)"
              :key="item+index"
              class="bg-grey-4 border-b-2 border-gray-400"
            >
              <q-item-section>
                <div class="flex justify-between">
                  <div>
                    <span class="text-sm font-black text-gray-600 text-uppercase tracking-wide">ID :</span>
                    <span
                      class="text-md font-sans font-black tracking-widest text-gray-800"
                    >{{item.id}}</span>
                  </div>
                  <div>
                    <span
                      class="text-sm font-black text-gray-600 text-uppercase tracking-wide"
                    >Date :</span>
                    <span class="text-sm font-black text-gray-800 text-lowercase">{{item.date}}</span>
                  </div>
                </div>
              </q-item-section>
            </q-item>
          </q-list>
        </div>
        <div class="w-10/12 pl-2" v-if="showTable">
          <q-table :data="data" :columns="columns" row-key="name" binary-state-sort>
            <template v-slot:top>
              <div class="flex items-center justify-between">
                <div class="flex items-center">
                  <div class="px-4">
                    <span
                      class="font-sans font-black border-r-4 pr-4 border-gray-500 text-gray-700 text-lg tracking-wider"
                    >Project Plan</span>
                  </div>
                  <div class="px-4">
                    <q-btn
                      dense
                      flat
                      :disable="planDisable"
                      rounded
                      no-caps
                      class="w-18 h-2"
                      :style="planBtnColor"
                      @click="activateProject(planObj)"
                    >
                      <span
                        class="text-bold-soft text-gray-100 text-gray-800 tracking-wide px-4"
                      >{{planActivate}}</span>
                    </q-btn>
                  </div>
                </div>
                <div class="flex justify-end">
                  <q-btn
                    dense
                    flat
                    rounded
                    no-caps
                    class="w-24 h-6"
                    style="background-color:#022C4C"
                    @click="saveProject"
                    :disable="saveDisable"
                  >
                    <span class="text-bold-soft text-gray-100 tracking-wide">Save</span>
                  </q-btn>
                </div>
              </div>
            </template>
            <template v-slot:body="props">
              <q-tr :props="props">
                <q-td
                  key="WF_01A_Task_Holder"
                  :props="props"
                >{{ props.row.WF_01A_Task_Holder || "-" }}</q-td>
                <q-td
                  key="WF_01A_Task_InternalID"
                  :props="props"
                >{{ props.row.WF_01A_Task_InternalID || "-"}}</q-td>
                <q-td key="WF_01A_Task_Type" :props="props">{{ props.row.WF_01A_Task_Type || "-"}}</q-td>
                <q-td key="WF_01A_Task_PlanStartDt" :props="props">
                  {{ props.row.WF_01A_Task_PlanStartDt || "-"}}
                  <q-popup-edit v-model="props.row.WF_01A_Task_PlanStartDt">
                    <q-input
                      type="date"
                      v-model="props.row.WF_01A_Task_PlanStartDt"
                      dense
                      autofocus
                      @keypress.enter="computeDate(props.row.WF_01A_Task_PlanStartDt,props.row.WF_01A_Task_DurationPlan,props.row.WF_01A_Task_ExternalID)"
                    />
                  </q-popup-edit>
                </q-td>
                <q-td key="WF_01A_Task_DurationPlan" :props="props">
                  {{ props.row.WF_01A_Task_DurationPlan ||"-" | formatDurationPlan}}
                  <q-popup-edit v-model="props.row.WF_01A_Task_DurationPlan">
                    <q-input
                      type="number"
                      v-model="props.row.WF_01A_Task_DurationPlan"
                      dense
                      autofocus
                      @keypress.enter="computeDate(props.row.WF_01A_Task_PlanStartDt,props.row.WF_01A_Task_DurationPlan,props.row.WF_01A_Task_InternalID)"
                    />
                  </q-popup-edit>
                </q-td>
                <q-td key="WF_01A_Task_PlanEndDt" :props="props">
                  {{ props.row.WF_01A_Task_PlanEndDt ||"-"}}
                  <q-popup-edit v-model="props.row.WF_01A_Task_PlanEndDt">
                    <q-input
                      type="date"
                      v-model="props.row.WF_01A_Task_PlanEndDt"
                      dense
                      autofocus
                      @keypress.enter="computeDate(props.row.WF_01A_Task_PlanStartDt,props.row.WF_01A_Task_DurationPlan,props.row.WF_01A_Task_InternalID)"
                    />
                  </q-popup-edit>
                </q-td>
                <q-td
                  key="WF_01A_Task_Negative"
                  :props="props"
                >{{ props.row.WF_01A_Task_Negative || "-" }}</q-td>
                <q-td
                  key="WF_01A_Task_DocAttachment"
                  :props="props"
                >{{ props.row.WF_01A_Task_DocAttachment || "-" }}</q-td>
                <q-td
                  key="WF_01A_Task_EscalationMatrix"
                  :props="props"
                >{{ props.row.WF_01A_Task_EscalationMatrix ||"-" }}</q-td>
                <q-td key="WF_01A_Task_Abort" :props="props">{{ props.row.WF_01A_Task_Abort || "-"}}</q-td>
                <q-td
                  key="WF_01A_Task_DependencyCondExpr"
                  :props="props"
                >{{ props.row.WF_01A_Task_DependencyCondExpr || "-"}}</q-td>
                <q-td
                  key="WF_01A_Task_OwnerPersonID"
                  :props="props"
                >{{ props.row.WF_01A_Task_OwnerPersonID || "-" }}</q-td>
                <q-td
                  key="WF_01A_Task_OverDue"
                  :props="props"
                >{{ props.row.WF_01A_Task_OverDue ||"-"}}</q-td>
                <q-td
                  key="WF_01A_Task_OwnerPositionID"
                  :props="props"
                >{{ props.row.WF_01A_Task_OwnerPositionID||"-" }}</q-td>
                <q-td key="WF_01A_Task_Name" :props="props">{{ props.row.WF_01A_Task_Name ||"-"}}</q-td>
                <q-td
                  key="WF_01A_Task_Reject"
                  :props="props"
                >{{ props.row.WF_01A_Task_Reject ||"-"}}</q-td>
                <q-td
                  key="WF_01A_Task_Status"
                  :props="props"
                >{{ props.row.WF_01A_Task_Status||"-" }}</q-td>
                <q-td
                  key="WF_01A_Task_Content"
                  :props="props"
                >{{ props.row.WF_01A_Task_Content ||"-"}}</q-td>
                <q-td
                  key="WF_01A_Task_Execute"
                  :props="props"
                >{{ props.row.WF_01A_Task_Execute||"-" }}</q-td>
                <q-td
                  key="WF_01A_Task_LineIndex"
                  :props="props"
                >{{ props.row.WF_01A_Task_LineIndex||"-" }}</q-td>
                <q-td
                  key="WF_01A_Task_DurationAmended"
                  :props="props"
                >{{ props.row.WF_01A_Task_DurationAmended ||"-"}}</q-td>
                <q-td
                  key="WF_01A_Task_ContentType"
                  :props="props"
                >{{ props.row.WF_01A_Task_ContentType||"-" }}</q-td>
                <q-td
                  key="WF_01A_Task_NotificationGrp"
                  :props="props"
                >{{ props.row.WF_01A_Task_NotificationGrp ||"-"}}</q-td>
              </q-tr>
            </template>
          </q-table>
        </div>
      </div>
    </div>
  </q-page>
</template>

<script>
import { ApiConstants } from './../const';
import { EventBus } from "./event-bus.js";
import { setTimeout } from "timers";
import _ from "lodash";
import moment from "moment";
export default {
  data() {
    return {
      saveDisable: true,
      columns: [
        {
          name: "WF_01A_Task_Holder",
          label: "WF_01A_Task_Holder",
          align: "left",
          field: "WF_01A_Task_Holder"
        },
        {
          name: "WF_01A_Task_InternalID",
          label: "WF_01A_Task_InternalID",
          align: "center",
          field: "WF_01A_Task_InternalID"
        },
        {
          name: "WF_01A_Task_Type",
          label: "WF_01A_Task_Type",
          align: "center",
          field: "WF_01A_Task_Type"
        },
        {
          name: "WF_01A_Task_PlanStartDt",
          label: "WF_01A_Task_PlanStartDt",
          align: "center",
          field: "WF_01A_Task_PlanStartDt"
        },
        {
          name: "WF_01A_Task_DurationPlan",
          label: "WF_01A_Task_DurationPlan",
          field: "WF_01A_Task_DurationPlan",
          align: "center"
        },
        {
          name: "WF_01A_Task_PlanEndDt",
          label: "WF_01A_Task_PlanEndDt",
          field: "WF_01A_Task_PlanEndDt",
          align: "center"
        },
        {
          name: "WF_01A_Task_Negative",
          label: "WF_01A_Task_Negative",
          align: "center",
          field: "WF_01A_Task_Negative"
        },
        {
          name: "WF_01A_Task_DocAttachment",
          label: "WF_01A_Task_DocAttachment",
          align: "center",
          field: "WF_01A_Task_DocAttachment"
        },
        {
          name: "WF_01A_Task_NotificationGrp",
          align: "center",
          label: "WF_01A_Task_NotificationGrp",
          field: "WF_01A_Task_NotificationGrp"
        },
        {
          name: "WF_01A_Task_EscalationMatrix",
          label: "WF_01A_Task_EscalationMatrix",
          field: "WF_01A_Task_EscalationMatrix",
          align: "center"
        },
        {
          name: "WF_01A_Task_Abort",
          label: "WF_01A_Task_Abort",
          field: "WF_01A_Task_Abort",
          align: "center"
        },
        {
          name: "WF_01A_Task_DependencyCondExpr",
          label: "WF_01A_Task_DependencyCondExpr",
          field: "WF_01A_Task_DependencyCondExpr",
          align: "center"
        },
        {
          name: "WF_01A_Task_OverDue",
          label: "WF_01A_Task_OverDue",
          field: "WF_01A_Task_OverDue",
          align: "center"
        },
        {
          name: "WF_01A_Task_OwnerPositionID",
          label: "WF_01A_Task_OwnerPositionID",
          field: "WF_01A_Task_OwnerPositionID",
          align: "center"
        },
        {
          name: "WF_01A_Task_Name",
          label: "WF_01A_Task_Name",
          field: "WF_01A_Task_Name",
          align: "center"
        },
        {
          name: "WF_01A_Task_Reject",
          label: "WF_01A_Task_Reject",
          field: "WF_01A_Task_Reject",
          align: "center"
        },
        {
          name: "WF_01A_Task_Status",
          label: "WF_01A_Task_Status",
          field: "WF_01A_Task_Status",
          align: "center"
        },
        {
          name: "WF_01A_Task_Content",
          label: "WF_01A_Task_Content",
          field: "WF_01A_Task_Content",
          align: "center"
        },
        {
          name: "WF_01A_Task_Execute",
          label: "WF_01A_Task_Execute",
          field: "WF_01A_Task_Execute",
          align: "center"
        },
        {
          name: "WF_01A_Task_LineIndex",
          label: "WF_01A_Task_LineIndex",
          field: "WF_01A_Task_LineIndex",
          align: "center"
        },
        {
          name: "WF_01A_Task_DurationAmended",
          label: "WF_01A_Task_DurationAmended",
          field: "WF_01A_Task_DurationAmended",
          align: "center"
        },
        {
          name: "WF_01A_Task_ContentType",
          label: "WF_01A_Task_ContentType",
          field: "WF_01A_Task_ContentType",
          align: "center"
        },
        {
          name: "WF_01A_Task_OwnerPersonID",
          label: "WF_01A_Task_OwnerPersonID",
          field: "WF_01A_Task_OwnerPersonID",
          align: "center"
        }
      ],
      data: [],
      searchText: null,
      listLeaseModel: "Active",
      listLeaseOptions: ["Active", "Inactive"],
      listProjectModel: "Drafted",
      listProjectOptions: ["Project Active", "Drafted", "EOL"],
      leaseIds: [],
      showTable: false,
      planDisable: null,
      planBtnColor: null,
      planActivate: null,
      planObj: null
    };
  },
  created() {
    this.getLease(this.listLeaseModel, this.listProjectModel);
  },
  computed: {
    _() {
      return _;
    }
  },
  methods: {
    listLease() {
      if (
        this.listLeaseModel === "Inactive" ||
        this.listProjectModel === "EOL"
      ) {
        // this.getLease(this.listLeaseModel, this.listProjectModel);
      } else {
        this.$q.loading.show({
          message: "Fetching please wait",
          spinnerSize: 50,
          spinnerColor: "red-10",
          backgroundColor: "grey-7",
          messageColor: "grey-10",
          spinner: "QSpinnerBars",
          customClass: "font-sans text-bold tracking-wide text-xl text-gray-800"
        });
        this.getLease(this.listLeaseModel, this.listProjectModel);
        this.$q.loading.hide();
      }
    },
    saveProject() {
      this.$axios
        .post( ApiConstants.APIURL + "saveProject", {
          leaseData: this.data,
          lease: this.planObj.id,
          status: "Active",
          // this.leaseIds.forEach(obj => {
          //   if (this.planObj.id === obj.id) {
          //     return obj.status;
          //   }
          // })
          project_status: "Drafted",
          // this.leaseIds.forEach(obj => {
          //   if (this.planObj.id === obj.id) {
          //     return obj.project_status;
          //   }
          // })
          org: this.$q.localStorage.getItem("audire_user_org")
        })
        .then(response => {})
        .catch(reserr => console.error(reserr));
    },
    activateProject(item) {
      this.planDisable = true;
      this.planBtnColor = "background-color:#a5d6a7";
      this.planActivate = "activated";
      this.leaseIds.filter(obj => {
        if (obj.id === item.id) {
          obj.disable = true;
          obj.activate = "activated";
          obj.color = "background-color:#a5d6a7";
        }
      });
      this.data.forEach(obj => {
        obj.WF_01A_Task_OwnerPersonID = this.$q.localStorage.getItem(
          "audire_user"
        );
      });
      this.saveProject();
    },
    getLease(lease, project) {
      this.leaseIds = [];
      this.$axios
        .post( ApiConstants.APIURL +  "leases", {
          org: this.$q.localStorage.getItem("audire_user_org"),
          status: lease,
          project_status: project
        })
        .then(response => {
          response.data.ids.forEach(obj => {
            if (obj.project_status.includes(["Drafted"])) {
              obj.disable = false;
              obj.activate = "activate";
              obj.color = "background-color:#ffe082";
              this.leaseIds.push(obj);
            } else {
              obj.disable = true;
              obj.activate = "activated";
              obj.color = "background-color:#a5d6a7";
              this.leaseIds.push(obj);
            }
          });
          this.showTable = true;
        })
        .catch(err => console.error(err));
    },
    getWorkflow(item) {
      this.data = [];
      this.$axios
        .post( ApiConstants.APIURL +  "workflow", {
          lease: item.id
        })
        .then(response => {
          this.saveDisable = false;
          this.planBtnColor = item.color;
          this.planObj = item;
          this.planActivate = item.activate;
          this.planDisable = item.disable;
          this.data = [];
          response.data.docs.forEach(obj => {
            obj.WF_01A_Task_ExternalID_new = parseInt(
              obj.WF_01A_Task_ExternalID.replace("T", "")
            );
            this.data.push(obj);
          });
        })
        .catch(err => console.error(err));
    },
    searchAfterDebounce: _.debounce(
      function() {
        this.search();
      },
      500 // 500 milliseconds
    ),
    search() {
      this.showTable = false;
      if (this.searchText.length > 1) {
        this.$axios
          .post( ApiConstants.APIURL +  "findLease", {
            org: this.$q.localStorage.getItem("audire_user_org"),
            lease: this.searchText
          })
          .then(response => {
            this.leaseIds = [];
            response.data.ids.forEach(obj => {
              if (obj.project_status.includes(["Drafted"])) {
                obj.disable = false;
                obj.activate = "activate";
                obj.color = "background-color:#ffe082";
              } else {
                obj.disable = true;
                obj.activate = "activated";
                obj.color = "background-color:#a5d6a7";
              }
              this.showTable = true;
              this.leaseIds.push(obj);
            });
          });
      }
    },
    computeDate(startdt, duration, id) {
      this.data.forEach(obj => {
        if (obj.WF_01A_Task_ExternalID === id) {
          obj.WF_01A_Task_PlanStartDt = startdt;
          obj.WF_01A_Task_PlanEndDt = moment(startdt, "YYYY-MM-DD")
            .add(parseInt(obj.WF_01A_Task_DurationPlan.split(":")[0]), "days")
            .format("YYYY-MM-DD");
        }
        if (obj.WF_01A_Task_ExternalID_new > id.replace("T", "")) {
          let prevObj = this.data[this.data.indexOf(obj) - 1];
          obj.WF_01A_Task_PlanStartDt = moment(
            prevObj.WF_01A_Task_PlanEndDt,
            "YYYY-MM-DD"
          )
            .add(1, "days")
            .format("YYYY-MM-DD");
          obj.WF_01A_Task_PlanEndDt = moment(
            obj.WF_01A_Task_PlanStartDt,
            "YYYY-MM-DD"
          )
            .add(parseInt(obj.WF_01A_Task_DurationPlan.split(":")[0]), "days")
            .format("YYYY-MM-DD");
        }
      });
    }
  },
  watch: {
    searchText(newval, oldval) {
      this.searchAfterDebounce(newval);
    }
  },
  filters: {
    formatDurationPlan(val) {
      if (val !== "-") {
        if (val !== null) {
          return parseInt(val.split(":")[0]);
        } else {
          return val;
        }
      } else {
        return val;
      }
    }
  }
};
</script>

<style>
</style>

