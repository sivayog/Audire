<template>
  <q-page>
    <h4>Settings</h4>
  </q-page>
</template>

<script>
export default {};
</script>

<style>
</style>