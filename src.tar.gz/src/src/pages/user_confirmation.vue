<template>
  <q-page>
    <div class="flex h-screen">
      <div class="flex flex-col items-center m-auto">
        <div>
          <span
            class="font-serif font-semibold text-xl text-gray-800 tracking-widest"
          >Account Confirmed.Logging in...</span>
        </div>
      </div>
    </div>
  </q-page>
</template>

<script>
import { ApiConstants } from './../const';
import { EventBus } from "./event-bus.js";
export default {
  name: "user_confirmation",
  data() {
    return {
      verificationCode: null,
      show: false
    };
  },
  methods: {},
  created() {
    this.$q.loading.show({
      message: "Verifiying Account.Please Wait."
    });
    this.$axios
      .get(ApiConstants.LOGINAPIURL + "verify", {
        headers: { authorization: this.$route.query.token }
      })
      .then(response => {
        if (response.data.status === "failed") {
          this.$q.loading.hide();
          this.$router.push("/");
        } else {
          this.$q.loading.hide();
          this.show = true;
          this.$axios
            .post(ApiConstants.LOGINAPIURL + "login", {
              email: response.data.createdUser.email,
              password: response.data.createdUser.password
            })
            .then(response => {
              if (response.data.status === "failed") {
                this.$q.notify({
                  color: "red-2",
                  position: "top-right",
                  textColor: "black",
                  icon: "fas fa-exclamation",
                  message: response.data.message
                });
              } else {
                this.$q.localStorage.set(
                  "audire_bearer",
                  response.data.message
                );
                this.$q.localStorage.set("audire_user", response.data.name);
                this.$q.localStorage.set(
                  "audire_user_org",
                  response.data.organization
                );
                this.$axios
                  .post(ApiConstants.APIURL + "createOrg", {
                    org: this.$q.localStorage.getItem("audire_user_org")
                  })
                  .then(response => {
                    if (response.data.status === "success") {
                      this.$router.push("/inference");
                    } else {
                      this.$q.notify({
                        color: "red-2",
                        position: "top-right",
                        textColor: "black",
                        icon: "fas fa-exclamation",
                        message:
                          "Error creating organization, pls contact support."
                      });
                    }
                  });
              }
            });
        }
      });
  }
};
</script>

<style scoped>
</style>