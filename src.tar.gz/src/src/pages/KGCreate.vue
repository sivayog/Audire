<template>
  <q-page padding>
    <div class="q-pa-md">
      <q-table
        :data="data"
        :columns="columns"
        row-key="name"
        :rows-per-page-options="[0]"
        :pagination.sync="pagination"
        hide-bottom
        no-data-label
        class="bg-blue-grey-2"
      >
        <template v-slot:top class="flex flex-center row">
          <q-input
            v-model="orgName"
            placeholder="Enter Organization name"
            dense
            use-input
            autofocus
            class="text-title"
            style="width:250px"
          />
          <q-space />
          <q-btn rounded icon="fas fa-plus" color="teal-10" flat dense @click="addRow"></q-btn>
        </template>
        <template v-slot:body="props">
          <q-tr :props="props">
            <q-td key="description" :props="props">
              {{ props.row.name }}
              <q-popup-edit v-model="props.row.name" @save="val=>{popupHandler(val,props.row.id)}">
                <q-input v-model="props.row.name" dense autofocus />
              </q-popup-edit>
            </q-td>
            <q-td key="available process" :props="props">
              <div class="col-xs-6">
                <q-select
                  :options="processes[props.row.id]"
                  v-model="selectedProcess[props.row.id]"
                  label="Choose single/multiple"
                  multiple
                  options-dense
                  @input="selectHandler(props.row.id)"
                />
              </div>
            </q-td>
            <!-- <q-td key="add process" :props="props">
              <div class="col-xs-6">
                <q-select
                  placeholder="Add process manually or leave blank"
                  v-model="processAdd"
                  use-input
                  dense
                  flat
                  use-chips
                  multiple
                  hide-dropdown-icon
                  input-debounce="0"
                  emit-value
                  @new-value="createValue"
                />
              </div>
            </q-td>-->
            <q-td key="sot" :props="props">
              <q-option-group
                v-model="props.row.checkbox"
                :options="options[props.row.id]"
                color="teal-10"
                type="checkbox"
                dense
                @input="optionsHandler(props.row.checkbox,props.row.id)"
              />
            </q-td>
            <q-td key="remove" :props="props">
              <q-btn flat dense color="red-14" icon="far fa-trash-alt" @click="removeRow(props)"></q-btn>
            </q-td>
          </q-tr>
        </template>
      </q-table>
    </div>
    <div class="row q-pa-lg">
      <div class="col q-pr-lg">
        <q-btn class="float-right text-outline bg-blue-grey-3" @click="saveKG">Save</q-btn>
      </div>
      <div class="col">
        <q-btn class="flex flex-center bg-blue-grey-3" @click="resetKG">Reset</q-btn>
      </div>
    </div>
  </q-page>
</template>

<script>
import { ApiConstants } from './../const'; 
window._ = require("lodash");
export default {
  name: "KGCreate",
  data() {
    return {
      pagination: {
        page: 1,
        rowsPerPage: 0 // 0 means all rows
      },
      orgName: null,
      rowCount: 10,
      processes: {},
      processAdd: null,
      selectedProcess: {},
      currentSelected: [],
      columns: [
        {
          name: "description",
          required: true,
          label: "Systems",
          align: "left",
          field: row => row.name,
          format: val => `${val}`,
          sortable: true
        },
        {
          name: "available process",
          align: "fixed",
          label: "Avail. Process",
          field: "availprocess"
        },
        // {
        //   name: "add process",
        //   label: "Add Process",
        //   field: "addprocess",
        //   align: "center"
        // },
        {
          name: "sot",
          label: "Source of Truth",
          field: "sot",
          align: "left"
        },
        {
          name: "remove",
          label: "Action",
          field: "remove",
          align: "center"
        }
      ],
      data: [],
      globalProcess: [],
      rowCounter: 0,
      options: {},
      group: {},
      kg: null,
      systems: {}
    };
  },
  created() {},
  mounted() {
    this.getProcess();
  },
  methods: {
    getProcess() {
      this.$axios.get(ApiConstants.APIURL +  "process").then(response => {
        if (response.data.status !== "failed") {
          this.globalProcess = response.data.msg;
        } else {
          this.globalProcess = null;
        }
      });
    },
    addRow() {
      let rowNo = this.rowCounter++;
      this.processes[`row${rowNo}`] = this.globalProcess;
      // this.group[`row${rowNo}`] = [];
      this.options[`row${rowNo}`] = [];
      // this.selectedProcess[`row${rowNo}`] = [];
      this.data.push({
        id: `row${rowNo}`,
        checkbox: [],
        name: "<click to edit>",
        availprocess: null,
        // addprocess: "<click to edit>",
        sot: null,
        remove: null
      });
    },
    removeRow(prop) {
      // console.log(prop);
      this.data.splice(
        this.data.indexOf(_.find(this.data, { id: prop.row.id })),
        1
      );
      delete this.systems[prop.row.id];
      delete this.group[prop.row.id];
    },
    selectHandler() {
      Object.keys(this.selectedProcess).forEach(key => {
        this.options[key] = [];
        this.selectedProcess[key].forEach(ele => {
          this.options[key].push({ label: ele, value: ele });
        });
      });
    },
    optionsHandler(vals, id) {
      this.group[id] = vals;
      Object.keys(this.group).forEach(key => {
        if (key !== id) {
          vals.forEach(val => {
            if (_.includes(this.group[key], val) === true) {
              this.group[key].splice(this.group[key].indexOf(val), 1);
              this.group[id].splice(this.group[id].indexOf(val), 1);
              this.$q.notify({
                color: "red-9",
                position: "top",
                textColor: "white",
                icon: "fas fa-exclamation-triangle",
                message: "Systems can't have multiple Source of truth process."
              });
            }
          });
        }
      });
    },
    saveKG() {
      if (
        this.orgName !== null &&
        Object.keys(this.systems).length > 0 &&
        Object.keys(this.selectedProcess).length > 0
      ) {
        let tempObj = {};
        tempObj["org"] = this.orgName;
        tempObj["systems"] = [];
        let process = [];
        let sot = [];
        Object.keys(this.systems).forEach(row => {
          tempObj["systems"].push({
            system: this.systems[row],
            process: this.selectedProcess[row],
            sot: this.group[row]
          });
        });
        this.kg = tempObj;
        this.$axios
          .post(ApiConstants.APIURL +  "createkg", {
            config: JSON.stringify(this.kg)
          })
          .then(response => {
            if (response.data.status === "success") {
              this.$q.notify({
                color: "green-10",
                position: "top",
                textColor: "white",
                icon: "fas fa-check-circle",
                message: "Systems created successfully!."
              });
              this.$router.push("/upload");
            } else {
              this.$q.notify({
                color: "red-9",
                position: "top",
                textColor: "white",
                icon: "fas fa-exclamation-triangle",
                message: "UnSuccessful Transaction!."
              });
            }
          });
      } else {
        this.$q.notify({
          color: "red-9",
          position: "top",
          textColor: "white",
          icon: "fas fa-exclamation-triangle",
          message: "Can't Have empty Fields!."
        });
      }
    },
    resetKG() {
      this.orgName = null;
      this.processes = {};
      this.options = {};
      this.data = [];
      this.systems = {};
      this.selectedProcess = {};
      this.group = {};
      this.kg = {};
    },
    popupHandler(val, id) {
      this.systems[id] = val;
    }
  },
  computed: {
    _() {
      return _;
    }
  }
};
</script>

<style scoped>
</style>
