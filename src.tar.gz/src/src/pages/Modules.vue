<template>
  <q-page>
    <div class="px-10 py-8">
      <div class="border-b-2 border-gray-400">
        <span
          class="text-lg font-sans font-semibold tracking-wider text-gray-700"
          >Modules</span
        >
      </div>
    </div>
    <div class="px-10 py-8 flex">
      <div
        class="w-1/4 px-3 py-4"
        style="cursor:pointer"
        v-for="(i, index) of modules"
        :key="i + index"
      >
        <div
          class="bg-gray-500 px-2 rounded-lg bg-grey-1 border-2 border-b-4 border-r-4 border-gray-400"
          @click="loadProcess(i.moduleName)"
        >
          <div class="w-10/12 ellipsis">
            <span class="text-lg font-sans font-bold-soft text-camelcase">{{
              i.moduleName
            }}</span>
          </div>
          <div class="py-5 pl-2">
            <span
              class="text-md font-black-soft text-gray-600 tracking-wider text-camelcase"
              >{{ i.desc }}</span
            >
          </div>
        </div>
      </div>
    </div>
  </q-page>
</template>

<script>
  import { ApiConstants } from './../const';
  export default {
    data() {
      return {
        modules: []
      };
    },
    created() {
      this.getModules();
    },
    methods: {
      getModules() {
        this.modules = [];
        this.$axios
          .post(ApiConstants.APIURL +  "modules", {
            orgName: this.$q.localStorage.getItem("audire_user_org")
          })
          .then(response => {
            response.data.msg.forEach(element => {
              this.modules.push({
                moduleName: element.name.split("_").join(" "),
                desc: element.desc
              });
            });
          })
          .catch(err => console.log(err));
      },
      loadProcess(moduleName) {
        this.$axios
          .post(ApiConstants.APIURL + "moduleProcess", {
            orgName: this.$q.localStorage.getItem("audire_user_org"),
            moduleName: moduleName.split(" ").join("_")
          })
          .then(response => {
            let temp = {
              [moduleName]: response.data.msg
            };
            this.$q.localStorage.set("moduleAndProcess", JSON.stringify(temp));
            window.location.reload(true);
            this.$router.push("/transactions");
          })
          .catch(err => console.log(err));
      }
    }
  };
</script>

<style></style>
