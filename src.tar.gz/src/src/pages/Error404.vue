<template>
  <div class="fixed-center text-center">
    <p>
      <img src="~assets/404.svg" style="width:50vw;max-width:300px;" />
    </p>
    <p class="text-h5 text-black text-outline">
      <strong>Sorry , Nothing here...</strong>
    </p>
    <q-btn color="secondary" style="width:200px;" @click="$router.push('/')">Go back</q-btn>
  </div>
</template>

<script>
export default {
  name: "Error404"
};
</script>

<style scoped>
</style>
