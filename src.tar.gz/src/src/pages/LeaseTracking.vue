<template>
  <q-page>
    <div class="px-10 py-6">
      <q-table
        :data="data"
        :columns="columns"
        row-key="name"
        binary-state-sort
        no-data-label="No Tasks available"
      >
        <template v-slot:top>
          <div class="flex items-center justify-between">
            <div class="flex items-center">
              <div class="px-4">
                <span
                  class="font-sans font-black border-r-4 pr-4 border-gray-500 text-gray-700 text-lg tracking-wider"
                >Activity Tracker</span>
              </div>
              <div>
                <q-btn
                  dense
                  flat
                  rounded
                  no-caps
                  class="w-24 h-6"
                  style="background-color:#022C4C"
                  @click="changeTaskStatus"
                >
                  <span class="text-bold-soft text-gray-100 tracking-wide">Start</span>
                </q-btn>
              </div>
            </div>
          </div>
        </template>
        <template v-slot:body="props">
          <q-tr :props="props">
            <q-td key="check" :props="props">
              <q-checkbox v-model="props.row.check" @input="checkHandler(props.row)" />
            </q-td>
            <q-td key="LeaseId" :props="props">{{ props.row.LeaseId }}</q-td>
            <q-td key="WF_01A_Task_PlanStartDt" :props="props">{{ props.row.WF_01A_Task_PlanStartDt }}</q-td>
            <q-td key="WF_01A_Task_PlanEndDt" :props="props">{{ props.row.WF_01A_Task_PlanEndDt }}</q-td>
            <q-td key="WF_01A_Task_ActualStartDt" :props="props">{{ props.row.WF_01A_Task_ActualStartDt }}</q-td>
            <q-td key="WF_01A_Task_ActualEndDt" :props="props">{{ props.row.WF_01A_Task_ActualEndDt }}</q-td>
            <q-td key="WF_01A_Task_Status" :props="props">{{ props.row.WF_01A_Task_Status }}</q-td>
            <q-td key="WF_01A_Task_Name" :props="props">{{ props.row.WF_01A_Task_Name }}</q-td>
            <q-td key="WF_01A_Task_DependencyCondExpr" :props="props">{{ props.row.WF_01A_Task_DependencyCondExpr }}</q-td>
            <q-td key="WF_01A_Task_DurationPlan" :props="props">{{ props.row.WF_01A_Task_DurationPlan }}</q-td>
            <q-td
              key="WF_01A_Task_DurationAmended"
              :props="props"
            >{{ props.row.WF_01A_Task_DurationAmended }}</q-td>
            <q-td key="WF_01A_Task_OwnerPersonID" :props="props">{{ props.row.WF_01A_Task_OwnerPersonID }}</q-td>
            <q-td
              key="WF_01A_Task_NotificationGrp"
              :props="props"
            >{{ props.row.WF_01A_Task_NotificationGrp }}</q-td>
            <q-td key="WF_01A_Task_ContentType" :props="props">{{ props.row.WF_01A_Task_ContentType }}</q-td>
          </q-tr>
        </template>
      </q-table>
    </div>
  </q-page>
</template>

<script>
import { ApiConstants } from './../const';
import { EventBus } from "./event-bus.js";
import { setTimeout } from "timers";
export default {
  data() {
    return {
      selected: [],
      columns: [
        {
          name: "check",
          label: "#",
          align: "left",
          field: "check"
        },
        {
          name: "LeaseId",
          label: "LeaseId",
          align: "center",
          field: "LeaseId"
        },
        {
          name: "WF_01A_Task_PlanStartDt",
          label: "WF_01A_Task_PlanStartDt",
          align: "center",
          field: "WF_01A_Task_PlanStartDt"
        },
        {
          name: "WF_01A_Task_PlanEndDt",
          align: "center",
          label: "WF_01A_Task_PlanEndDt",
          field: "WF_01A_Task_PlanEndDt"
        },
        {
          name: "WF_01A_Task_ActualStartDt",
          label: "WF_01A_Task_ActualStartDt",
          field: "WF_01A_Task_ActualStartDt",
          align: "center"
        },
        {
          name: "WF_01A_Task_ActualEndDt",
          label: "WF_01A_Task_ActualEndDt",
          field: "WF_01A_Task_ActualEndDt",
          align: "center"
        },
        {
          name: "WF_01A_Task_Status",
          label: "WF_01A_Task_Status",
          field: "WF_01A_Task_Status",
          align: "center"
        },
        {
          name: "WF_01A_Task_Name",
          label: "WF_01A_Task_Name",
          field: "WF_01A_Task_Name",
          align: "center"
        },
        {
          name: "WF_01A_Task_DependencyCondExpr",
          label: "WF_01A_Task_DependencyCondExpr",
          field: "WF_01A_Task_DependencyCondExpr",
          align: "center"
        },
        {
          name: "WF_01A_Task_DurationPlan",
          label: "WF_01A_Task_DurationPlan",
          field: "WF_01A_Task_DurationPlan",
          align: "center"
        },
        {
          name: "WF_01A_Task_DurationAmended",
          label: "WF_01A_Task_DurationAmended",
          field: "WF_01A_Task_DurationAmended",
          align: "center"
        },
        {
          name: "WF_01A_Task_OwnerPersonID",
          label: "WF_01A_Task_OwnerPersonID",
          field: "WF_01A_Task_OwnerPersonID",
          align: "center"
        },
        {
          name: "WF_01A_Task_NotificationGrp",
          label: "WF_01A_Task_NotificationGrp",
          field: "WF_01A_Task_NotificationGrp",
          align: "center"
        },
        {
          name: "WF_01A_Task_ContentType",
          label: "WF_01A_Task_ContentType",
          field: "WF_01A_Task_ContentType",
          align: "center"
        }
      ],
      data: []
    };
  },
  created() {
    this.getTasks();
  },
  methods: {
    getTasks() {
      this.$axios
        .post( ApiConstants.APIURL +  "vueTasks", {
          org: this.$q.localStorage.getItem("audire_user_org")
        })
        .then(response => {
          this.data = response.data.finalDocs;
        })
        .catch(err => console.log(err));
    },
    changeTaskStatus() {
      this.$axios
        .post( ApiConstants.APIURL +  "changeTaskStatus", {
          org: this.$q.localStorage.getItem("audire_user_org"),
          leaseData: this.selected
        })
        .then(response => console.log(response.data))
        .catch(err => console.log(err));
    },
    checkHandler(obj) {
      this.selected.push(obj);
    }
  },
  watch: {
    selected() {}
  }
};
</script>

<style>
</style>

