<template>
  <q-page>
    <div class="flex items-top px-12 py-12 overflow-y-auto">
      <div class="w-2/12">
        <q-list class>
          <q-item
            clickable
            @click="refreshData(transaction.TRANSACTION_ID)"
            v-for="(transaction,index) in transactionsList"
            :key="transaction+index"
            class="border-b-2 border-gray-400 bg-grey-1 border-b-2 border-gray-300"
          >
            <div class="flex flex-col">
              <div>
                <span
                  class="text-sm font-sans font-semibold text-gray-700"
                >{{transaction.TRANSACTION_ID}}</span>
              </div>
              <div class="flex flex-col pt-4">
                <div class>
                  <span
                    class="text-sm font-black-soft text-gray-600 text-lowercase tracking-wide"
                  >{{transaction.process}}</span>
                </div>
                <div class>
                  <span
                    class="text-sm font-sans font-semibold-soft text-gray-600 tracking-wide"
                  >{{ new Date(transaction.createdAt).toLocaleDateString()}}</span>
                </div>
              </div>
            </div>
          </q-item>
        </q-list>
        <!-- <div class="bg-grey-1 border-b-2 border-gray-300 cursor-pointer" @click="cardInference">
          <div class="flex justify-between items-baseline px-4 py-2">
            <div>
              <span class="text-lg font-sans font-bold-soft">MTR</span>
            </div>
            <div>
              <span class="text-md font-sans font-bold-soft tracking-wider text-gray-700">Jan 5</span>
            </div>
          </div>
          <div class="py-2 px-4">
            <span class="text-md font-black-soft text-gray-600 tracking-wider">Address #</span>
          </div>
        </div>-->
      </div>
      <!--TODO: ------------------- FOR RENDERING PURPOSES -------------------->
      <div class="w-10/12">
        <!-- <q-icon name="fas fa-id-card" size="150px" style="opacity:.10"></q-icon>
        <span class="text-4xl text-gray-600 text-bold-soft tracking-wide">Select a Lease</span>-->
        <div class="flex items-center justify-between py-2 my-4 mx-24">
          <div class="w-3/12 bg-grey-1 rounded-full">
            <q-select
              outlined
              :disable="disabled"
              rounded
              options-dense
              v-model="processModel"
              :options="processOptions"
              label="Process"
              dense
              transition-show="jump-up"
              transition-hide="jump-up"
              @input="getInference(processModel,systemModel,dimensionModel)"
            />
          </div>
          <div class="w-3/12 bg-grey-1 rounded-full">
            <q-select
              :disable="disabled"
              rounded
              options-dense
              outlined
              v-model="systemModel"
              :options="systemOptions"
              label="System"
              dense
              transition-show="jump-up"
              transition-hide="jump-up"
              @input="getInference(processModel,systemModel,dimensionModel)"
            />
          </div>
          <div class="w-3/12 bg-grey-1 rounded-full">
            <q-select
              :disable="disabled"
              outlined
              options-dense
              rounded
              v-model="dimensionModel"
              :options="dimensionOptions"
              label="Dimension"
              dense
              transition-show="jump-up"
              transition-hide="jump-up"
              @input="getInference(processModel,systemModel,dimensionModel)"
            />
          </div>
        </div>

        <div class="px-8">
          <div class>
            <q-table
              binary-state-sort
              square
              flat
              wrap-cells
              bordered
              class="bg-grey-11 my-sticky-header-table mb-8"
              dense
              title
              :data="impactdata"
              :columns="impactcolumns"
              row-key="name"
              :loading="tableLoader"
              table-class
              table-header-class="text-grey-10 text-weight-bolder bg-blue-10"
              :filter="impactfilter"
            >
              <template v-slot:top>
                <span class="text-weight-bolder text-grey-10 text-h5">Impact -- Error Columns & Data</span>
              </template>
              <template v-slot:top-right>
                <q-input
                  borderless
                  dense
                  debounce="300"
                  v-model="impactfilter"
                  placeholder="Search"
                  class="bg-grey-10 px-3 rounded-full"
                >
                  <template v-slot:append>
                    <q-icon name="search" />
                  </template>
                </q-input>
              </template>
              <template v-slot:bottom-row>
                <q-tr>
                  <q-td
                    v-for="(item,index) in impactbottomData"
                    :key="item+index"
                    class="text-weight-bolder text-grey-9 bg-grey-4"
                  >{{item}}</q-td>
                </q-tr>
              </template>
            </q-table>
          </div>
          <div class>
            <q-table
              binary-state-sort
              square
              flat
              wrap-cells
              bordered
              class="bg-grey-11 my-sticky-header-table"
              dense
              title="Integrity -- Error Columns & Data"
              :data="integritydata"
              :columns="integritycolumns"
              row-key="name"
              :loading="tableLoader"
              table-class
              table-header-class="text-grey-9 text-weight-bolder bg-blue-10"
              :filter="integrityfilter"
            >
              <template v-slot:top>
                <span
                  class="text-weight-bolder text-grey-10 text-h5"
                >Integrity -- Error Columns & Data</span>
              </template>
              <template v-slot:top-right>
                <q-input
                  borderless
                  dense
                  debounce="300"
                  v-model="integrityfilter"
                  placeholder="Search"
                  class="bg-grey-5 px-3 rounded-full"
                >
                  <template v-slot:append>
                    <q-icon name="search" />
                  </template>
                </q-input>
              </template>
              <template v-slot:bottom-row>
                <q-tr>
                  <q-td
                    v-for="(item,index) in integritybottomData"
                    :key="item+index"
                    class="text-weight-bolder text-grey-9 bg-grey-4"
                  >{{item}}</q-td>
                </q-tr>
              </template>
            </q-table>
          </div>
        </div>
      </div>
    </div>

    <!-- <div class="flex items-center justify-between py-2 my-4 mx-24">
      <div class="w-3/12 bg-grey-1 rounded-full">
        <q-select
          outlined
          rounded
          options-dense
          v-model="processModel"
          :options="processOptions"
          label="Process"
          dense
          transition-show="jump-up"
          transition-hide="jump-up"
          @input="getInference(processModel,systemModel,dimensionModel)"
        />
      </div>
      <div class="w-3/12 bg-grey-1 rounded-full">
        <q-select
          :disable="disabled"
          rounded
          options-dense
          outlined
          v-model="systemModel"
          :options="systemOptions"
          label="System"
          dense
          transition-show="jump-up"
          transition-hide="jump-up"
          @input="getInference(processModel,systemModel,dimensionModel)"
        />
      </div>
      <div class="w-3/12 bg-grey-1 rounded-full">
        <q-select
          :disable="disabled"
          outlined
          options-dense
          rounded
          v-model="dimensionModel"
          :options="dimensionOptions"
          label="Dimension"
          dense
          transition-show="jump-up"
          transition-hide="jump-up"
          @input="getInference(processModel,systemModel,dimensionModel)"
        />
      </div>
      <div class="w-1/12">
        <q-btn
          dense
          unelevated
          no-caps
          filled
          rounded
          size="md"
          class="w-24 text-bold-soft text-white"
          @click="refreshData"
          style="background-color:#022C4C"
        >
          Refresh
          <q-tooltip>Click to refresh</q-tooltip>
        </q-btn>
      </div>
    </div>

    <div class="px-8">
      <div class>
        <q-table
          binary-state-sort
          square
          flat
          wrap-cells
          bordered
          class="bg-grey-11 my-sticky-header-table mb-8"
          dense
          title
          :data="impactdata"
          :columns="impactcolumns"
          row-key="name"
          :loading="tableLoader"
          table-class
          table-header-class="text-grey-10 text-weight-bolder bg-blue-10"
          :filter="impactfilter"
        >
          <template v-slot:top>
            <span class="text-weight-bolder text-grey-10 text-h5">Impact -- Error Columns & Data</span>
          </template>
          <template v-slot:top-right>
            <q-input
              borderless
              dense
              debounce="300"
              v-model="impactfilter"
              placeholder="Search"
              class="bg-grey-10 px-3 rounded-full"
            >
              <template v-slot:append>
                <q-icon name="search" />
              </template>
            </q-input>
          </template>
          <template v-slot:bottom-row>
            <q-tr>
              <q-td
                v-for="(item,index) in impactbottomData"
                :key="item+index"
                class="text-weight-bolder text-grey-9 bg-grey-4"
              >{{item}}</q-td>
            </q-tr>
          </template>
        </q-table>
      </div>
      <div class>
        <q-table
          binary-state-sort
          square
          flat
          wrap-cells
          bordered
          class="bg-grey-11 my-sticky-header-table"
          dense
          title="Integrity -- Error Columns & Data"
          :data="integritydata"
          :columns="integritycolumns"
          row-key="name"
          :loading="tableLoader"
          table-class
          table-header-class="text-grey-9 text-weight-bolder bg-blue-10"
          :filter="integrityfilter"
        >
          <template v-slot:top>
            <span class="text-weight-bolder text-grey-10 text-h5">Integrity -- Error Columns & Data</span>
          </template>
          <template v-slot:top-right>
            <q-input
              borderless
              dense
              debounce="300"
              v-model="integrityfilter"
              placeholder="Search"
              class="bg-grey-5 px-3 rounded-full"
            >
              <template v-slot:append>
                <q-icon name="search" />
              </template>
            </q-input>
          </template>
          <template v-slot:bottom-row>
            <q-tr>
              <q-td
                v-for="(item,index) in integritybottomData"
                :key="item+index"
                class="text-weight-bolder text-grey-9 bg-grey-4"
              >{{item}}</q-td>
            </q-tr>
          </template>
        </q-table>
      </div>
    </div>-->
  </q-page>
</template>

<script>
import { EventBus } from "./event-bus.js";
import { setTimeout } from "timers";
export default {
  data() {
    return {
      impactdata: [],
      integritydata: [],
      impactcolumns: [],
      integritycolumns: [],
      responseColumns: [],
      systemModel: null,
      systemOptions: null,
      processModel: null,
      dimensionModel: null,
      processOptions: null,
      dimensionOptions: null,
      dataModel: null,
      globalDataModel: null,
      globalOptions: null,
      tableLoader: false,
      impactbottomData: [],
      integritybottomData: [],
      impactfilter: "",
      integrityfilter: "",
      disabled: true,
      transactionsList: null,
      currentTransactionId: null
    };
  },
  created() {
    // TODO: make request only after the saveData is successful.Right now skip and assume the saveData is success.
    // -----------------------   ORIGINAL CONTENT  -----------------------------
    // if (this.$q.localStorage.has("audire_tempProcess")) {
    //   this.globalOptions = JSON.parse(
    //     this.$q.localStorage.getItem("audire_tempProcess")
    //   );
    //   this.processOptions = Object.keys(globalOptions);
    //   this.$q.localStorage.remove("audire_tempProcess");
    // this.dimensionOptions = ["Grn", "Item", "Po", "Vendor", "Company"];
    // } else {
    //   this.$q.notify({
    //     color: "red-10",
    //     position: "top",
    //     textColor: "white",
    //     icon: "fas fa-exclamation-traingle",
    //     message: "Please map and upload a file to see inference."
    //   });
    // }
    // this.processOptions = ["DOMESTIC_PURCHASE_ORDER", "GRN_WRT_PO"];
    this.getAllTransactions();
  },
  methods: {
    async getAllTransactions() {
      let transPromise = await this.$axios.get(
        "http://localhost:7777/transactions"
      );
      this.transactionsList = transPromise.data.msg;
    },
    // changeProcess() {
    //   this.$axios
    //     .post("http://localhost:7777/python", {
    //       org: this.$q.localStorage.getItem("audire_user_org"),
    //       process: "DOMESTIC_PURCHASE_ORDER" //this.processModel
    //     })
    //     .then(response => {
    //       if (
    //         response.data.status !== "failed" &&
    //         response.data.status !== "error"
    //       ) {
    //         this.dataModel = response.data.systemWideFinal;
    //         this.systemOptions = response.data.systems;
    //       } else if (response.data.status === "error") {
    //         this.$q.notify({
    //           color: "amber-2",
    //           position: "top-right",
    //           textColor: "black",
    //           icon: "fas fa-exclamation",
    //           message: response.data.message
    //         });
    //       } else {
    //         this.$q.notify({
    //           color: "amber-14",
    //           position: "top-right",
    //           textColor: "white",
    //           icon: "fas fa-exclamation",
    //           message: "File for the process doesn't exist"
    //         });
    //       }
    //     });
    // },
    // changeData() {
    //   this.columns = [
    //     {
    //       name: "po",
    //       required: true,
    //       label: "PO_NO",
    //       align: "left",
    //       field: "po",
    //       sortable: true
    //     },
    //     {
    //       name: "item",
    //       required: true,
    //       label: "Item_Name",
    //       align: "left",
    //       field: "item",
    //       sortable: true
    //     }
    //   ];
    //   for (let column of this.dataModel[this.systemModel].columns) {
    //     this.columns.push(column);
    //   }
    //   this.columns.push(
    //     {
    //       name: "date",
    //       required: true,
    //       label: "DATE",
    //       align: "left",
    //       field: "date",
    //       sortable: true
    //     },
    //     {
    //       name: "total",
    //       required: true,
    //       label: "Total",
    //       align: "left",
    //       field: "total",
    //       sortable: true
    //     }
    //   );
    //   this.data = this.dataModel[this.systemModel].data;
    // },
    resetData() {
      this.globalDataModel = null;
      this.systemModel = null;
      this.systemOptions = null;
      this.processModel = null;
      this.processOptions = null;
      this.dimensionOptions = null;
      this.dimensionModel = null;
      this.disabled = true;
      this.impactdata = [];
      this.impactcolumns = [];
      this.impactbottomData = [];
      this.integritydata = [];
      this.integritycolumns = [];
      this.integritybottomData = [];
      this.currentTransactionId = null;
    },
    refreshData(id) {
      // let arr = [...Object.values(this.globalOptions)];
      this.resetData();
      this.currentTransactionId = id;
      this.$axios
        .post("http://localhost:7777/refresh", {
          transids: [id]
        })
        .then(response => {
          let temp = this.transactionsList.filter(
            trans => trans.TRANSACTION_ID === id
          );
          this.processOptions = [temp[0].process];
          this.dimensionOptions = ["Grn", "Item", "Po", "Vendor", "Company"];
          this.disabled = false;
          this.globalDataModel = response.data.msg;
        })
        .catch(err => console.error(err));
    },
    getInference(process, system, dimension) {
      if (this.globalDataModel !== null) {
        this.tableLoader = true;
        this.impactdata = [];
        this.impactcolumns = [];
        this.impactbottomData = [];
        this.integritydata = [];
        this.integritycolumns = [];
        this.integritybottomData = [];
        // let data = this.globalDataModel[this.globalOptions[this.processModel]];
        let data = this.globalDataModel[this.currentTransactionId];
        this.systemOptions = data["system"]["systems"];
        if (system === null && dimension === null) {
          this.systemModel = data["system"]["systems"][0];
          this.dimensionModel = "Grn";
          let impactCols = data["impact"][this.systemModel]["grn_cols"];
          let integrityCols = data["integrity"][this.systemModel]["grn_cols"];
          let impactData = data["impact"][this.systemModel]["grn_data"];
          let integrityData = data["integrity"][this.systemModel]["grn_data"];
          for (let col of impactCols) {
            let temp = {
              name: col,
              label: col,
              field: col,
              align: "left",
              sortable: true,
              classes: "bg-grey-2 text-grey-9 text-weight-medium",
              format: val => (typeof val === "number" ? val.toFixed(2) : val)
            };
            this.impactcolumns.push(temp);
          }
          for (let d of impactData) {
            if (d.grn !== "Total") {
              this.impactdata.push(d);
            } else {
              let values = Object.values(d);
              let removed = values.splice(1, 1);
              this.impactbottomData = values.concat(removed);
            }
          }
          for (let col of integrityCols) {
            let temp = {
              name: col,
              label: col,
              field: col,
              align: "left",
              sortable: true,
              classes: "bg-grey-2 text-grey-9 text-weight-medium",
              format: val => (typeof val === "number" ? val.toFixed(2) : val)
            };
            this.integritycolumns.push(temp);
          }
          for (let d of integrityData) {
            if (d.grn !== "Total") {
              this.integritydata.push(d);
            } else {
              let values = Object.values(d);
              let removed = values.splice(1, 1);
              this.integritybottomData = values.concat(removed);
            }
          }
        } else {
          this.systemModel = system;
          this.dimensionModel = dimension;
          let mapper = {
            Grn: ["grn_cols", "grn_data"],
            Po: ["po_cols", "po_data"],
            Item: ["item_cols", "item_data"],
            Vendor: ["vendor_cols", "vendor_data"],
            Company: ["company_cols", "company_data"]
          };
          let impactCols =
            data["impact"][this.systemModel][mapper[dimension][0]];
          let integrityCols =
            data["integrity"][this.systemModel][mapper[dimension][0]];
          let impactData =
            data["impact"][this.systemModel][mapper[dimension][1]];
          let integrityData =
            data["integrity"][this.systemModel][mapper[dimension][1]];
          for (let col of impactCols) {
            let temp = {
              name: col,
              label: col,
              field: col,
              align: "left",
              sortable: true,
              classes: "bg-grey-2 text-grey-9 text-weight-medium",
              format: val => (typeof val === "number" ? val.toFixed(2) : val)
            };
            this.impactcolumns.push(temp);
          }
          for (let d of impactData) {
            if (d[dimension.toLowerCase()] !== "Total") {
              this.impactdata.push(d);
            } else {
              let values = Object.values(d);
              let removed = values.splice(1, 1);
              this.impactbottomData = values.concat(removed);
            }
          }
          for (let col of integrityCols) {
            let temp = {
              name: col,
              label: col,
              field: col,
              align: "left",
              sortable: true,
              classes: "bg-grey-2 text-grey-9 text-weight-medium",
              format: val => (typeof val === "number" ? val.toFixed(2) : val)
            };
            this.integritycolumns.push(temp);
          }
          for (let d of integrityData) {
            if (d[dimension.toLowerCase()] !== "Total") {
              this.integritydata.push(d);
            } else {
              let values = Object.values(d);
              let removed = values.splice(1, 1);
              this.integritybottomData = values.concat(removed);
            }
          }
        }
        // for (let d of data["impact"]["SYS1"]["grn"]) {
        //   if (d["type"] === undefined) {
        //     this.impactdata.push(d);
        //   } else {
        //     let cancel = [
        //       "vendor",
        //       "company",
        //       "po",
        //       "po_value",
        //       "grn",
        //       "item",
        //       "item_value",
        //       "grn_value"
        //     ];
        //     for (let key of Object.keys(d)) {
        //       if (!cancel.includes(key)) {
        //         typeof d[key] === "number"
        //           ? this.bottomData.push(d[key].toFixed(2))
        //           : this.bottomData.push(d[key]);
        //       }
        //     }
        //     this.bottomData.push(d["grn_value"].toFixed(2));
        //   }
        // }
        this.tableLoader = false;
      } else {
        this.processModel = null;
        this.$q.notify({
          color: "amber-11",
          position: "top-right",
          textColor: "black",
          timeout: 1000,
          icon: "fas fa-exclamation",
          message: "Data not available.Press refresh"
        });
      }
    }
  },
  watch: {
    // processModel: function(val) {
    //   if (val !== null) {
    //     this.disabled = false;
    //   } else {
    //     this.disabled = true;
    //   }
    // }
  }
};
</script>

<style scoped>
</style>

