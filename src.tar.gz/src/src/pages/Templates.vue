<template>
  <q-page>
    <div class="flex items-center items-baseline">
      <div class="px-12 py-8 w-6/12">
        <div class="rounded-full bg-grey-1">
          <q-input
            color="indigo-10"
            v-model="searchText"
            outlined
            rounded
            dense
            placeholder="Search"
            @input="searchPage"
          >
            <template v-slot:prepend>
              <q-icon name="search" />
            </template>
          </q-input>
        </div>
      </div>
      <div class="flex items-center w-6/12 justify-end px-12">
        <div class="px-4 m-1">
          <router-link to="/upload">
            <q-btn
              dense
              flat
              rounded
              no-caps
              size="15px"
              class="w-24"
              style="background-color:#022C4C"
            >
              <span class="text-bold-soft text-gray-100 tracking-wide">Upload</span>
            </q-btn>
          </router-link>
        </div>
        <!-- <div class="px-4 m-1">
          <router-link to="/dashboard">
            <q-btn
              dense
              unelevated
              no-caps
              flat
              rounded
              size="md"
              class="w-24"
              style="background-color:#022C4C"
            >
              <span class="text-bold-soft text-gray-100 tracking-wide">View</span>
            </q-btn>
          </router-link>
        </div>-->
      </div>
    </div>

    <div class="flex items-center px-12 pt-4">
      <!-- <div class="flex items-center"> -->
      <div class="w-4/12 px-3 py-4" v-for="(template,index) of templates" :key="template+index">
        <div class="bg-gray-500 px-2 rounded-b-lg bg-grey-1 border-b-4 border-gray-400">
          <div class="flex items-center justify-between pl-4">
            <div class="w-10/12 ellipsis">
              <span class="text-lg font-sans font-bold-soft lowercase">{{template}}</span>
            </div>
            <div class="w-2/12">
              <q-btn flat round icon="fas fa-arrow-circle-down" @click="downloadFile(template)"></q-btn>
            </div>
          </div>
          <div class="py-5 pl-4 ellipsis">
            <span
              class="text-md font-black-soft text-gray-600 tracking-wider lowercase"
            >{{template}}</span>
          </div>
        </div>
      </div>
      <!-- </div> -->
    </div>
  </q-page>
</template>

<script>
import { ApiConstants } from './../const';
export default {
  data() {
    return {
      searchText: null,
      templates: null,
      fallbacktemplates: null
    };
  },
  created() {
    this.getTemplates();
  },
  methods: {
    async getTemplates() {
      let templatePromise = await this.$axios.get(
        ApiConstants.APIURL +  "templates"
      );
      this.fallbacktemplates = templatePromise.data.msg;
      this.templates = templatePromise.data.msg;
    },
    searchPage() {
      if (this.searchText.length < 1) {
        this.templates = this.fallbacktemplates;
      } else {
        this.templates = this.fallbacktemplates.filter(s =>
          s
            .toLowerCase()
            .replace(/\s+/g, "")
            .includes(this.searchText.toLowerCase())
        );
      }
    },
    downloadFile(file) {
      this.$axios
        .post(
          ApiConstants.APIURL +  "download",
          {
            filename: file
          },
          { responseType: "blob" }
        )
        .then(response => {
          let link = document.createElement("a");
          link.href = window.URL.createObjectURL(response.data);
          link.download = file;
          link.click().catch(error => console.error(error));
        });
    }
  }
};
</script>

<style>
</style>