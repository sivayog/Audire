<template>
  <q-page class="antialiased">
    <div class="flex h-screen">
      <div class="flex flex-col items-center m-auto">
        <div>
          <span class="font-serif font-black text-3xl text-gray-900 tracking-widest">AUDIRE</span>
        </div>
        <div>
          <q-form @submit="changePass">
            <div>
              <q-input
                v-model="password"
                placeholder="Password"
                type="password"
                @keydown.space.prevent
                :rules="[
          val => val  && val.length >= 7 || 'Password must be atleast 7 characters in length'
        ]"
              />
            </div>
            <div>
              <q-input
                v-model="confirmPassword"
                placeholder="Retype password"
                type="password"
                @keydown.space.prevent
                :rules="[
          val => val  && val.length >= 7 || 'Password must be atleast 7 characters in length'
        ]"
              />
            </div>
            <div class="flex items-center justify-center pt-5">
              <q-btn
                unelevated
                label="Submit"
                no-caps
                size="md"
                type="submit"
                color="indigo-9"
                :loading="submitLoading"
                class="mr-1"
              />
            </div>
          </q-form>
        </div>

        <!-- <q-card bordered class="bg-grey-2 q-mt-lg" flat>
          <q-card-section>
            <q-form>
              <q-input
                dense
                filled
                type="password"
                v-model="password"
                placeholder="Enter New Password "
                lazy-rules
                @keydown.space.prevent
                :rules="[
                 v => v && v.length >=7|| 'Password must be atleast 7 characters in length'
        ]"
              />
              <q-input
                dense
                filled
                type="password"
                v-model="confirmPassword"
                placeholder="Re-Enter New Password "
                lazy-rules
                @keydown.space.prevent
                :rules="[
                v => v && v.length >=7|| 'Password must be atleast 7 characters in length'
        ]"
              />
              <div class="flex flex-center">
                <q-btn label="Submit" @click="changePass" color="primary"></q-btn>
              </div>
            </q-form>
          </q-card-section>
        </q-card>-->
      </div>
    </div>
  </q-page>
</template>

<script>
import { ApiConstants } from './../const';
import { EventBus } from "./event-bus.js";
export default {
  name: "changePassword",
  data() {
    return {
      password: null,
      confirmPassword: null,
      submitLoading: false,
      isPwd: true
    };
  },
  methods: {
    changePass() {
      this.submitLoading = true;
      const payload = {
        password: this.password
      };
      if (this.password === this.confirmPassword) {
        this.$axios
          .post(ApiConstants.LOGINAPIURL +  "changePass", payload, {
            headers: { authorization: this.$route.query.token }
          })
          .then(response => {
            this.submitLoading = false;
            if (response.data.status === "failed") {
              this.$q.notify({
                color: "red-2",
                position: "top-right",
                textColor: "black",
                icon: "fas fa-exclamation",
                message: `Token Expired`
              });
            } else {
              this.$q.notify({
                color: "red-2",
                position: "top-right",
                textColor: "black",
                icon: "fas fa-exclamation",
                message: `Password changed Successfully.`
              });
              this.$router.push("/");
            }
          })
          .catch(err => {
            console.error(err);
          });
      } else {
        this.submitLoading = false;
        this.$q.notify({
          color: "red-2",
          position: "top-right",
          textColor: "black",
          icon: "fas fa-exclamation",
          message: `Entered passwords din't match.`
        });
      }
    }
  },
  created() {}
};
</script>

<style scoped>
</style>