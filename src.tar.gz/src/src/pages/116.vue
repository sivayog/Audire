<template>
  <q-page>
    <div class="flex items-center">
      <div class="px-12 py-8 w-6/12">
        <div class="rounded-full bg-grey-1">
          <q-input
            color="indigo-10"
            v-model="searchText"
            outlined
            rounded
            dense
            placeholder="Search location or Lease Id"
            @input="searchPage"
          >
            <template v-slot:prepend>
              <q-icon name="search" />
            </template>
          </q-input>
        </div>
      </div>
      <div class="px-2 w-2/12">
        <q-select
          rounded
          outlined
          hide-bottom-space
          v-model="listLeaseModel"
          :options="listLeaseOptions"
          label="Lease Status"
          class="w-auto"
          size="md"
          dense
          style="min-width:8rem"
          options-dense
          transition-show="jump-up"
          transition-hide="jump-up"
        />
      </div>
      <div class="px-2 w-2/12">
        <q-select
          rounded
          outlined
          hide-bottom-space
          v-model="listProjectModel"
          :options="listProjectOptions"
          label="Project Status"
          class="w-auto"
          size="md"
          dense
          style="min-width:8rem"
          options-dense
          transition-show="jump-up"
          transition-hide="jump-up"
        />
      </div>
      <div class="flex items-center w-2/12 justify-end px-12">
        <div class="px-4 m-1">
          <!-- <router-link to="/upload"> -->
          <q-btn
            dense
            flat
            rounded
            no-caps
            size="15px"
            class="w-24"
            style="background-color:#022C4C"
            @click="listLease"
          >
            <span class="text-bold-soft text-gray-100 tracking-wide">Load</span>
          </q-btn>
          <!-- </router-link> -->
        </div>
      </div>
    </div>
    <div class="flex items-top px-12 py-4 overflow-y-auto">
      <div class="w-2/12">
        <q-list>
          <q-item
            clickable
            @click="getInference(item.id)"
            v-for="(item, index) in leaseIds"
            :key="item + index"
            class="bg-grey-4 border-b-2 border-gray-400"
          >
            <div>
              <div class="py-2">
                <span
                  class="text-md font-sans font-black tracking-widest text-gray-800 pr-4"
                >{{ item.id }}</span>
                <span
                  class="pl-8 text-sm font-semibold text-gray-700 text-lowercase tracking-wide"
                >{{ item.date }}</span>
              </div>
              <div>
                <span
                  class="text-sm font-sans font-semibold text-gray-700 tracking-wide"
                >{{ item.location }}</span>
              </div>
            </div>
          </q-item>
        </q-list>
      </div>
      <div class="w-10/12 pl-5 pr-4 flex items-center" v-if="noids">
        <div class="px-12 mx-auto">
          <span
            class="font-sans font-semibold text-gray-700 tracking-wide text-xl"
          >No data available.Please select a lease</span>
        </div>
      </div>
      <!--TODO: ------------------- FOR RENDERING PURPOSES -------------------->
      <div class="w-10/12 pl-5 pr-4" v-if="allids">
        <div>
          <!-- <div class="flex justify-center pb-8">
            <span
              class="border-b-4 border-gray-700 font-black text-lg text-gray-700"
            >{{leaseIdModel}}</span>
          </div>-->
          <div
            class="text-white py-1 px-4 text-md rounded-lg text-gray-700 font-semibold tracking-wider"
            style="background-color:#022C4C"
          >Header Info</div>
          <div class="bg-grey-1 rounded-lg mt-2 mb-4 pl-4 py-2">
            <div>
              <span class="text-md tracking-wide font-bold text-gray-600">Internal Id :</span>
              <span
                class="text-md tracking-wide font-bold text-gray-800 px-2"
              >{{ headerData["Lease Internal ID"] }}</span>
            </div>
            <div class="flex items-center justify-between pt-1">
              <div class="w-3/12">
                <span class="text-md tracking-wide font-bold text-gray-600">External Id :</span>
                <span
                  class="text-md tracking-wide font-bold text-gray-800 px-2"
                >{{ headerData["Lease ID"] }}</span>
              </div>
              <div class="w-3/12">
                <span class="text-md tracking-wide font-bold text-gray-600">Execution Date :</span>
                <span class="text-md tracking-wide font-bold text-gray-800 px-2">
                  {{
                  new Date(
                  headerData["Lease Execution Date"]
                  ).toLocaleDateString()
                  }}
                </span>
              </div>
              <div class="w-3/12">
                <span class="text-md tracking-wide font-bold text-gray-600">Start Date :</span>
                <span class="text-md tracking-wide font-bold text-gray-800 px-2">
                  {{
                  new Date(
                  headerData["Lease Start Date"]
                  ).toLocaleDateString()
                  }}
                </span>
              </div>
              <div class="w-3/12">
                <span class="text-md tracking-wide font-bold text-gray-600">Total days :</span>
                <span
                  class="text-md tracking-wide font-bold text-gray-800 px-2"
                >{{ headerData["Lease Total Days"] }}</span>
              </div>
            </div>
            <div class="flex items-center justify-between pt-1">
              <div class="w-3/12">
                <span class="text-md tracking-wide font-bold text-gray-600">Category :</span>
                <span
                  class="text-md tracking-wide font-bold text-gray-800 px-2"
                >{{ headerData["Lease Category"] }}</span>
              </div>
              <div class="w-3/12">
                <span class="text-md tracking-wide font-bold text-gray-600">Execution Place :</span>
                <span
                  class="text-md tracking-wide font-bold text-gray-800 px-2"
                >{{ headerData["Lease Execution Place"] }}</span>
              </div>
              <div class="w-3/12">
                <span class="text-md tracking-wide font-bold text-gray-600">End Date :</span>
                <span class="text-md tracking-wide font-bold text-gray-800 px-2">
                  {{
                  new Date(headerData["Lease End Date"]).toLocaleDateString()
                  }}
                </span>
              </div>
              <div class="w-3/12">
                <span class="text-md tracking-wide font-bold text-gray-600">Total Period :</span>
                <span
                  class="text-md tracking-wide font-bold text-gray-800 px-2"
                >{{ headerData["Lease Total Period"] }}</span>
              </div>
            </div>
            <div class="pt-1">
              <span class="text-md tracking-wide font-bold text-gray-600">Name :</span>
              <span
                class="text-md tracking-wide font-bold text-gray-800 px-2"
              >{{ headerData["Lease Nature"] }}</span>
            </div>
          </div>
        </div>
        <div>

        <!-- Modifiers starts here -->
        <div  class="text-white py-1 px-4 text-md rounded-lg text-gray-700 font-semibold tracking-wider"
          style="background-color:#022C4C" >Modifiers</div>
        <div v-for="(modifier, index) in modifierData" :key="`modifier123-${index}`" class="bg-grey-1 rounded-lg mt-2 mb-4 pl-4 py-2">
              <div class="flex items-center justify-between pt-1">
                  <div class="w-3/12">
                    <span class="text-md tracking-wide font-bold text-gray-600">Contr.Signed Date :</span>
                    <span 
                    v-if="modifier['LEMod_ContractSignedDt']" 
                    class="text-md tracking-wide font-bold text-gray-800 px-2"> {{  new Date( modifier["LEMod_ContractSignedDt"] ).toLocaleDateString() }}</span>
                  </div> 
                  <div class="w-3/12">
                    <span class="text-md tracking-wide font-bold text-gray-600">From Version :</span>
                    <span  v-if="modifier['LEMod_FromVersion']" class="text-md tracking-wide font-bold text-gray-800 px-2">
                      {{  modifier["LEMod_FromVersion"]  }}
                    </span>
                  </div>
                  <div class="w-3/12">
                    <span class="text-md tracking-wide font-bold text-gray-600">Mod Internal Id</span>
                    <span  v-if="modifier['LEMod_InternalID']" class="text-md tracking-wide font-bold text-gray-800 px-2">
                      {{  modifier["LEMod_InternalID"]  }}
                    </span>
                  </div>                 
              </div>
              <div class="flex items-center justify-between pt-1">    
               <div class="w-3/12">
                    <span class="text-md tracking-wide font-bold text-gray-600">Effective Date of Modification :</span>
                    <span   v-if="modifier['LEMod_EffectiveDtOfModification']"  class="text-md tracking-wide font-bold text-gray-800 px-2">
                      {{  new Date( modifier["LEMod_EffectiveDtOfModification"] ).toLocaleDateString() }}                      
                    </span>
                  </div>                  
                  <div class="w-3/12">
                    <span class="text-md tracking-wide font-bold text-gray-600">To Version :</span>
                    <span  v-if="modifier['LEMod_ToVersion']" class="text-md tracking-wide font-bold text-gray-800 px-2">
                      {{  modifier["LEMod_ToVersion"]  }}
                    </span>
                  </div>
                  <div class="w-3/12"></div>
              </div>
              <br />
              <div class="flex items-center justify-between pt-1">                  
                  <div  class="w-3/12">
                    <span class="text-md tracking-wide font-bold text-gray-600">Lease term Mode :</span>
                    <span  v-if="modifier['LEMod_LTerm_Mode']" class="text-md tracking-wide font-bold text-gray-800 px-2">
                      {{ modifier["LEMod_LTerm_Mode"] }}
                    </span>
                  </div>
                  <div class="w-3/12">
                    <span class="text-md tracking-wide font-bold text-gray-600">Decrease in Scope:</span>
                    <span v-if="modifier['LEMod_ScopeDec_Mode']" class="text-md tracking-wide font-bold text-gray-800 px-2">
                      {{ modifier["LEMod_ScopeDec_Mode"] }}
                    </span>
                  </div>
                  <div  class="w-3/12">
                    <span class="text-md tracking-wide font-bold text-gray-600">Increase in Scope:</span>
                    <span v-if="modifier['LEMod_ScopeInc_Modifier']" class="text-md tracking-wide font-bold text-gray-800 px-2">
                      {{ modifier["LEMod_ScopeInc_Modifier"] }}
                    </span>
                  </div>
                 
              </div>
              <div class="flex items-center justify-between pt-1">
                  <div class="w-3/12">
                    <span class="text-md tracking-wide font-bold text-gray-600">Revised End Date :</span>
                    <span  v-if="modifier['LEMod_LTerm_RevisedEndDt']"  class="text-md tracking-wide font-bold text-gray-800 px-2">
                     {{  new Date( modifier["LEMod_LTerm_RevisedEndDt"] ).toLocaleDateString() }}
                    </span>
                  </div>  
                  <div  class="w-3/12">
                    <span class="text-md tracking-wide font-bold text-gray-600">Scope Decrement Par value :</span>
                    <span v-if="modifier['LEMod_ScopeDec_ParValue']" class="text-md tracking-wide font-bold text-gray-800 px-2">
                      {{ modifier["LEMod_ScopeDec_ParValue"] }}
                    </span>
                  </div>   
                  <div  class="w-3/12">
                    <span class="text-md tracking-wide font-bold text-gray-600">Commencement Date :</span>
                    <span v-if="modifier['LEMod_ScopeInc_CommDt']" class="text-md tracking-wide font-bold text-gray-800 px-2">
                      {{ new Date(modifier["LEMod_ScopeInc_CommDt"] ).toLocaleDateString() }}
                    </span>
                  </div>  
              </div>
              <br/>
              <div class="flex items-center justify-between pt-1">
                  <div  class="w-3/12">
                    <span class="text-md tracking-wide font-bold text-gray-600">Change in Discount:</span>
                    <span v-if="modifier['LEMod_DiscRate_Modifier']" class="text-md tracking-wide font-bold text-gray-800 px-2">
                      {{ modifier["LEMod_DiscRate_Modifier"] }}
                    </span>
                  </div> 
                  <div  class="w-3/12">
                    <span class="text-md tracking-wide font-bold text-gray-600">Change in Rent:</span>
                    <span v-if="modifier['LEMod_RentChng_Modifier']" class="text-md tracking-wide font-bold text-gray-800 px-2">
                      {{ modifier["LEMod_RentChng_Modifier"] }}
                    </span>
                  </div>  
                  <div  class="w-3/12"></div>
              </div>
              <div class="flex items-center justify-between pt-1">
                  <div  class="w-3/12">
                    <span class="text-md tracking-wide font-bold text-gray-600">Mode:</span>
                    <span v-if="modifier['LEMod_DiscRate_Modifier']" class="text-md tracking-wide font-bold text-gray-800 px-2">
                      {{ modifier["LEMod_DiscRate_Modifier"] }}
                    </span>
                  </div> 
                  <div  class="w-3/12">
                    <span class="text-md tracking-wide font-bold text-gray-600">Contribution to ROU asset:</span>
                    <span v-if="modifier['LEMod_RentChng_Cont']" class="text-md tracking-wide font-bold text-gray-800 px-2">
                      {{ modifier["LEMod_RentChng_Cont"] }}
                    </span>
                  </div>  
                  <div  class="w-3/12"></div>
              </div>
              <div class="flex items-center justify-between pt-1">
                  <div  class="w-3/12">
                    <span class="text-md tracking-wide font-bold text-gray-600">Revised% :</span>
                    <span v-if="modifier['LEMod_DiscRate_Revised']" class="text-md tracking-wide font-bold text-gray-800 px-2">
                      {{ modifier["LEMod_DiscRate_Revised"] }}
                    </span>
                  </div> 
                  <div  class="w-3/12">
                  </div>  
                  <div  class="w-3/12"></div>
              </div>


            <!-- --------------- -->
            
            
<!-- modifierPaymentcolumns: [
        { name: 'LE_Pymt_Reason', align: 'center', label: 'Payment Reason', field: 'LE_Pymt_Reason', sortable: true },
        { name: 'LE_Pymt_Due_Days', align: 'center', label: 'Payment Due Days', field: 'LE_Pymt_Due_Days', sortable: true },
        { name: 'LE_Pymt_Frequency', align: 'center', label: 'Payment frequency', field: 'LE_Pymt_Frequency', sortable: true },
        { name: 'LE_Pymt_Occurance_Cnt', align: 'center', label: 'Payment Occurance Count', field: 'LE_Pymt_Occurance_Cnt', sortable: true },
        { name: 'LE_Pymt_Cycle_Start', align: 'center', label: 'Payment Cycle Start', field: 'LE_Pymt_Cycle_Start', sortable: true },
        { name: 'LE_Pymt_Amt', align: 'center', label: 'Payment Amount', field: 'LE_Pymt_Amt', sortable: true },
        { name: 'LE_Pymt_Type', align: 'center', label: 'Payment Type', field: 'LE_Pymt_Type', sortable: true },
        { name: 'LE_Pymt_Effective_from', align: 'center', label: 'Payment Effective From', field: 'LE_Pymt_Effective_from', sortable: true },
        { name: 'LE_Pymt_Effective_to', align: 'center', label: 'Payment Effective To', field: 'LE_Pymt_Effective_to', sortable: true },
      ], -->
        <!-- <pre>
          {{modifier['Pymt']}}

        </pre> -->
              <div  v-if="modifier['Pymt']"  >
                  <div  >
                      <template>
                          <div class="flex items-center justify-between pt-1">
                            <q-list bordered class="rounded-borders" style="width:98%">
                              <q-expansion-item   expand-separator :label="'Payments  '" default-opened>
                                <q-card>
                                  <q-card-section style="padding:3px;">
                                    <div class="px-4 py-4 bg-grey-1 rounded-lg mt-2 mb-4" style="overflow: scroll;">
                                        <table class ="modifier-payment-table">
                                          <thead>
                                              <tr>
                                                <th >Type</th>
                                                <th >Reason</th>
                                                <th >Payment Effective From</th>
                                                <th >Payment Effective To</th>
                                                <th >Payment Amount</th>                                                
                                                <th >Payment frequency</th>
                                                <th >Payment Due At</th>
                                                <th >Payment Due Days</th>
                                                <!-- <th >Payment Occurance Count</th>
                                                <th >Payment Cycle Start</th> -->
                                                
                                                
                                                
                                              </tr>
                                          </thead>
                                          <tbody>
                                            <tr  v-for="(payment, index) in modifier['Pymt']" :key="'paymentModifierData' + index">
                                              <td>{{payment['LE_Pymt_Type'] ? payment['LE_Pymt_Type'] : payment['LEMod_Pymt_Type']}}</td>
                                              <td>{{payment['LE_Pymt_Reason'] ? payment['LE_Pymt_Reason'] : payment['LEMod_Pymt_Reason']}}</td>
                                              <td>{{payment['LE_Pymt_Effective_from'] ? new Date(payment['LE_Pymt_Effective_from']).toLocaleString() :  new Date(payment['LEMod_Pymt_Effective_from']).toLocaleString()}}</td>
                                              <td>{{payment['LE_Pymt_Effective_to'] ? new Date(payment['LE_Pymt_Effective_to']).toLocaleString() :  new Date(payment['LEMod_Pymt_Effective_to']).toLocaleString()}}</td>
                                              <td>{{payment['LE_Pymt_Amt'] ? payment['LE_Pymt_Amt'] : payment['LEMod_Pymt_Amt']}}</td>
                                              <td>{{payment['LE_Pymt_Frequency'] ? payment['LE_Pymt_Frequency'] : payment['LEMod_Pymt_Frequency']}}</td>                                              
                                              <td>{{payment['LE_Pymt_Due_At'] ? payment['LE_Pymt_Due_At'] : payment['LEMod_Pymt_Due_At']}}</td>
                                              <td>{{payment['LE_Pymt_Due_Days'] ? payment['LE_Pymt_Due_Days'] : payment['LEMod_Pymt_Due_Days']}}</td>




                                              <!-- <td>{{payment['LE_Pymt_Occurance_Cnt'] ? payment['LE_Pymt_Occurance_Cnt'] : ''}}</td>
                                               -->
                                              
                                              
                                              
                                            </tr>
                                          </tbody>
                                        </table>
                                    </div>
                                  </q-card-section>
                                </q-card>
                              </q-expansion-item>                        
                            </q-list>
                          </div>
                        </template>
                  </div>
              </div>



        </div>
        <!-- Modifiers Ends here -->
          <div
            class="text-white py-1 px-4 text-md rounded-lg text-gray-700 font-semibold tracking-wider"
            style="background-color:#022C4C"
          >Approach Summary</div>
          <div class="px-4 py-2 bg-grey-1 rounded-lg mt-2 mb-4">
            <div class="py-4">
              <q-markup-table wrap-cells separator="cell" flat bordered>
                <thead>
                  <tr>
                    <th class="text-right"></th>
                    <th
                      class="text-center"
                      colspan="3"
                      style="color:#1a202c;	font-size: 1rem;	font-weight: 700; font-size: 1rem;"
                    >Full Restrospective</th>
                    <th
                      class="text-center"
                      colspan="2"
                      style="color:#1a202c;	font-size: 1rem;	font-weight: 700; font-size: 1rem;"
                    >Modified Retrospective</th>
                    <th
                      class="text-center"
                      colspan="2"
                      style="color:#1a202c;	font-size: 1rem;	font-weight: 700; font-size: 1rem;"
                    >Modified Simplified</th>
                  </tr>
                  <tr>
                    <th class="text-right"></th>
                    <th
                      class="text-right"
                      v-for="(item, index) in dates"
                      :key="item + index"
                      style="color:#1a202c;	font-size: 1rem;	font-weight: 700; font-size: 0.85rem;text-align: center"
                    >{{ item }}</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td
                      class="text-left"
                      v-for="(item, index) in rou"
                      :key="item + index"
                      style="color:#2d3748;	font-size: 1rem;	font-weight: 700; font-size: 0.85rem;text-align: center"
                    >{{ item }}</td>
                  </tr>
                  <tr>
                    <td
                      class="text-left"
                      v-for="(item, index) in lease"
                      :key="item + index"
                      style="color:#2d3748;	font-size: 1rem;	font-weight: 700; font-size: 0.85rem;text-align: center"
                    >{{ item }}</td>
                  </tr>
                  <tr>
                    <td
                      class="text-left"
                      v-for="(item, index) in retearn"
                      :key="item + index"
                      style="color:#2d3748;	font-size: 1rem;	font-weight: 700; font-size: 0.85rem;text-align: center"
                    >{{ item }}</td>
                  </tr>
                </tbody>
              </q-markup-table>
            </div>
            <div class="flex items-center justify-center py-2">
              <!-- <div class="w-3/12 px-4">
                <q-select
                  label="Select approach"
                  outlined
                  rounded
                  options-dense
                  v-model="approachModel"
                  :options="approachOptions"
                  dense
                  transition-show="jump-up"
                  transition-hide="jump-up"
                />
              </div>-->
              <!-- <div class="w-3/12 px-4">
                <q-btn
                  dense
                  unelevated
                  no-caps
                  flat
                  rounded
                  size="md"
                  class="w-24"
                  style="background-color:#022C4C"
                  @click="saveApproach"
                >
                  <span class="text-bold-soft text-gray-100 tracking-wide">Save</span>
                </q-btn>
              </div>-->
            </div>
          </div>
        </div>
        <div>
          <div class="flex items-center" style="background-color:#022C4C">
            <div
              class="text-white py-1 px-4 text-md rounded-lg text-gray-700 font-semibold tracking-wider w-6/12"
            >Lessor</div>
            <div
              class="text-white py-1 px-4 text-md rounded-lg text-gray-700 font-semibold tracking-wider w-6/12"
            >On Behalf of</div>
          </div>
          <div class="flex items-center">
            <div class="bg-grey-1 rounded-lg mt-2 mb-4 border-r-2 w-6/12 pl-4 py-2">
              <div class="flex items-center justify-between pt-1">
                <div class="w-6/12">
                  <span class="text-md tracking-wide font-bold text-gray-600">Id :</span>
                  <span
                    class="text-md tracking-wide font-bold text-gray-800 px-2"
                  >{{ lessorData["Lessor ID Ref"] }}</span>
                </div>
                <div class="w-6/12">
                  <span class="text-md tracking-wide font-bold text-gray-600">Name :</span>
                  <span
                    class="text-md tracking-wide font-bold text-gray-800 px-2"
                  >{{ lessorData["Lessor Name"] }}</span>
                </div>
              </div>
              <div class="flex items-center justify-between pt-1">
                <div class="w-6/12">
                  <span class="text-md tracking-wide font-bold text-gray-600">Address 1 :</span>
                  <span
                    class="text-md tracking-wide font-bold text-gray-800 px-2"
                  >{{ lessorData["Lessor Address Line (1)"] }}</span>
                </div>
                <div class="w-6/12">
                  <span class="text-md tracking-wide font-bold text-gray-600">Address 2 :</span>
                  <span
                    class="text-md tracking-wide font-bold text-gray-800 px-2"
                  >{{ lessorData["Lessor Address Line (2)"] }}</span>
                </div>
              </div>
              <div class="flex items-center justify-between pt-1">
                <div class>
                  <span class="text-md tracking-wide font-bold text-gray-600">Location :</span>
                  <span
                    class="text-md tracking-wide font-bold text-gray-800 px-2"
                  >{{ lessorData["Lessor Location"] }}</span>
                </div>
              </div>
              <div class="flex items-center justify-between pt-1">
                <div class="w-6/12">
                  <span class="text-md tracking-wide font-bold text-gray-600">City :</span>
                  <span
                    class="text-md tracking-wide font-bold text-gray-800 px-2"
                  >{{ lessorData["Lessor City"] }}</span>
                </div>
                <div class="w-6/12">
                  <span class="text-md tracking-wide font-bold text-gray-600">Pincode :</span>
                  <span
                    class="text-md tracking-wide font-bold text-gray-800 px-2"
                  >{{ lessorData["Lessor PinCode"] }}</span>
                </div>
              </div>
              <div class="flex items-center justify-between pt-1">
                <div class>
                  <span class="text-md tracking-wide font-bold text-gray-600">Represented By :</span>
                  <span
                    class="text-md tracking-wide font-bold text-gray-800 px-2"
                  >{{ lessorData["Lessor Represented By (1)"] }}</span>
                </div>
              </div>
            </div>
            <div class="pl-4 py-2 bg-grey-1 rounded-lg mt-2 mb-4 w-6/12">
              <div class="flex items-center justify-between pt-1">
                <div class="w-6/12">
                  <span class="text-md tracking-wide font-bold text-gray-600">Id :</span>
                  <span
                    class="text-md tracking-wide font-bold text-gray-800 px-2"
                  >{{ lessorData["Lessor ID Ref"] }}</span>
                </div>
                <div class="w-6/12">
                  <span class="text-md tracking-wide font-bold text-gray-600">Name :</span>
                  <span
                    class="text-md tracking-wide font-bold text-gray-800 px-2"
                  >{{ lessorData["Lessor Name"] }}</span>
                </div>
              </div>
              <div class="flex items-center justify-between pt-1">
                <div class="w-6/12">
                  <span class="text-md tracking-wide font-bold text-gray-600">Address 1 :</span>
                  <span
                    class="text-md tracking-wide font-bold text-gray-800 px-2"
                  >{{ lessorData["Lessor Address Line (1)"] }}</span>
                </div>
                <div class="w-6/12">
                  <span class="text-md tracking-wide font-bold text-gray-600">Address 2 :</span>
                  <span
                    class="text-md tracking-wide font-bold text-gray-800 px-2"
                  >{{ lessorData["Lessor Address Line (2)"] }}</span>
                </div>
              </div>
              <div class="flex items-center justify-between pt-1">
                <div class>
                  <span class="text-md tracking-wide font-bold text-gray-600">Location :</span>
                  <span
                    class="text-md tracking-wide font-bold text-gray-800 px-2"
                  >{{ lessorData["Lessor Location"] }}</span>
                </div>
              </div>
              <div class="flex items-center justify-between pt-1">
                <div class="w-6/12">
                  <span class="text-md tracking-wide font-bold text-gray-600">City :</span>
                  <span
                    class="text-md tracking-wide font-bold text-gray-800 px-2"
                  >{{ lessorData["Lessor City"] }}</span>
                </div>
                <div class="w-6/12">
                  <span class="text-md tracking-wide font-bold text-gray-600">Pincode :</span>
                  <span
                    class="text-md tracking-wide font-bold text-gray-800 px-2"
                  >{{ lessorData["Lessor PinCode"] }}</span>
                </div>
              </div>
              <div class="flex items-center justify-between pt-1">
                <div class>
                  <span class="text-md tracking-wide font-bold text-gray-600">Represented By :</span>
                  <span
                    class="text-md tracking-wide font-bold text-gray-800 px-2"
                  >{{ lessorData["Lessor Represented By (1)"] }}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div>
          <div
            class="text-white py-1 px-4 text-md rounded-lg text-gray-700 font-semibold tracking-wider"
            style="background-color:#022C4C"
          >Payment Information</div>
          <div
            class="pl-4 py-2 bg-grey-1 rounded-lg mt-2 mb-4"
            v-for="(item, index) in paymentsData"
            :key="item + index"
          >
            <div class="flex items-center justify-between pt-1">
              <div class>
                <span class="text-md tracking-wide font-bold text-gray-600">Internal Id :</span>
                <span
                  class="text-md tracking-wide font-bold text-gray-800 px-2"
                >{{ item["Payment InternalID"] }}</span>
              </div>
            </div>
            <div class="flex items-center justify-between pt-1">
              <div class="w-3/12">
                <span class="text-md tracking-wide font-bold text-gray-600">Type :</span>
                <span
                  class="text-md tracking-wide font-bold text-gray-800 px-2"
                >{{ item["Payment Type"] }}</span>
              </div>
              <div class="w-3/12">
                <span class="text-md tracking-wide font-bold text-gray-600">Frequency :</span>
                <span
                  class="text-md tracking-wide font-bold text-gray-800 px-2"
                >{{ item["Payment Frequency"] }}</span>
              </div>
              <div class="w-3/12">
                <span class="text-md tracking-wide font-bold text-gray-600">Amount :</span>
                <span
                  class="text-md tracking-wide font-bold text-gray-800 px-2"
                >{{ item["Payment Amount"] }}</span>
              </div>
              <div class="w-3/12">
                <span class="text-md tracking-wide font-bold text-gray-600">Exe - Direct Cost :</span>
                <span
                  class="text-md tracking-wide font-bold text-gray-800 px-2"
                >{{ item["Initial Direct Costs"] }}</span>
              </div>
            </div>
            <div class="flex items-center justify-between pt-1">
              <div class="w-3/12">
                <span class="text-md tracking-wide font-bold text-gray-600">Reason :</span>
                <span
                  class="text-md tracking-wide font-bold text-gray-800 px-2"
                >{{ item["Reason for Payment"] }}</span>
              </div>
              <div class="w-3/12">
                <span class="text-md tracking-wide font-bold text-gray-600">Due At :</span>
                <span
                  class="text-md tracking-wide font-bold text-gray-800 px-2"
                >{{ item["Payment Due At"] }}</span>
              </div>
              <div class="w-3/12">
                <span class="text-md tracking-wide font-bold text-gray-600">Occurence count :</span>
                <span
                  class="text-md tracking-wide font-bold text-gray-800 px-2"
                >{{ item["Payment Occurance Cnt"] }}</span>
              </div>
              <div class="w-3/12">
                <span class="text-md tracking-wide font-bold text-gray-600">Exe - Total incentive :</span>
                <span class="text-md tracking-wide font-bold text-gray-800 px-2">
                  {{
                  item["Incentive Payment made before commencement"]
                  }}
                </span>
              </div>
            </div>
            <div class="flex items-center justify-between pt-1">
              <div class="w-3/12">
                <span class="text-md tracking-wide font-bold text-gray-600">Effective from :</span>
                <span class="text-md tracking-wide font-bold text-gray-800 px-2">
                  {{
                  new Date(
                  item["Payment Effective From"]
                  ).toLocaleDateString()
                  }}
                </span>
              </div>
              <div class="w-3/12">
                <span class="text-md tracking-wide font-bold text-gray-600">Due days :</span>
                <span
                  class="text-md tracking-wide font-bold text-gray-800 px-2"
                >{{ item["Payment Due Days"] }}</span>
              </div>
              <div class="w-3/12"></div>
              <div class="w-3/12">
                <span class="text-md tracking-wide font-bold text-gray-600">Exe - PreComm. :</span>
                <span
                  class="text-md tracking-wide font-bold text-gray-800 px-2"
                >{{ item["Total Pre Commencement"] }}</span>
              </div>
            </div>
            <div class="flex items-center justify-between pt-1">
              <div class="w-3/12">
                <span class="text-md tracking-wide font-bold text-gray-600">Effective To :</span>
                <span class="text-md tracking-wide font-bold text-gray-800 px-2">
                  {{
                  new Date(item["Payment Effective To"]).toLocaleDateString()
                  }}
                </span>
              </div>
              <div class="w-3/12">
                <span class="text-md tracking-wide font-bold text-gray-600">Cycle start :</span>
                <span
                  class="text-md tracking-wide font-bold text-gray-800 px-2"
                >{{ item["Payment Cycle Start Type"] }}</span>
              </div>
              <div class="w-3/12">
                <span class="text-md tracking-wide font-bold text-gray-600">Total amount :</span>
                <span
                  class="text-md tracking-wide font-bold text-gray-800 px-2"
                >{{ item["Total Payment Amount"] }}</span>
              </div>
              <div class="w-3/12">
                <span class="text-md tracking-wide font-bold text-gray-600">Total exe cost :</span>
                <span
                  class="text-md tracking-wide font-bold text-gray-800 px-2"
                >{{ item["Total Executory Costs"] }}</span>
              </div>
            </div>
            <div class="flex items-center justify-end pt-1 px-2">
              <div class="bg-grey-4 p-1 px-2 rounded-lg font-semibold tracking-wide">
                <span class="text-md tracking-wide font-bold text-gray-700">Min payment :</span>
                <span
                  class="text-md tracking-wide font-bold text-gray-800 px-2"
                >{{ item["Total Payment Amount"] }}</span>
              </div>
            </div>
          </div>
        </div>
        <div>
          <div class="flex items-center justify-between" style="background-color:#022C4C">
            <span
              class="text-white py-1 px-4 text-md rounded-lg text-gray-700 font-semibold tracking-wider"
            >Discounting Rate</span>
            <span>
              <download-excel
                :data="discountingrateData"
                type="csv"
                default-value="-"
                name="Disc_Rate.csv"
              >
                <q-btn
                  dense
                  flat
                  icon="fas fa-download"
                  rounded
                  no-caps
                  size="10px"
                  class="w-20"
                  color="white"
                ></q-btn>
              </download-excel>
            </span>
          </div>
          <div class="px-4 py-4 bg-grey-1 rounded-lg mt-2 mb-4">
            <q-table
              binary-state-sort
              square
              flat
              wrap-cells
              bordered
              dense
              :data="discountingrateData"
              :columns="discountingrateColumns"
              row-key="name"
            />
          </div>
        </div>
        <div>
          <div class="flex items-center justify-between" style="background-color:#022C4C">
            <span
              class="text-white py-1 px-4 text-md rounded-lg text-gray-700 font-semibold tracking-wider"
            >Asset Schedule</span>
            <!-- <span>{{approachModel}}</span> -->
            <span>
              <download-excel :data="assetscheduleData" type="csv" name="Asset_Schedule.csv">
                <q-btn
                  dense
                  flat
                  icon="fas fa-download"
                  rounded
                  no-caps
                  size="10px"
                  class="w-20"
                  color="white"
                ></q-btn>
              </download-excel>
            </span>
          </div>
          <div class="px-4 py-4 bg-grey-1 rounded-lg mt-2 mb-4">
            <q-table
              binary-state-sort
              square
              flat
              wrap-cells
              bordered
              dense
              :data="assetscheduleData"
              :columns="assetscheduleColumns"
              row-key="name"
            />
          </div>
        </div>
        <div>
          <div class="flex items-center justify-between" style="background-color:#022C4C">
            <span
              class="text-white py-1 px-4 text-md rounded-lg text-gray-700 font-semibold tracking-wider"
            >PV Calculations</span>
            <span
              class="text-white py-1 px-4 text-sm rounded-lg text-gray-700 font-semibold tracking-wider"
            >{{ approachModel }}</span>
            <span>
              <download-excel :data="pvcalcData" type="csv" name="PV_Calculations.csv">
                <q-btn
                  dense
                  flat
                  icon="fas fa-download"
                  rounded
                  no-caps
                  size="10px"
                  class="w-20"
                  color="white"
                ></q-btn>
              </download-excel>
            </span>
          </div>
          <div class="px-4 py-4 bg-grey-1 rounded-lg mt-2 mb-4">
            <q-table
              binary-state-sort
              square
              flat
              wrap-cells
              bordered
              dense
              :data="pvcalcData"
              :columns="pvcalcColumns"
              row-key="name"
            />
          </div>
        </div>
        <div>
          <div class="flex items-center justify-between" style="background-color:#022C4C">
            <span
              class="text-white py-1 px-4 text-md rounded-lg text-gray-700 font-semibold tracking-wider"
            >Liability & Depreciation Schedule</span>
            <!-- <span>{{approachModel}}</span> -->
            <span>
              <download-excel
                :data="liabdepreData"
                type="csv"
                name="Liability_and_Depreciation_Schedule.csv"
              >
                <q-btn
                  dense
                  flat
                  icon="fas fa-download"
                  rounded
                  no-caps
                  size="10px"
                  class="w-20"
                  color="white"
                ></q-btn>
              </download-excel>
            </span>
          </div>
          <div class="px-4 py-4 bg-grey-1 rounded-lg mt-2 mb-4">
            <q-table
              binary-state-sort
              square
              flat
              wrap-cells
              bordered
              dense
              :data="liabdepreData"
              :columns="liabdepreColumns"
              row-key="name"
            />
          </div>
        </div>
        <div>
          <div class="flex items-center justify-between" style="background-color:#022C4C">
            <span
              class="text-white py-1 px-4 text-md rounded-lg text-gray-700 font-semibold tracking-wider"
            >Accounting Entries - Inception/Transition</span>
            <!-- <span>{{approachModel}}</span> -->
            <span>
              <download-excel
                :data="aeitData"
                type="csv"
                name="Accounting_Entries-Inception/Transition.csv"
              >
                <q-btn
                  dense
                  flat
                  icon="fas fa-download"
                  rounded
                  no-caps
                  size="10px"
                  class="w-20"
                  color="white"
                ></q-btn>
              </download-excel>
            </span>
          </div>
          <div class="px-4 py-4 bg-grey-1 rounded-lg mt-2 mb-4">
            <q-table
              binary-state-sort
              square
              flat
              wrap-cells
              bordered
              dense
              :data="aeitData"
              :columns="aeitColumns"
              row-key="name"
            />
          </div>
        </div>
        <div>
          <div class="flex items-center justify-between" style="background-color:#022C4C">
            <span
              class="text-white py-1 px-4 text-md rounded-lg text-gray-700 font-semibold tracking-wider"
            >Accounting Entries - Depreciation/Accumulated Depreciation</span>
            <!-- <span>{{approachModel}}</span> -->
            <span>
              <download-excel
                :data="aedadData"
                type="csv"
                name="Accounting_Entries-Depreciation/Accumulated_Depreciation.csv"
              >
                <q-btn
                  dense
                  flat
                  icon="fas fa-download"
                  rounded
                  no-caps
                  size="10px"
                  class="w-20"
                  color="white"
                ></q-btn>
              </download-excel>
            </span>
          </div>
          <div class="px-4 py-4 bg-grey-1 rounded-lg mt-2 mb-4">
            <q-table
              binary-state-sort
              square
              flat
              wrap-cells
              bordered
              dense
              :data="aedadData"
              :columns="aedadColumns"
              row-key="name"
            />
          </div>
        </div>
        <div>
          <div class="flex items-center justify-between" style="background-color:#022C4C">
            <span
              class="text-white py-1 px-4 text-md rounded-lg text-gray-700 font-semibold tracking-wider"
            >Accounting Entries - Cost/Liability</span>
            <!-- <span>{{approachModel}}</span> -->
            <span>
              <download-excel
                :data="aeclData"
                type="csv"
                name="Accounting_Entries-Cost/Liability.csv"
              >
                <q-btn
                  dense
                  flat
                  icon="fas fa-download"
                  rounded
                  no-caps
                  size="10px"
                  class="w-20"
                  color="white"
                ></q-btn>
              </download-excel>
            </span>
          </div>
          <div class="px-4 py-4 bg-grey-1 rounded-lg mt-2 mb-4">
            <q-table
              binary-state-sort
              square
              flat
              wrap-cells
              bordered
              dense
              :data="aeclData"
              :columns="aeclColumns"
              row-key="name"
            />
          </div>
        </div>
        <div>
          <div class="flex items-center justify-between" style="background-color:#022C4C">
            <span
              class="text-white py-1 px-4 text-md rounded-lg text-gray-700 font-semibold tracking-wider"
            >Accounting Entries - Payments/Liability Reversals</span>
            <!-- <span>{{approachModel}}</span> -->
            <span>
              <download-excel
                :data="aeplData"
                type="csv"
                name="Accounting_Entries-Payments/Liability_Reversals.csv"
              >
                <q-btn
                  dense
                  flat
                  icon="fas fa-download"
                  rounded
                  no-caps
                  size="10px"
                  class="w-20"
                  color="white"
                ></q-btn>
              </download-excel>
            </span>
          </div>
          <div class="px-4 py-4 bg-grey-1 rounded-lg mt-2 mb-4">
            <q-table
              binary-state-sort
              square
              flat
              wrap-cells
              bordered
              dense
              :data="aeplData"
              :columns="aeplColumns"
              row-key="name"
            />
          </div>
        </div>
        <div>
          <div class="flex items-center justify-between" style="background-color:#022C4C">
            <span
              class="text-white py-1 px-4 text-md rounded-lg text-gray-700 font-semibold tracking-wider"
            >Accounting Entries - Rent Posting</span>
            <!-- <span>{{approachModel}}</span> -->
            <span>
              <download-excel
                :data="aerpData"
                type="csv"
                name="Accounting_Entries-Rent_Posting.csv"
              >
                <q-btn
                  dense
                  flat
                  icon="fas fa-download"
                  rounded
                  no-caps
                  size="10px"
                  class="w-20"
                  color="white"
                ></q-btn>
              </download-excel>
            </span>
          </div>
          <div class="px-4 py-4 bg-grey-1 rounded-lg mt-2 mb-4">
            <q-table
              binary-state-sort
              square
              flat
              wrap-cells
              bordered
              dense
              :data="aerpData"
              :columns="aerpColumns"
              row-key="name"
            />
          </div>
        </div>
      </div>
    </div>
  </q-page>
</template>


<script>
import { ApiConstants } from "./../const";
import Vue from "vue";
import JsonExcel from "vue-json-excel";


Vue.component("downloadExcel", JsonExcel);
export default {
  data() {
    return {
      json_meta: [{ key: "charset", value: "utf-8" }],
      searchText: null,
      approachModel: "Full retrospective",
      approachOptions: [
        "Full retrospective",
        "Modified retrospective",
        "Modified simplified"
      ],
      discountingrateData: [],
      discountingrateColumns: [],
      assetscheduleData: [],
      assetscheduleColumns: [],
      pvcalcData: [],
      pvcalcColumns: [],
      liabdepreData: [],
      liabdepreColumns: [],
      aeitData: [],
      aeitColumns: [],
      aedadData: [],
      aedadColumns: [],
      aeclData: [],
      aeclColumns: [],
      aeplData: [],
      aeplColumns: [],
      aerpColumns: [],
      aerpData: [],
      leaseIds: null,
      fallbackleaseIds: null,
      headerData: null,
      lessorData: null,
      paymentsData: [],
      dates: null,
      rou: null,
      lease: null,
      retearn: null,
      leaseIdModel: null,
      noids: false,
      allids: false,
      listLeaseModel: "Active",
      listLeaseOptions: ["Active", "Inactive", "Not_Approved"],
      listProjectModel: "Drafted",
      listProjectOptions: ["Drafted", "Project Active", "EOL"],
      init: false,
      modifierData: null,
      
    };
  },
  methods: {
    listLease() {
      if (
        this.listLeaseModel === "Inactive" ||
        this.listProjectModel === "EOL"
      ) {
        this.allids = false;
        this.noids = true;
        this.init = false;
        // this.getLease(this.listLeaseModel, this.listProjectModel);
      } else {
        // this.$q.loading.show({
        //   message: "Fetching please wait",
        //   spinnerSize: 50,
        //   spinnerColor: "red-10",
        //   backgroundColor: "grey-7",
        //   messageColor: "grey-10",
        //   spinner: "QSpinnerBars",
        //   customClass: "font-sans text-bold tracking-wide text-xl text-gray-800"
        // });
        // this.init = tru;
        // this.allids = true;
        this.getLease(this.listLeaseModel, this.listProjectModel);
        this.noids = true;
        // this.$q.loading.hide();
      }
    },
    searchPage() {
      if (this.searchText.length < 1) {
        this.leaseIds = this.fallbackleaseIds;
      } else {
        this.leaseIds = this.fallbackleaseIds.filter(s => {
          if (s.id.includes(this.searchText)) return s;
        });
      }
    },
    resetData() {
      this.paymentsData = [];
      this.liabdepreColumns = [];
      this.pvcalcColumns = [];
      this.assetscheduleColumns = [];
      this.discountingrateColumns = [];
      this.aeitColumns = [];
      this.aedadColumns = [];
      this.aeclColumns = [];
    },
    async getInference(lease) {
      this.$q.loading.show({
        delay: 200,
        message: "Fetching please wait",
        spinnerSize: 50,
        spinnerColor: "red-10",
        backgroundColor: "grey-7",
        messageColor: "grey-10",
        spinner: "QSpinnerBars",
        customClass: "font-sans text-bold tracking-wide text-xl text-gray-800"
      });
      this.resetData();
      let leasePromise = await this.$axios.post(ApiConstants.APIURL + "116", {
        lease,
        status: this.fallbackleaseIds.filter(obj => obj.id === lease)[0][
          "status"
        ],
        project_status: this.fallbackleaseIds.filter(
          obj => obj.id === lease
        )[0]["project_status"]
      });
      this.leaseIdModel = lease;
      this.headerData = leasePromise.data.msg.header;
      this.lessorData = leasePromise.data.msg.lessor;
      this.modifierData = leasePromise.data.msg.modifierData;
      console.log(this.modifierData)
      Object.keys(leasePromise.data.msg.payment).forEach(key => {
        this.paymentsData.push(leasePromise.data.msg.payment[key]);
      });
      leasePromise.data.msg.landdschedulecolumns.map(ele => {
        this.liabdepreColumns.push({
          name: ele,
          align: "left",
          label: ele,
          field: ele,
          style:
            "color:#1a202c;	font-size: 1rem;	font-weight: 700; font-size: 0.85rem;text-align: left"
        });
      });
      this.liabdepreData = leasePromise.data.msg.landdscheduledata;
      leasePromise.data.msg.pvretrocolumns.map(ele => {
        this.pvcalcColumns.push({
          name: ele,
          align: "left",
          label: ele,
          field: ele,
          style:
            "color:#1a202c;	font-size: 1rem;	font-weight: 700; font-size: 0.85rem;text-align: left"
        });
      });
      this.pvcalcData = leasePromise.data.msg.pvretrodata;
      this.dates = leasePromise.data.msg.dates;
      this.rou = leasePromise.data.msg.rou;
      this.lease = leasePromise.data.msg.lease;
      this.retearn = leasePromise.data.msg.retearn;
      leasePromise.data.msg.assetschedulecolumns.map(ele => {
        this.assetscheduleColumns.push({
          name: ele,
          align: "left",
          label: ele,
          field: ele,
          style:
            "color:#1a202c;	font-size: 1rem;	font-weight: 700; font-size: 0.85rem;text-align: left"
        });
      });
      this.assetscheduleData = leasePromise.data.msg.assetscheduledata;
      leasePromise.data.msg.discratecolumns.map(ele => {
        this.discountingrateColumns.push({
          name: ele,
          align: "left",
          label: ele,
          field: ele,
          style:
            "color:#1a202c;	font-size: 1rem;	font-weight: 700; font-size: 0.85rem;text-align: left"
        });
      });
      this.discountingrateData = leasePromise.data.msg.discratedata;
      leasePromise.data.msg.inceptranscolumns.map(ele => {
        this.aeitColumns.push({
          name: ele,
          align: "left",
          label: ele,
          field: ele,
          style:
            "color:#1a202c;	font-size: 1rem;	font-weight: 700; font-size: 0.85rem;text-align: left"
        });
      });
      this.aeitData = leasePromise.data.msg.inceptransdata;
      leasePromise.data.msg.depaccucolumns.map(ele => {
        this.aedadColumns.push({
          name: ele,
          align: "left",
          label: ele,
          field: ele,
          style:
            "color:#1a202c;	font-size: 1rem;	font-weight: 700; font-size: 0.85rem;text-align: left"
        });
      });
      this.aedadData = leasePromise.data.msg.depaccudata;
      leasePromise.data.msg.costliabcolumns.map(ele => {
        this.aeclColumns.push({
          name: ele,
          align: "left",
          label: ele,
          field: ele,
          style:
            "color:#1a202c;	font-size: 1rem;	font-weight: 700; font-size: 0.85rem;text-align: left"
        });
      });
      this.aeclData = leasePromise.data.msg.costliabdata;
      leasePromise.data.msg.payreversalcolumns.map(ele => {
        this.aeplColumns.push({
          name: ele,
          align: "left",
          label: ele,
          field: ele,
          style:
            "color:#1a202c;	font-size: 1rem;	font-weight: 700; font-size: 0.85rem;text-align: left"
        });
      });
      this.aeplData = leasePromise.data.msg.payreversaldata;
      leasePromise.data.msg.rentpostingcolumns.map(ele => {
        this.aerpColumns.push({
          name: ele,
          align: "left",
          label: ele,
          field: ele,
          style:
            "color:#1a202c;	font-size: 1rem;	font-weight: 700; font-size: 0.85rem;text-align: left"
        });
      });
      this.aerpData = leasePromise.data.msg.rentpostingdata;
      this.$q.loading.hide();
      this.allids = true;
      this.noids = false;
    },
    getLease(lease, project) {
      this.noids = true;
      this.allids = false;
      this.$axios
        .post(ApiConstants.APIURL + "leases", {
          org: this.$q.localStorage.getItem("audire_user_org"),
          status: lease,
          project_status: project
        })
        .then(response => {
          if (response.data.ids.length !== 0) {
            // this.allids = true;
            // this.noids = false;
            // this.init = false;
            this.fallbackleaseIds = response.data.ids.sort(
              (a, b) => new Date(b.date) - new Date(a.date)
            );
            this.leaseIds = response.data.ids.sort(
              (a, b) => new Date(b.date) - new Date(a.date)
            );
            // this.getInference(this.leaseIds[0]["id"]);
          } else {
            // this.allids = false;
            // this.noids = true;
            // this.init = false;
          }
        })
        .catch(err => console.error(err));
    }
  },
  created() {
    this.$axios
      .post(ApiConstants.APIURL + "leases", {
        org: this.$q.localStorage.getItem("audire_user_org"),
        status: this.listLeaseModel,
        project_status: this.listProjectModel
      })
      .then(response => {
        if (response.data.ids.length !== 0) {
          this.allids = false;
          this.init = true;
          this.noids = true;
          this.fallbackleaseIds = response.data.ids.sort(
            (a, b) => new Date(b.date) - new Date(a.date)
          );
          this.leaseIds = response.data.ids.sort(
            (a, b) => new Date(b.date) - new Date(a.date)
          );
          // this.getInference(this.leaseIds[0]["id"]);
        } else {
          this.allids = false;
          this.noids = true;
          this.init = false;
        }
      })
      .catch(err => console.error(err));
  }
};
</script>

<style>
.my-menu-link {
  color: white;
  background: #f2c037;
}

.modifier-payment-table thead th {
  width:1px;
  white-space:nowrap;
  padding:8px;
  border: 1px solid #EEEEEE;
}

/* modifier-payment-table tbody tr{
  padding:2px;
  border:1px solid  #e6e6e6;
} */

.modifier-payment-table tbody tr td {
   padding:2px;
  border:1px solid  #e6e6e6;
}
</style>
