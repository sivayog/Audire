<template>
  <!-- <q-page class="flex flex-center no-wrap">
    <div class="row full-width">
      <div class="col-xs-4 offset-xs-4 center">
        <q-card>
          <q-item class="bg-blue-grey-3">
            <q-item-section>
              <q-item-label class="text-h5 text-center">Login</q-item-label>
            </q-item-section>
          </q-item>
          <div class="row full-width q-gutter-y-md bg-grey-3" style="height:100px">
            <div class="col-xs-6 offset-xs-4 flex-center q-gutter-y-md text-black">
              <q-btn
                color="primary"
                icon="fab fa-google"
                :loading="loading"
                @click="handleClickSignIn"
                :label="label"
              >
                <template v-slot:loading>
                  <q-spinner-hourglass class="on-left"/>Loading...
                </template>
              </q-btn>
            </div>
          </div>
        </q-card>
      </div>
    </div>
  </q-page>-->
  <q-page padding>
    <div class="row fixed-center full-width">
      <div class="col-xs-12 col-sm-12 col-md-6 ol-lg-6 offset-md-3 offset-lg-3">
        <q-card dark bordered class="bg-blue-grey-9">
          <q-card-section>
            <div class="text-h6">Login</div>
          </q-card-section>
          <q-separator dark inset/>
          <q-card-section>
            <div class="row">
              <div class="col-xs-12 col-sm-12 col-md-5 offset-md-4 col-lg-5 offset-lg-4">
                <q-btn
                  flat
                  rounded
                  push
                  icon="img:https://img.icons8.com/color/48/000000/google-logo.png"
                  :loading="loading"
                  @click="handleClickSignIn"
                >
                  <span class="text-overline q-ml-md">Login with Google</span>
                </q-btn>
              </div>
            </div>
          </q-card-section>
        </q-card>
      </div>
    </div>
  </q-page>
</template>

<script>
import { ApiConstants } from './../const';
import { EventBus } from "./event-bus.js";
export default {
  name: "login",
  data() {
    return {
      isInit: false,
      isSignIn: false,
      tab: "one",
      name: null,
      pass: null,
      accept: false,
      loading: false,
      logout: false
    };
  },
  methods: {
    handleClickLogin() {
      this.$gAuth
        .getAuthCode()
        .then(authCode => {
          //on success
          console.log("authCode", authCode);
        })
        .catch(error => {
          //on fail do something
        });
    },

    handleClickSignIn() {
      if (this.logout === true) {
        this.logout = false;
        this.label = "Google Login";
        this.handleClickSignOut();
      } else {
        this.loading = true;
        this.$gAuth
          .signIn()
          .then(GoogleUser => {
            //on success do something
            this.loading = false;
            this.label = "Log Out";
            this.logout = true;
            this.$axios
              .get(
                `https://www.googleapis.com/oauth2/v2/userinfo?alt=json&access_token=${
                  GoogleUser.Zi.access_token
                }`
              )
              .then(resss => {
                // EventBus.$emit("googleLoginEvent", resss.data);
                this.$router.push({
                  path: "/dashboard",
                  query: {
                    name: resss.data.given_name,
                    avatar: resss.data.picture
                  }
                });
              }) //
              .catch(error => {
                console.error(error);
              });
            // console.log("getId", GoogleUser.getId());
            // console.log("getBasicProfile", GoogleUser.getBasicProfile());
            // console.log("getAuthResponse", GoogleUser.getAuthResponse());
            // console.log(
            //   "getAuthResponse",
            //   this.$gAuth.GoogleAuth.currentUser.get().getAuthResponse()
            // );
            this.isSignIn = this.$gAuth.isAuthorized;
          })
          .catch(error => {
            //on fail do something
            this.loading = false;
          });
      }
    },

    handleClickSignOut() {
      this.$gAuth
        .signOut()
        .then(() => {
          //on success do something
          this.isSignIn = this.$gAuth.isAuthorized;
        })
        .catch(error => {
          //on fail do something
        });
    },
    onSubmit() {
      this.$refs.name.validate();
      this.$refs.age.validate();

      if (this.$refs.name.hasError || this.$refs.age.hasError) {
        this.formHasError = true;
      } else if (this.accept !== true) {
        this.$q.notify({
          color: "negative",
          message: "You need to accept the license and terms first"
        });
      } else {
        this.$q.notify({
          icon: "done",
          color: "positive",
          message: "Submitted"
        });
      }
    },

    onReset() {
      this.name = null;
      this.pass = null;

      this.$refs.name.resetValidation();
      this.$refs.pass.resetValidation();
    }
  },
  created() {
    let that = this;
    let checkGauthLoad = setInterval(function() {
      that.isInit = that.$gAuth.isInit;
      if (that.isInit) {
        clearInterval(checkGauthLoad);
        if (!that.$gAuth.isAuthorized) {
          that.$router.push("/");
        }
      }
    }, 1000);
  }
};
</script>

<style scoped>
</style>