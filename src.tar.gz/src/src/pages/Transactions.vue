<template>
  <q-page>
    <div class="px-12 py-8">
      <q-markup-table flat bordered>
        <thead class>
          <tr>
            <th colspan="5">
              <div class="flex no-wrap items-center justify-between">
                <div>
                  <span class="text-lg font-black text-black tracking-wider"
                    >Transactions' Status</span
                  >
                </div>
                <div>
                  <q-btn
                    size="11px"
                    round
                    color="indigo-10"
                    text-color="white"
                    icon="refresh"
                    @click="refreshData"
                  />
                </div>
              </div>
            </th>
          </tr>
          <tr>
            <th class="text-left">
              <span class="text-uppercase font-bold text-gray-800 tracking-wide"
                >Transaction ID</span
              >
            </th>
            <th class="text-center">
              <span
                class="text-uppercase text-md font-bold text-gray-800 tracking-wide"
                >Date</span
              >
            </th>
            <th class="text-center">
              <span
                class="text-uppercase text-md font-bold text-gray-800 tracking-wide"
                >Process</span
              >
            </th>
            <th class="text-center">
              <span
                class="text-uppercase text-md font-bold text-gray-800 tracking-wide"
                >System</span
              >
            </th>
            <th class="text-center">
              <span
                class="text-uppercase text-md font-bold text-gray-800 tracking-wide"
                >Status</span
              >
            </th>
          </tr>
        </thead>
        <tbody class>
          <tr
            v-for="(item, index) in statusData"
            :key="item + index + 'abcd'"
            class="text-left"
          >
            <td
              v-for="(secondary, secindex) in item"
              :key="item + secondary + secindex"
              :class="[secindex === 0 ? 'text-left' : 'text-center']"
            >
              <span
                v-if="secondary === 'In Progress'"
                class="rounded-full bg-amber-3 px-2 py-1 font-black text-gray-600"
                >{{ secondary }}</span
              >
              <span
                v-else-if="secondary === 'Completed'"
                class="rounded-full bg-green-3 px-2 py-1 font-black text-gray-600"
                >{{ secondary }}</span
              >
              <span
                v-else-if="secondary === 'Errored'"
                class="rounded-full bg-red-3 px-2 py-1 font-black text-gray-600"
                >{{ secondary }}</span
              >
              <span
                v-else
                class="px-2 py-1 font-semibold text-gray-700 text-md tracking-wide font-sans"
                >{{ secondary }}</span
              >
            </td>
          </tr>
        </tbody>
      </q-markup-table>
    </div>
  </q-page>
</template>

<script>
  import { ApiConstants } from './../const';
  export default {
    data() {
      return {
        statusData: []
      };
    },
    created() {
      this.getAllTransactions();
    },
    methods: {
      async getAllTransactions() {
        this.statusData = [];
        let transPromise = await this.$axios.get(
          ApiConstants.APIURL +  "transactions"
        );

        transPromise.data.msg.sort(
          (a, b) => new Date(b.CREATED_AT) - new Date(a.CREATED_AT)
        );
        transPromise.data.msg.map(obj => {
          let temp = [];
          temp.push(
            obj.TRANSACTION_ID,
            new Date(obj.CREATED_AT).toLocaleDateString(),
            obj.PROCESS[0],
            obj.SYSTEM[0],
            obj.STATUS
          );
          this.statusData.push(temp);
        });
      },
      refreshData() {
        this.statusData = [];
        this.getAllTransactions();
      }
    }
  };
</script>

<style></style>
