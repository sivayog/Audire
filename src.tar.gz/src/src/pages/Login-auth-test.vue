<template>
  <q-page>
    <div class="flex h-screen">
      <div class="flex flex-col items-center m-auto">
        <div>
          <span
            class="font-serif font-black text-3xl text-gray-900 tracking-widest"
            >AUDIRE</span
          >
        </div>
        <div v-show="isLogin">
          <span
            class="font-serif font-light text-sm text-gray-600 tracking-wider"
            >Welcome back! Please login to your account.</span
          >
        </div>
        <div v-show="isSignup">
          <span
            class="font-serif font-light text-sm text-gray-600 tracking-wider"
            >Please complete to create your account.</span
          >
        </div>
        <div v-show="isForgot">
          <span
            class="font-serif font-light text-sm text-gray-600 tracking-wider"
            >Enter your email and we send you a password reset link.</span
          >
        </div>

        <div class="py-6" v-show="isForgot">
          <q-form @submit="onforgot">
            <div>
              <q-input
                v-model="resetEmail"
                placeholder="Email"
                type="text"
                @keydown.space.prevent
                :rules="[
                  val =>
                    (val && val.length > 0 && val.keycode !== 32) ||
                    'Type in email'
                ]"
              />
            </div>

            <div class="flex items-center justify-center pt-5">
              <q-btn
                unelevated
                label="Send request"
                no-caps
                size="md"
                type="submit"
                color="indigo-9"
                :loading="forgotLoading"
                class="mr-1"
              />
            </div>
            <div class="flex justify-center" v-show="isForgot">
              <span
                class="text-xs font-semibold-soft text-gray-700 tracking-widest hover:underline cursor-pointer pt-3"
                @click="goback"
                >Go back.</span
              >
            </div>
          </q-form>
        </div>

        <div class="py-6" v-show="isLogin">
          <q-form @submit="onLogin">
            <div>
              <q-input
                v-model="logemail"
                placeholder="Email"
                type="text"
                @keydown.space.prevent
                :rules="[
                  val =>
                    (val && val.length > 0 && val.keycode !== 32) ||
                    'Please type something'
                ]"
              />
            </div>
            <div>
              <q-input
                v-model="logpassword"
                @keydown.space.prevent
                :type="isPwd ? 'password' : 'text'"
                placeholder="Password"
                :rules="[
                  val =>
                    (val && val.length >= 7) ||
                    'Password must be atleast 7 characters in length'
                ]"
              >
                <template v-slot:append>
                  <q-icon
                    :name="isPwd ? 'visibility_off' : 'visibility'"
                    class="cursor-pointer"
                    @click="isPwd = !isPwd"
                  />
                </template>
              </q-input>
            </div>

            <div class="flex items-center justify-center pt-5">
              <q-btn
                unelevated
                label="Login"
                no-caps
                size="md"
                type="submit"
                color="indigo-9"
                :loading="loginLoading"
                class="mr-1"
              />
              <q-btn
                class="ml-1"
                unelevated
                @click="goback"
                flat
                label="Sign Up"
                no-caps
                type="submit"
                color="indigo-9"
              />
            </div>
            <div class="flex justify-center" v-show="isLogin">
              <span
                class="text-xs font-semibold-soft text-gray-700 tracking-widest hover:underline cursor-pointer pt-3"
                @click="handleForgot"
                >Forgot Password?.</span
              >
            </div>
          </q-form>
        </div>

        <div class="py-6" v-show="isSignup">
          <q-form @submit="onRegister">
            <!-- <div class="flex items-center justify-between">
              <q-input
                class="mr-2"
                v-model="regfirstname"
                placeholder="First name"
                type="text"
                @keydown.space.prevent
              />
              <q-input
                class="ml-2"
                v-model="reglastname"
                placeholder="Last name"
                type="text"
                @keydown.space.prevent
              />
            </div> -->
            <div>
              <q-input
                v-model="regusername"
                placeholder="Username"
                type="text"
                @keydown.space.prevent
                :rules="[
                  val =>
                    (val && val.length > 0 && val.keycode !== 32) ||
                    'Please type something'
                ]"
              />
            </div>
            <div>
              <q-input
                v-model="regphone"
                placeholder="Phone"
                type="tel"
                @keydown.space.prevent
                pattern="^[6-9]\d{9}$"
                :rules="[
                  val =>
                    (val && val.length > 0 && val.keycode !== 32) ||
                    'Please type something'
                ]"
              />
            </div>
            <div>
              <q-input
                type="email"
                v-model="regemail"
                placeholder="Email"
                @keydown.space.prevent
                :rules="[
                  val =>
                    (val && val.length > 0 && val.keycode !== 32) ||
                    'Please type something'
                ]"
              />
            </div>
            <div>
              <q-input
                v-model="regorganization"
                placeholder="Organization"
                type="text"
                @input="regorg"
                :rules="[
                  val =>
                    (val && val.length > 0 && val.keycode !== 32) ||
                    'Please type something'
                ]"
              />
            </div>
            <div>
              <q-input
                v-model="regpassword"
                @keydown.space.prevent
                :type="isPwd ? 'password' : 'text'"
                placeholder="Password"
                :rules="[
                  val =>
                    (val && val.length >= 7) ||
                    'Password must be atleast 7 characters in length'
                ]"
              >
                <template v-slot:append>
                  <q-icon
                    :name="isPwd ? 'visibility_off' : 'visibility'"
                    class="cursor-pointer"
                    @click="isPwd = !isPwd"
                  />
                </template>
              </q-input>
            </div>

            <div class="flex justify-center py-2">
              <q-btn
                unelevated
                label="Sign Up"
                no-caps
                type="submit"
                color="indigo-9"
                :loading="signupLoading"
              />
            </div>
            <div class="flex justify-center">
              <span
                class="text-xs font-semibold-soft text-gray-700 tracking-widest hover:underline cursor-pointer"
                @click="handleSignin"
                >Already have an account? Sign in.</span
              >
            </div>
          </q-form>
        </div>
      </div>
    </div>
  </q-page>
</template>

<script>
import { ApiConstants } from './../const';
import { EventBus } from "./event-bus.js";
import { truncate } from "fs";
export default {
  name: "login",
  data() {
    return {
      tab: "login",
      isSignup: false,
      isLogin: true,
      isPwd: true,
      isForgot: false,
      forgotLoading: false,
      signupLoading: false,
      loginLoading: false,
      regphone: null,
      resetEmail: null,
      isInit: false,
      isSignIn: false,
      name: null,
      pass: null,
      accept: false,
      loading: false,
      logout: false,
      regemail: null,
      regpassword: null,
      regusername: null,
      cpassword: null,
      regorganization: null,
      logemail: null,
      logpassword: null,
      buttonDisable: false
    };
  },
  methods: {
    handleClickLogin() {
      this.$gAuth
        .getAuthCode()
        .then(authCode => {
          //on success
          console.log("authCode", authCode);
        })
        .catch(error => {
          //on fail do something
        });
    },

    handleClickSignIn() {
      if (this.logout === true) {
        this.logout = false;
        this.label = "Google Login";
        this.handleClickSignOut();
      } else {
        this.loading = true;
        this.$gAuth
          .signIn()
          .then(GoogleUser => {
            //on success do something
            this.loading = false;
            this.label = "Log Out";
            this.logout = true;
            this.$axios
              .get(
                `https://www.googleapis.com/oauth2/v2/userinfo?alt=json&access_token=${GoogleUser.Zi.access_token}`
              )
              .then(resss => {
                // EventBus.$emit("googleLoginEvent", resss.data);
                this.$router.push({
                  path: "/dashboard",
                  query: {
                    name: resss.data.given_name,
                    avatar: resss.data.picture
                  }
                });
              }) //
              .catch(error => {
                console.error(error);
              });
            // console.log("getId", GoogleUser.getId());
            // console.log("getBasicProfile", GoogleUser.getBasicProfile());
            // console.log("getAuthResponse", GoogleUser.getAuthResponse());
            // console.log(
            //   "getAuthResponse",
            //   this.$gAuth.GoogleAuth.currentUser.get().getAuthResponse()
            // );
            this.isSignIn = this.$gAuth.isAuthorized;
          })
          .catch(error => {
            //on fail do something
            this.loading = false;
          });
      }
    },

    handleClickSignOut() {
      this.$gAuth
        .signOut()
        .then(() => {
          //on success do something
          this.isSignIn = this.$gAuth.isAuthorized;
        })
        .catch(error => {
          //on fail do something
        });
    },
    onRegister() {
      this.signupLoading = true;
      let userData = {
        username: this.regusername,
        password: this.regpassword,
        email: this.regemail,
        organization: this.regorganization,
        phone: this.regphone
      };
      this.$axios
        .post( ApiConstants.LOGINAPIURL + "register", userData)
        .then(response => {
          this.signupLoading = false;
          if (response.data.status === "failed") {
            this.$q.notify({
              color: "red-2",
              position: "top-right",
              textColor: "black",
              icon: "fas fa-exclamation",
              message: response.data.message
            });
          } else {
            this.$q.notify({
              color: "green-2",
              position: "top-right",
              textColor: "black",
              icon: "fas fa-exclamation",
              message:
                "A verification email has been sent to the registered ID."
            });
            this.buttonDisable = true;
            this.$q.localStorage.set("verify", response.data.verifyCode);
          }
        });
    },

    onRegisterReset() {
      (this.regusername = null),
        (this.regpassword = null),
        (this.regemail = null),
        (this.regorganization = null);
    },
    onLogin() {
      this.loginLoading = true;
      let userData = {
        password: this.logpassword,
        email: this.logemail
      };
      this.$axios
        .post( ApiConstants.LOGINAPIURL + "login", userData)
        .then(response => {
          this.loginLoading = false;
          if (response.data.status === "failed") {
            this.$q.notify({
              color: "red-2",
              position: "top-right",
              textColor: "black",
              icon: "fas fa-exclamation",
              message: response.data.message
            });
          } else {
            this.$q.localStorage.set("audire_bearer", response.data.message);
            this.$q.localStorage.set("audire_user", response.data.name);
            this.$q.localStorage.set(
              "audire_user_org",
              response.data.organization
            );
            this.$router.push("/modules");
          }
        });
    },
    onLoginReset() {
      (this.logpassword = null), (this.logemail = null);
    },
    forgotPass() {
      this.$router.push("/reset");
    },
    handleSignin() {
      this.isSignup = false;
      this.isLogin = true;
      this.isForgot = false;
    },
    goback() {
      this.isForgot = false;
      this.isSignup = true;
      this.isLogin = false;
    },
    handleForgot() {
      this.isForgot = true;
      this.isSignup = false;
      this.isLogin = false;
    },
    onforgot() {
      this.forgotLoading = true;
      const payload = {
        email: this.resetEmail
      };
      this.$axios
        .post( ApiConstants.LOGINAPIURL + "passwordReset", payload)
        .then(response => {
          this.forgotLoading = false;
          if (response.data.status === "failed") {
            this.$q.notify({
              color: "red-2",
              position: "top-right",
              textColor: "black",
              icon: "fas fa-exclamation",
              message: response.data.message
            });
          } else {
            this.$q.notify({
              color: "green-2",
              position: "top-right",
              textColor: "black",
              icon: "fas fa-exclamation",
              message: `Password Reset link sent to the provided e-mail.`
            });
          }
        })
        .catch(err => console.log(err));
    },
    regorg() {
      if (this.timeout) clearTimeout(this.timeout);
      this.timeout = setTimeout(() => {
        this.regorganization = this.regorganization.trim();
      }, 450);
    }
  },
  created() {
    // multiple tags log in sewat buggy
    if (this.$route.query.rereg) {
      if (this.$route.query.rereg === true) {
        this.$q.notify({
          color: "red-2",
          position: "top-right",
          textColor: "black",
          icon: "fas fa-exclamation",
          message: "Token Expired.Please register again."
        });
      } else {
        this.$q.notify({
          color: "red-2",
          position: "top-right",
          textColor: "black",
          icon: "fas fa-exclamation",
          message: "Successfully Registered.Please login to continue."
        });
      }
    }
  }
};
</script>

<style scoped></style>
