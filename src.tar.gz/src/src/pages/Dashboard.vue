<template>
  <q-page>
    <div class="px-12 pt-12 pb-8">
      <div class="flex items-center justify-start border-gray-600 p-2">
        <div class="pr-2 flex items-center flex-no-wrap">
          <div class="flex items-center">
            <span class="text-lg text-gray-700 font-semibold font-sans">From</span>
            <q-input
              outlined
              rounded
              dense
              options-dense
              v-model="fromDate"
              mask="date"
              style="width:10rem"
              class="px-2"
            >
              <template v-slot:append>
                <q-icon name="event" class="cursor-pointer">
                  <q-popup-proxy
                    ref="qDateProxyFrom"
                    transition-show="jump-down"
                    transition-hide="jump-up"
                  >
                    <q-date v-model="fromDate" @input="() => $refs.qDateProxyFrom.hide()" />
                  </q-popup-proxy>
                </q-icon>
              </template>
            </q-input>
          </div>
          <div class="pl-2 flex items-center">
            <span class="text-lg text-gray-700 font-semibold font-sans">To</span>
            <q-input
              class="px-2"
              rounded
              outlined
              dense
              options-dense
              v-model="toDate"
              mask="date"
              style="width:10rem"
            >
              <template v-slot:append>
                <q-icon name="event" class="cursor-pointer">
                  <q-popup-proxy
                    ref="qDateProxyTo"
                    transition-show="jump-down"
                    transition-hide="jump-up"
                  >
                    <q-date v-model="toDate" @input="() => $refs.qDateProxyTo.hide()" />
                  </q-popup-proxy>
                </q-icon>
              </template>
            </q-input>
          </div>
        </div>
        <div>
          <span class="border-r-2 border-gray-500"></span>
        </div>
        <div>
          <div class="flex items-center px-4">
            <span class="text-lg text-gray-700 font-semibold font-sans px-4">System</span>
            <q-select
              style="min-width:10rem;max-width:auto"
              outlined
              rounded
              ellipsis
              options-dense
              v-model="systemModel"
              :options="systemOptions"
              label="System"
              dense
              class="ellipsis"
              transition-show="jump-up"
              transition-hide="jump-down"
            />
          </div>
        </div>
        <div>
          <span class="border-r-2 border-gray-500"></span>
        </div>
        <div>
          <div class="flex items-center px-4">
            <span class="text-lg text-gray-700 font-semibold font-sans px-4">Process</span>
            <q-select
              style="min-width:10rem;max-width:10rem;overflow: hidden;text-overflow: ellipsis;white-space: nowrap"
              outlined
              rounded
              class
              options-dense
              v-model="processModel"
              :options="processOptions"
              label="Process"
              dense
              transition-show="jump-up"
              transition-hide="jump-down"
            />
          </div>
        </div>
        <div>
          <span class="border-r-2 border-gray-500"></span>
        </div>
        <div class="px-4 flex text-right">
          <q-btn
            dense
            unelevated
            no-caps
            flat
            rounded
            size="md"
            class="w-24"
            style="background-color:#022C4C"
            @click="tableData"
          >
            <span class="text-bold-soft text-gray-100 tracking-wide">Search</span>
          </q-btn>
        </div>
      </div>
    </div>
    <div class="px-12 py-4">
      <q-table
        binary-state-sort
        square
        flat
        wrap-cells
        no-data-label="Search to load Data"
        bordered
        dense
        :data="summaryData"
        :columns="summaryColumns"
        row-key="name"
      />
    </div>
  </q-page>
</template>

<script>
import { ApiConstants } from './../const';
import { EventBus } from "./event-bus.js";
import { setTimeout } from "timers";
export default {
  data() {
    return {
      systemModel: null,
      systemOptions: null,
      processModel: null,
      processOptions: null,
      fromDate: new Date().toISOString().split("T")[0],
      toDate: new Date().toISOString().split("T")[0],
      summaryData: [],
      summaryColumns: []
    };
  },
  created() {
    this.getsysproc();
  },
  methods: {
    async tableData() {
      if (
        this.systemModel !== null &&
        this.processModel !== null &&
        this.fromDate !== null &&
        this.toDate !== null
      ) {
        if (
          this.processModel === "INDAS116_Lease_Accounting_Inception_Transition"
        ) {
          let summaryPromise = await this.$axios.post(
            ApiConstants.APIURL + "summary",
            {
              from: this.fromDate,
              to: this.toDate,
              system: this.systemModel,
              processcode: "INCEPTION/TRANSITION_TABLE",
              process: this.processModel
            }
          );
          this.summaryData = summaryPromise.data.data;
          this.summaryColumns = [];
          summaryPromise.data.cols.map(ele => {
            this.summaryColumns.push({
              name: ele,
              align: ele === "Lease Id" ? "left" : "center",
              label: ele,
              field: ele,
              style:
                ele === "Lease Id"
                  ? "color:#1a202c;	font-size:0.85rem;	font-weight: 700;text-align: left"
                  : "color:#1a202c;	font-size:0.85rem;	font-weight: 700;text-align: center"
            });
          });
        }
        if (this.processModel === "INDAS116_Lease_Accounting_Depreciation") {
          let summaryPromise = await this.$axios.post(
            ApiConstants.APIURL +  "summary",
            {
              from: this.fromDate,
              to: this.toDate,
              system: this.systemModel,
              processcode: "DEPRECIATION/ACCUMULATED/DEPRECIATION_TABLE",
              process: this.processModel
            }
          );
          this.summaryData = summaryPromise.data.data;
          this.summaryColumns = [];
          summaryPromise.data.cols.map(ele => {
            this.summaryColumns.push({
              name: ele,
              align: ele === "Lease Id" ? "left" : "center",
              label: ele,
              field: ele,
              style:
                ele === "Lease Id"
                  ? "color:#1a202c;	font-size:0.85rem;	font-weight: 700;text-align: left"
                  : "color:#1a202c;	font-size:0.85rem;	font-weight: 700;text-align: center"
            });
          });
        }
        if (
          this.processModel === "INDAS116_Lease_Accounting_Liability_Reversals"
        ) {
          let summaryPromise = await this.$axios.post(
            "summary",
            {
              from: this.fromDate,
              to: this.toDate,
              system: this.systemModel,
              processcode: "LIABILITY_REVERSALS_TABLE",
              process: this.processModel
            }
          );
          this.summaryData = summaryPromise.data.data;
          this.summaryColumns = [];
          summaryPromise.data.cols.map(ele => {
            this.summaryColumns.push({
              name: ele,
              align: ele === "Lease Id" ? "left" : "center",
              label: ele,
              field: ele,
              style:
                ele === "Lease Id"
                  ? "color:#1a202c;	font-size:0.85rem;	font-weight: 700;text-align: left"
                  : "color:#1a202c;	font-size:0.85rem;	font-weight: 700;text-align: center"
            });
          });
        }
        if (this.processModel === "INDAS116_Lease_Accounting_Rent_Posting") {
          let summaryPromise = await this.$axios.post(
            ApiConstants.APIURL + "summary",
            {
              from: this.fromDate,
              to: this.toDate,
              system: this.systemModel,
              processcode: "RENT_POSTED_TABLE",
              process: this.processModel
            }
          );
          this.summaryData = summaryPromise.data.data;
          this.summaryColumns = [];
          summaryPromise.data.cols.map(ele => {
            this.summaryColumns.push({
              name: ele,
              align: ele === "Lease Id" ? "left" : "center",
              label: ele,
              field: ele,
              style:
                ele === "Lease Id"
                  ? "color:#1a202c;	font-size:0.85rem;	font-weight: 700;text-align: left"
                  : "color:#1a202c;	font-size:0.85rem;	font-weight: 700;text-align: center"
            });
          });
        }
        if (this.processModel === "INDAS116_Lease_Accounting_Liabilities") {
          let summaryPromise = await this.$axios.post(
            ApiConstants.APIURL +  "summary",
            {
              from: this.fromDate,
              to: this.toDate,
              system: this.systemModel,
              processcode: "COST/LIABILITY_TABLE",
              process: this.processModel
            }
          );
          this.summaryData = summaryPromise.data.data;
          this.summaryColumns = [];
          summaryPromise.data.cols.map(ele => {
            this.summaryColumns.push({
              name: ele,
              align: ele === "Lease Id" ? "left" : "center",
              label: ele,
              field: ele,
              style:
                ele === "Lease Id"
                  ? "color:#1a202c;	font-size:0.85rem;	font-weight: 700;text-align: left"
                  : "color:#1a202c;	font-size:0.85rem;	font-weight: 700;text-align: center"
            });
          });
        }
      } else {
        console.log("Select all to view summary");
      }
    },
    async getsysproc() {
      let syspromise = await this.$axios.post(ApiConstants.APIURL +  "sysProc", {
        orgName: this.$q.localStorage.getItem("audire_user_org")
      });
      this.systemOptions = syspromise.data.sys.filter(ele => {
        return ele !== "Audire";
      });
      this.processOptions = syspromise.data.subproc;
    }
  }
};
</script>

<style>
</style>

