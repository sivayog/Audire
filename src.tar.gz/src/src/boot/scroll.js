import PerfectScrollbar from 'vue2-perfect-scrollbar'
import 'vue2-perfect-scrollbar/dist/vue2-perfect-scrollbar.css'


export default async ({ Vue }) => {
    Vue.use(PerfectScrollbar)
}
