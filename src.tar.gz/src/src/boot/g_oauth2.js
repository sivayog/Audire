// import GAuth from 'vue-google-oauth2'

// const gauthOption = {
//   clientId: '771301049436-54rvlomd88gnsb5bqq4p1rulfmpa6a9q.apps.googleusercontent.com',
//   scope: 'https://www.googleapis.com/auth/userinfo.email https://www.googleapis.com/auth/userinfo.profile https://www.googleapis.com/auth/plus.me',
//   prompt: 'select_account',
//   fetch_basic_profile: false,
//   // hosted_domain:'oneintegral.com'
// }

// // "async" is optional
// export default async ({ Vue }) => {
//   Vue.use(GAuth, gauthOption)
// }
