import Vue from "vue";
import JsonExcel from "vue-json-excel";

export default async ({ app, Vue }) => {
  Vue.component("downloadExcel", JsonExcel);
};
