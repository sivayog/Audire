// Login-auth-test
// user_confirmation
const routes = [
  {
    path: '/',
    component: () => import('layouts/NewLoginLayout.vue'),
    children: [
      { path: '', component: () => import('pages/Login-auth-test.vue') }
    ]
  },
  {
    path: '/modules',
    component: () => import('layouts/NewLayout.vue'),
    children: [
      { path: '', component: () => import('pages/Modules.vue') }
    ]
  },
  {
    path: '/confirmation',
    component: () => import('layouts/NewLoginLayout.vue'),
    children: [
      { path: '', component: () => import('pages/user_confirmation.vue') }
    ]
  },
  {
    path: '/reset',
    component: () => import('layouts/NewLoginLayout.vue'),
    children: [
      { path: '', component: () => import('pages/passwordReset.vue') }
    ]
  },
  {
    path: '/changePass',
    component: () => import('layouts/NewLoginLayout.vue'),
    children: [
      { path: '', component: () => import('pages/changePassword.vue') }
    ]
  },
  {
    path: '/dashboard',
    component: () => import('layouts/NewLayout.vue'),
    children: [
      { path: '', component: () => import('pages/Dashboard.vue') }
    ]
  },
  {
    path: '/transactions',
    component: () => import('layouts/NewLayout.vue'),
    children: [
      { path: '', component: () => import('pages/Transactions.vue') }
    ]
  },
  {
    path: '/inference',
    component: () => import('layouts/NewLayout.vue'),
    children: [
      { path: '', component: () => import('pages/116.vue') }
    ]
  },
  {
    path: '/templates',
    component: () => import('layouts/NewLayout.vue'),
    children: [
      { path: '', component: () => import('pages/Templates.vue') }
    ]
  },
  {
    path: '/upload',
    component: () => import('layouts/NewLayout.vue'),
    children: [
      { path: '', component: () => import('pages/Upload.vue') }
    ]
  },
  {
    path: '/lease-plan',
    component: () => import('layouts/NewLayout.vue'),
    children: [
      { path: '', component: () => import('pages/LeasePlan.vue') }
    ]
  },
  {
    path: '/lease-track',
    component: () => import('layouts/NewLayout.vue'),
    children: [
      { path: '', component: () => import('pages/LeaseTracking.vue') }
    ]
  },
  // {
  //   path: '/settings',
  //   component: () => import('layouts/NewLayout.vue'),
  //   children: [
  //     { path: '', component: () => import('pages/Settings.vue') }
  //   ]
  // },
  {
    path: '/denied',
    component: () => import('pages/permission-denied.vue'),
  }
]

// Always leave this as last one
if (process.env.MODE !== 'ssr') {
  routes.push({
    path: '*',
    component: () => import('pages/Error404.vue')
  })
}

export default routes
