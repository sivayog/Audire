<template>
  <q-layout class="antialiased">
    <div class="flex flex-row overflow-hidden">
      <div class="w-1/2 relative">
        <img src="~assets/Audire_Login.svg" class="absolute h-full w-full object-cover" />
      </div>
      <div class="w-1/2">
        <q-page-container class="bg-grey-12">
          <transition
            name="transitions"
            :duration="{ enter: 2000, leave: 200 }"
            enter-active-class="animated fadeInLeft"
            leave-active-class="animated fadeOutRight"
            mode="out-in"
          >
            <router-view />
          </transition>
        </q-page-container>
      </div>
    </div>
  </q-layout>
</template>

<script>
export default {};
</script>

<style>
</style>