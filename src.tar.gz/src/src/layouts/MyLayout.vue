<template>
  <q-layout view="hHh lpR fff" class="bg-grey-3">
    <q-header reveal class="bg-blue-grey-3 text-black">
      <q-toolbar>
        <!-- <q-btn dense flat round icon="menu" @click="left = !left"/> -->
        <q-toolbar-title>
          <!-- <q-avatar>
            <img src="https://cdn.quasar.dev/logo/svg/quasar-logo.svg">
          </q-avatar>-->
          Audire
        </q-toolbar-title>
        <q-space/>
        <!-- <span class="q-mr-md" :v-show="showUser">Jai</span>
        <q-avatar class="q-mr-md" :v-show="showUser">
          <img src="https://cdn.quasar.dev/logo/svg/quasar-logo.svg" class="animate-spin">
        </q-avatar>
        <q-btn :v-show="showUser" @click.native="handleClickSignOut">Logout</q-btn>-->
      </q-toolbar>
    </q-header>

    <!-- <q-drawer
      v-model="left"
      :v-show="showUser"
      side="left"
      overlay
      behavior="desktop"
      bordered
      :content-style="{ backgroundColor: '#808080' }"
    ></q-drawer>-->

    <q-page-container>
      <transition
        name="transitions"
        enter-active-class="animated fadeInLeft"
        leave-active-class="animated fadeOutRight"
        mode="out-in"
      >
        <router-view/>
      </transition>
    </q-page-container>

    <!-- <q-footer bordered class="bg-blue-grey-3 text-black">
      <q-toolbar>
        <q-space></q-space>
        <span
          class="text-subtitle1 absolute-center col-xs-12 q-pl-lg"
        >Audire Copyright @ 2019 OneIntegral Pvt. Ltd.</span>
      </q-toolbar>
    </q-footer> -->
  </q-layout>
</template>

<script>
export default {
  data() {
    return {
      left: true,
      model: "one",
      showUser: false
    };
  },
  mounted() {
    // let that = this;
    // let checkGauthLoad = setInterval(function() {
    //   if (that.$gAuth.isInit === true && that.$gAuth.isAuthorized === true) {
    //     this.showUser = true;
    //   } else {
    //     this.showUser = false;
    //   }
    //   if (that.isInit) clearInterval(checkGauthLoad);
    // }, 1000);
    // this.showUser = false;
    // console.log(this.$gAuth.isAuthorized)
    // that.$root.$on("googleLoginEvent", data => console.log(data));
  },
  methods: {
    handleClickSignOut() {
      this.$gAuth
        .signOut()
        .then(() => {
          //on success do something
          this.showUser = false;
          this.$router.push({ path: "/" });
        })
        .catch(error => {
          //on fail do something
        });
    }
  }
};
</script>

<style scoped>
</style>