<template>
  <div class="antialiased">
    <q-layout container view="lHh Lpr lff" style class="min-h-screen">
      <q-header reveal>
        <q-toolbar class="bg-grey-1">
          <q-btn
            flat
            @click="drawer = !drawer"
            round
            dense
            icon="fas fa-campground"
            color="primary"
          />
          <q-toolbar-title class="flex items-center">
            <span
              class="font-sans font-black text-gray-700 text-xl tracking-wider"
              >Lease Management</span
            >
            <q-space></q-space>
            <span
              class="font-sans font-semibold text-gray-600 text-xl tracking-wider"
              >{{ modulename }}</span
            >
          </q-toolbar-title>
        </q-toolbar>
      </q-header>

      <q-drawer v-model="drawer" show-if-above :width="170" :breakpoint="400">
        <q-scroll-area
          style="height: calc(100% - 200px); margin-top: 200px ;background-color:#022C4C"
        >
          <q-list>
            <q-item
              clickable
              to="/inference"
              active-class="border-l-4 border-gray-200 bg-indigo-5"
            >
              <div class="flex items-center items-base">
                <div class="px-2">
                  <q-icon name="home" color="grey-2" size="17px"></q-icon>
                </div>
                <div
                  class="ml-auto font-bold-soft text-md tracking-wide text-gray-200"
                >
                  Home
                </div>
              </div>
            </q-item>
            <q-item
              clickable
              active
              to="/dashboard"
              active-class="border-l-4 border-gray-200 bg-indigo-5"
            >
              <div class="flex items-center items-base">
                <div class="px-2">
                  <q-icon
                    name="fas fa-chart-line"
                    color="grey-2"
                    size="17px"
                  ></q-icon>
                </div>
                <div
                  class="ml-auto font-bold-soft text-md tracking-wide text-gray-200"
                >
                  Inference
                </div>
              </div>
            </q-item>

            <q-item
              clickable
              active
              to="/transactions"
              active-class="border-l-4 border-gray-200 bg-indigo-5"
            >
              <div class="flex items-center items-base">
                <div class="px-2">
                  <q-icon
                    name="fas fa-clipboard-list"
                    color="grey-2"
                    size="14px"
                  ></q-icon>
                </div>
                <div
                  class="ml-auto font-bold-soft text-md tracking-wide text-gray-200"
                >
                  Transactions
                </div>
              </div>
            </q-item>
            <q-item
              clickable
              to="/templates"
              active-class="border-l-4 border-gray-200 bg-indigo-5"
            >
              <div class="flex items-center items-base">
                <div class="px-2">
                  <q-icon
                    name="fas fa-address-card"
                    color="grey-2"
                    size="13px"
                  ></q-icon>
                </div>
                <div
                  class="ml-auto font-bold-soft text-md tracking-wide text-gray-200"
                >
                  Templates
                </div>
              </div>
            </q-item>
            <q-item
              clickable
              to="/modules"
              active-class="border-l-4 border-gray-200 bg-indigo-5"
            >
              <div class="flex items-center items-base">
                <div class="px-2">
                  <q-icon
                    name="fas fa-archive"
                    color="grey-2"
                    size="14px"
                  ></q-icon>
                </div>
                <div
                  class="ml-auto font-bold-soft text-md tracking-wide text-gray-200"
                >
                  Modules
                </div>
              </div>
            </q-item>
            <!-- <q-item clickable to="/settings" active-class="border-l-4 border-gray-200 bg-indigo-5">
              <div class="flex items-center items-base">
                <div class="px-2">
                  <q-icon name="fas fa-sliders-h" color="grey-2" size="13px"></q-icon>
                </div>
                <div class="ml-auto font-bold-soft text-md tracking-wide text-gray-200">Settings</div>
              </div>
            </q-item>-->
            <q-item
              clickable
              to="/upload"
              active-class="border-l-4 border-gray-200 bg-indigo-5"
            >
              <div class="flex items-center items-base">
                <div class="px-2">
                  <q-icon
                    name="fas fa-cloud-upload-alt"
                    color="grey-2"
                    size="13px"
                  ></q-icon>
                </div>
                <div
                  class="ml-auto font-bold-soft text-md tracking-wide text-gray-200"
                >
                  Upload
                </div>
              </div>
            </q-item>
            <q-item
              clickable
              to="/lease-plan"
              active-class="border-l-4 border-gray-200 bg-indigo-5"
            >
              <div class="flex items-center items-base">
                <div class="px-2">
                  <q-icon
                    name="fas fa-project-diagram"
                    color="grey-2"
                    size="13px"
                  ></q-icon>
                </div>
                <div
                  class="ml-auto font-bold-soft text-md tracking-wide text-gray-200"
                >
                  Plan
                </div>
              </div>
            </q-item>
            <q-item
              clickable
              to="/lease-track"
              active-class="border-l-4 border-gray-200 bg-indigo-5"
            >
              <div class="flex items-center items-base">
                <div class="px-2">
                  <q-icon
                    name="fas fa-chalkboard-teacher"
                    color="grey-2"
                    size="13px"
                  ></q-icon>
                </div>
                <div
                  class="ml-auto font-bold-soft text-md tracking-wide text-gray-200"
                >
                  Track
                </div>
              </div>
            </q-item>
          </q-list>
        </q-scroll-area>
        <q-img
          class="absolute-top border-b-4 border-grey-200 object-fill"
          src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' width='12' height='12'%3E%3Cpath fill='%239C92AC' fill-opacity='0.045' d='M56 26v2h-7.75c2.3-1.27 4.94-2 7.75-2zm-26 2a2 2 0 1 0-4 0h-4.09A25.98 25.98 0 0 0 0 16v-2c.67 0 1.34.02 2 .07V14a2 2 0 0 0-2-2v-2a4 4 0 0 1 3.98 3.6 28.09 28.09 0 0 1 2.8-3.86A8 8 0 0 0 0 6V4a9.99 9.99 0 0 1 8.17 4.23c.94-.95 1.96-1.83 3.03-2.63A13.98 13.98 0 0 0 0 0h7.75c2 1.1 3.73 2.63 5.1 4.45 1.12-.72 2.3-1.37 3.53-1.93A20.1 20.1 0 0 0 14.28 0h2.7c.45.56.88 1.14 1.29 1.74 1.3-.48 2.63-.87 4-1.15-.11-.2-.23-.4-.36-.59H26v.07a28.4 28.4 0 0 1 4 0V0h4.09l-.37.59c1.38.28 2.72.67 4.01 1.15.4-.6.84-1.18 1.3-1.74h2.69a20.1 20.1 0 0 0-2.1 2.52c1.23.56 2.41 1.2 3.54 1.93A16.08 16.08 0 0 1 48.25 0H56c-4.58 0-8.65 2.2-11.2 5.6 1.07.8 2.09 1.68 3.03 2.63A9.99 9.99 0 0 1 56 4v2a8 8 0 0 0-6.77 3.74c1.03 1.2 1.97 2.5 2.79 3.86A4 4 0 0 1 56 10v2a2 2 0 0 0-2 2.07 28.4 28.4 0 0 1 2-.07v2c-9.2 0-17.3 4.78-21.91 12H30zM7.75 28H0v-2c2.81 0 5.46.73 7.75 2zM56 20v2c-5.6 0-10.65 2.3-14.28 6h-2.7c4.04-4.89 10.15-8 16.98-8zm-39.03 8h-2.69C10.65 24.3 5.6 22 0 22v-2c6.83 0 12.94 3.11 16.97 8zm15.01-.4a28.09 28.09 0 0 1 2.8-3.86 8 8 0 0 0-13.55 0c1.03 1.2 1.97 2.5 2.79 3.86a4 4 0 0 1 7.96 0zm14.29-11.86c1.3-.48 2.63-.87 4-1.15a25.99 25.99 0 0 0-44.55 0c1.38.28 2.72.67 4.01 1.15a21.98 21.98 0 0 1 36.54 0zm-5.43 2.71c1.13-.72 2.3-1.37 3.54-1.93a19.98 19.98 0 0 0-32.76 0c1.23.56 2.41 1.2 3.54 1.93a15.98 15.98 0 0 1 25.68 0zm-4.67 3.78c.94-.95 1.96-1.83 3.03-2.63a13.98 13.98 0 0 0-22.4 0c1.07.8 2.09 1.68 3.03 2.63a9.99 9.99 0 0 1 16.34 0z'%3E%3C/path%3E%3C/svg%3E"
          style="height: 200px;background-color:#022C4C"
        >
          <div class="flex flex-col items-center bg-transparent w-full">
            <div>
              <span
                class="font-serif font-black text-2xl text-gray-200 tracking-wider"
                >AUDIRE</span
              >
            </div>
            <div>
              <q-avatar rounded class="my-3">
                <img size="40px" src="assets/user.svg" />
              </q-avatar>
            </div>
            <div>
              <span
                class="text-xl text-gray-200 font-semibold font-sans tracking-wide"
                >{{ this.$q.localStorage.getItem("audire_user") }}</span
              >
            </div>
            <div class="font-sans">
              <q-btn
                flat
                no-caps
                outline
                dense
                size="md"
                rounded
                @click="logOut"
              >
                <span class="font-sans text-gray-200">logout</span>
              </q-btn>
            </div>
          </div>
        </q-img>
      </q-drawer>

      <q-page-container class="bg-grey-12">
        <transition
          name="transitions"
          :duration="{ enter: 2000, leave: 200 }"
          enter-active-class="animated fadeInLeft"
          leave-active-class="animated fadeOutRight"
          mode="out-in"
        >
          <router-view />
        </transition>
      </q-page-container>
    </q-layout>
  </div>
</template>

<script>
  import { EventBus } from "../pages/event-bus";
  export default {
    data() {
      return {
        left: false,
        model: "one",
        imgSource: null,
        userName: null,
        drawer: false,
        modulename: null
      };
    },
    created() {
      if (
        this.$q.localStorage.getItem("audire_user") &&
        this.$q.localStorage.getItem("audire_bearer")
      ) {
        this.userName = this.$q.localStorage.getItem("audire_user");
      } else {
        this.$router.push("/");
      }
      if (this.$q.localStorage.getItem("moduleAndProcess")) {
        
        if (
          JSON.parse(this.$q.localStorage.getItem("moduleAndProcess")) !== null
        ) {
          this.modulename = Object.keys(
            JSON.parse(this.$q.localStorage.getItem("moduleAndProcess"))
          )[0];
        }
      }
    },
    methods: {
      logOut() {
        this.$q.localStorage.remove("audire_bearer");
        this.$q.localStorage.remove("audire_user");
        this.$q.localStorage.remove("audire_user_org");
        this.$q.localStorage.remove("moduleAndProcess");
        this.$router.push({ path: "/" });
      }
    }
  };
</script>

<style></style>
