<template>
  <q-layout view="hHh lpR fff" class="bg-grey-3">
    <q-header reveal class="bg-blue-grey-3 text-black">
      <q-toolbar>
        <q-btn dense flat round icon="menu" @click="left = !left" />
        <q-toolbar-title>Audire</q-toolbar-title>
        <q-space />
        <span class="q-mr-md text-subtitle1 text-black text-capitalize">{{userName }}</span>
        <q-btn-dropdown rounded flat push color="bg-blue-grey-3" icon="img:assets/user.svg" outline>
          <!-- <img :src="imgSource"> -->
          <q-list>
            <q-item clickable v-close-popup>
              <q-item-section>
                <q-item-label @click="logOut">Logout</q-item-label>
              </q-item-section>
            </q-item>
          </q-list>
        </q-btn-dropdown>
      </q-toolbar>
    </q-header>

    <q-drawer
      v-model="left"
      side="left"
      behavior="default"
      :content-style="{ backgroundColor: '#263238' }"
      :width="150"
    >
      <q-list bordered separator class="text-white text-subtitle2 text-overline">
        <q-item clickable to="/dashboard" class="text-white">
          <q-item-section>Dashboard</q-item-section>
        </q-item>

        <q-item clickable to="/upload" class="text-white">
          <q-item-section>
            <q-item-label>Upload</q-item-label>
          </q-item-section>
        </q-item>

        <q-item clickable to="/kgc" class="text-white">
          <q-item-section>
            <q-item-label>Create KG</q-item-label>
          </q-item-section>
        </q-item>
      </q-list>
    </q-drawer>

    <q-page-container>
      <transition
        name="transitions"
        enter-active-class="animated fadeInLeft"
        leave-active-class="animated fadeOutRight"
        mode="out-in"
      >
        <router-view />
      </transition>
    </q-page-container>

    <!-- <q-footer bordered class="bg-blue-grey-3 text-black">
      <q-toolbar>
        <q-space></q-space>
        <span
          class="text-subtitle1 absolute-center col-xs-12 q-pl-lg"
        >Audire Copyright @ 2019 OneIntegral Pvt. Ltd.</span>
      </q-toolbar>
    </q-footer>-->
  </q-layout>
</template>

<script>
import { EventBus } from "../pages/event-bus";
export default {
  data() {
    return {
      left: false,
      model: "one",
      imgSource: null,
      userName: null
    };
  },
  created() {
    if (
      this.$q.localStorage.getItem("audire_user") &&
      this.$q.localStorage.getItem("audire_bearer")
    ) {
      this.userName = this.$q.localStorage.getItem("audire_user");
    } else {
      this.$router.push("/");
    }
  },
  methods: {
    logOut() {
      this.$q.localStorage.remove("audire_bearer");
      this.$q.localStorage.remove("audire_user");
      this.$q.localStorage.remove("audire_user_org");
      this.$router.push({ path: "/" });
    }
  }
};
</script>

<style scoped>
</style>