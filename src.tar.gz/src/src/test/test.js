let a = ['domesticorder.csv', 'po.csv', 'grn.csv']
console.log(a.splice(a.indexOf('po.csv'),1))
console.log(a)