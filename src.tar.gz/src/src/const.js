export const ApiConstants = {
    // APIURL: 'http://localhost:7777/',
    // LOGINAPIURL: 'http://localhost:8000/',
    
    APIURL: 'http://18.223.39.218:7777/',
    LOGINAPIURL: 'http://18.223.39.218:8000/',
}